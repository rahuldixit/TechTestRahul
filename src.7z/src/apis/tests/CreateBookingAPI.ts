// @ts-check
import { test, expect } from "@playwright/test";
import { faker } from "@faker-js/faker";
import { postRequest } from "../../../utils/apiUtils";

test("should be able to create a booking", async ({ baseURL }) => {
  const firstName = faker.person.firstName();
  const lastName = faker.person.lastName();
  const totalPrice = faker.number.int();
  const checkinDate = Date.now();
  const checkoutDate = faker.date.soon();
  const addNeeds = faker.lorem.word();

  const response = await postRequest({
    URL: `${baseURL}/booking`,
    payload: {
      firstname: firstName,
      lastname: lastName,
      totalprice: totalPrice,
      depositpaid: true,
      bookingdates: {
        checkin: checkinDate,
        checkout: checkoutDate,
      },
      additionalneeds: addNeeds,
    },
  });

  expect(response.ok()).toBeTruthy();
  expect(response.status()).toBe(200);
  const responseBody = await response.json();
  expect(responseBody.booking).toHaveProperty("firstname", firstName);
  expect(responseBody.booking).toHaveProperty("lastname", lastName);
  expect(responseBody.booking).toHaveProperty("totalprice", totalPrice);
  expect(responseBody.booking).toHaveProperty("depositpaid", true);
});
