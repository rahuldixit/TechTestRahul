// @ts-check
import { test, expect } from "@playwright/test";
import { deleteRequest, postRequest } from "../../../utils/apiUtils";

let token;

test("should be able to delete the booking details", async ({ baseURL }) => {
  // Create a Token which will be used in DELETE request
  const response = await postRequest({
    URL: `${baseURL}/auth`,
    payload: {
      username: "Admin",
      password: "Test1234",
    },
  });
  expect(response.ok()).toBeTruthy();
  expect(response.status()).toBe(200);
  const responseBody = await response.json();
  token = responseBody.token;
  console.log("New Token is: " + token);

  // DELETE

  const deleteresponse = await deleteRequest({
    URL: `${baseURL}/1`,
    headers: {
      "Content-Type": "application/json",
      token: `${token}`,
    },
  });
  expect(deleteresponse.status()).toEqual(201);
  expect(deleteresponse.statusText()).toBe("Created");
});
