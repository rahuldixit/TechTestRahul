import { test, expect } from "@playwright/test";
import { getRequest } from "../../../utils/apiUtils";

test("should be get all the booking details", async ({ baseURL }) => {
  const response = await getRequest({
    URL: `${baseURL}/booking`,
    headers: { "Content-Type": "application/json" },
  });
  expect(response.ok()).toBeTruthy();
  expect(response.status()).toBe(200);
});
