// @ts-check
import { test, expect } from "@playwright/test";
import { putRequest } from "../../../utils/apiUtils";
test("should be able to delete the booking details", async ({ baseURL }) => {
  const response = await putRequest({
    URL: `${baseURL}/1`,
    payload: {
      totalprice: 2004,
      additionalneeds: "NA",
    },
  });
  console.log(response);
  expect(response.status()).toBe(200);
  expect(response.ok()).toBeTruthy();
});
