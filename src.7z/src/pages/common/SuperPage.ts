import { Locator, Page } from "@playwright/test";
import moment from "moment";

/*
This super page is for functions applicable to any application.
Typically functions which operate on a given Locator, or does generic calculations
*/

export class SuperPage {
  protected page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForVisibility(element: Locator, timeout: number = 5000) {
    let wait = 0;
    while (!(await element.isVisible()) && timeout > wait) {
      await this.page.waitForTimeout(1000);
      wait += 1000;
    }
    return await element.isVisible();
  }

  async getPreviousWorkday() {
    const workday = moment();
    const day = workday.day();
    let diff = 1; // returns yesterday
    if (day == 0 || day == 1) {
      // is Sunday or Monday
      diff = day + 2; // returns Friday
    }
    return workday.subtract(diff, "days");
  }
}
