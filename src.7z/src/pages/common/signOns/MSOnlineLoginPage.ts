import { Locator, Page } from "@playwright/test";
import { SuperPage } from "../SuperPage";

export class MsOnlineLoginPage extends SuperPage {
  readonly email: Locator;
  readonly password: Locator;
  readonly btnNext: Locator;
  readonly signIn: Locator;
  readonly staySignedInNo: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.email = this.page.locator("#i0116");
    this.password = this.page.locator("#i0118");
    this.btnNext = this.page.locator('input[type="submit"]');
    this.signIn = this.page.locator("#idSIButton9");
    this.staySignedInNo = this.page.locator("input#idBtn_Back");
  }

  async doLogin(email: string, password: string) {
    await this.email.fill(email, { timeout: 30000 });
    await this.btnNext.click();
    await this.password.waitFor({ state: "visible" });
    await this.password.fill(password);
    await this.signIn.waitFor({ state: "attached" });
    await this.signIn.click();
    if (await this.waitForVisibility(this.staySignedInNo)) {
      await this.staySignedInNo.click();
    }
  }
}
