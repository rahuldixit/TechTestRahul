import { Locator, Page } from "@playwright/test";
import { SuperPage } from "pages/common/SuperPage";

export class BasePage extends SuperPage {
  readonly linkCustomerOrProducts: Locator;
  readonly linkRecosting: Locator;
  readonly linkAdmin: Locator;
  readonly linkFleet: Locator;
  readonly linkClients: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.linkCustomerOrProducts = this.page.locator(
      'a:has-text("Customers/Products")',
    );
    this.linkRecosting = this.page.locator('a:text-is("Recosting")');
    this.linkAdmin = this.page.locator("#TOPMENU").locator(':text-is("Admin")');
    this.linkFleet = this.page.locator('a:text-is("Fleet")');
    this.linkClients = this.page.locator('a:text-is("Clients")');
  }

  async getValueInSearchResultsFirstRow(columnName: string) {
    const columnIndex = Number(
      await this.page
        .locator(
          'th:has(.tablesorter-header-inner:text-is("' + columnName + '"))',
        )
        .getAttribute("data-column"),
    );
    const value = await this.page
      .locator("tr")
      .locator("td")
      .nth(columnIndex)
      .innerText();
    // replace any '&nbsp;' (non-breaking space) with a ' ' to allow comparisons
    return value.replace("\xa0", " "); // '\xa0' = '&nbsp;'
  }

  async clickSideMenu(menuName: string) {
    await this.page.locator('#SIDEMENU :text-is("' + menuName + '")').click();
  }

  async clickHorizontalTopMenu(menuName: string) {
    await this.page.locator('#TOPMENU :text-is("' + menuName + '")').click();
  }
}
