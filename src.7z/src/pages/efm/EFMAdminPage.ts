import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMAdminPage extends BasePage {
  readonly headingEFMProcessMonitoring: Locator;
  readonly headingRunPostTransactions: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headingEFMProcessMonitoring = this.page.locator(
      '.title:has-text("EFM Processes Monitoring")',
    );
    this.headingRunPostTransactions = this.page.locator(
      'h3:text-is("Run Post Transactions")',
    );
  }
}
