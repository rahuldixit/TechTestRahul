import { Locator, Page, expect } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMClientPage extends BasePage {
  readonly productDetails: Locator;
  readonly btnEditProduct: Locator;
  readonly btnBackProductDetails: Locator;

  constructor(page: Page) {
    super(page);
    this.productDetails = this.page.locator("span.title");
    this.btnEditProduct = this.page.locator('input[value="Edit product"]');
    this.btnBackProductDetails = this.page.locator('input[name="back"]');
  }

  async verifyField(fieldName: string, data: string) {
    const fieldData = this.page
      .locator(`td:text-is("${fieldName}")+td`)
      .first();
    expect(await fieldData.innerText()).toBe(data);
  }

  async verifySelectField(fieldName: string, data: string) {
    const field = this.page.locator(
      `xpath=//td[contains(.,"${fieldName}")]/..//select`,
    );
    const optionValue = await field.inputValue();
    const fieldData = field.locator(`option[value="${optionValue}"]`);
    expect(await fieldData.textContent()).toBe(data);
  }

  async verifyInputField(fieldName: string, data: string) {
    const field = this.page
      .locator(`xpath=//td[contains(.,"${fieldName}")]/..//input`)
      .first();
    expect(await field.inputValue()).toBe(data);
  }

  async verifyRadioButton(fieldName: string, buttonNo: string) {
    const radioButton = this.page
      .locator(`xpath=//td[contains(.,"${fieldName}")]/..//td`)
      .locator(`input[value="${buttonNo}"]`);
    expect(await radioButton.isChecked()).toBe(true);
  }
}
