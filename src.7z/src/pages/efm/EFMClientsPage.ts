import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMClientsPage extends BasePage {
  readonly clientsTab: Locator;
  readonly findClients: Locator;
  readonly btnSearchClient: Locator;
  readonly btnCreateNewStandardCompany: Locator;
  readonly btnCreateNewOnePayCompany: Locator;
  readonly clientSearchResult: Locator;
  readonly headerClients: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.clientsTab = this.page.locator('a[href*="/efm/login?employer=tm"]');
    this.findClients = this.page.locator('input[name="company_search_name"]');
    this.btnSearchClient = this.page.locator('input[name="find_company"]');
    this.btnCreateNewStandardCompany = this.page.locator(
      'input[name="create_company"]',
    );
    this.btnCreateNewOnePayCompany = this.page.locator(
      'input[name="create_fm_one_company"]',
    );
    this.clientSearchResult = this.page.locator('tbody[aria-live="polite"]');
    this.headerClients = this.page.locator('h3:text-is("Clients")');
  }
}
