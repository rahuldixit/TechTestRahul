import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMPaymentsPage extends BasePage {
  readonly btnRunReportFBTEndOfYear: Locator;
  readonly btnRunReportInForeground: Locator;
  readonly dateFromDay: Locator;
  readonly dateFromYear: Locator;
  readonly dateToDay: Locator;
  readonly dateToYear: Locator;
  readonly btnNext: Locator;
  readonly btnViewAsPDF: Locator;
  readonly btnRunFBTEOY: Locator;
  readonly reportStatus: Locator;
  readonly headingFBTPayments: Locator;
  readonly headingRunStandardFBT: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnRunReportFBTEndOfYear = this.page.locator(
      'input[name="fbt_end_of_year"]',
    );
    this.btnRunReportInForeground = this.page.locator(
      'input[name="fbt_payment"]',
    );

    this.dateFromDay = this.page.locator('input[name="date_from.day"]');
    this.dateFromYear = this.page.locator('input[name="date_from.year"]');
    this.dateToDay = this.page.locator('input[name="date_to.day"]');
    this.dateToYear = this.page.locator('input[name="date_to.year"]');
    this.btnNext = this.page.locator('input[name="next"]');
    this.btnViewAsPDF = this.page.locator('input[name="show_pdf"]');
    this.btnRunFBTEOY = this.page.locator('input[name="run_fbt_end_of_year"]');
    this.reportStatus = this.page.locator("#status");
    this.headingFBTPayments = this.page.locator(
      '.title:text-is("FBT Payments")',
    );
    this.headingRunStandardFBT = this.page.locator(
      'h3:text-is("Run Standard FBT End of Year for Employer")',
    );
  }

  //Select company by selecting company name directly
  async selectCompanyByName(companyName: string) {
    await this.page
      .locator(".cssbg td")
      .filter({ hasText: companyName })
      .click();
  }

  async selectFromMonthDropDown(fromMonth: string) {
    await this.page
      .locator('select[name="date_from.month"]')
      .selectOption(fromMonth);
  }

  async selectToMonthDropDown(toMonth: string) {
    await this.page
      .locator('select[name="date_to.month"]')
      .selectOption(toMonth);
  }
}
