import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMReportsPage extends BasePage {
  readonly runVehiclesReportFBTCR: Locator;
  readonly runVehicleReportFBTCGR: Locator;
  readonly btnEmailReports: Locator;
  readonly headingFBTReports: Locator;
  readonly headingFBTCompanyReport: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.runVehiclesReportFBTCR = this.page.locator(
      'input[name="company_fbt_report"]',
    );
    this.runVehicleReportFBTCGR = this.page.locator(
      'input[name="company_group_fbt_report"]',
    );
    this.btnEmailReports = this.page.locator(
      'input[name="email_report_multiple_companies"]',
    );
    this.headingFBTReports = this.page.locator('.title:text-is("FBT Reports")');
    this.headingFBTCompanyReport = this.page.locator(
      'h3:text-is("FBT Company Report")',
    );
  }
}
