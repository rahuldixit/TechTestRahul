import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMFBTTrackingPage extends BasePage {
  readonly headingFBTSummaryFor: Locator;
  readonly tableFBTSummary: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headingFBTSummaryFor = this.page.locator(
      '.title:has-text("FBT Summary for")',
    );
    this.tableFBTSummary = this.page.locator(".report");
  }
}
