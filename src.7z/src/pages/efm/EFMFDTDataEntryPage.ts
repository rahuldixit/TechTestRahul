import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FDTPage extends BasePage {
  readonly linkFDTDataEntry: Locator;
  readonly productHeader: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.linkFDTDataEntry = this.page.locator('a:has-text("FBT Data Entry")');
    this.productHeader = this.page.locator(".middle-box");
  }
}
