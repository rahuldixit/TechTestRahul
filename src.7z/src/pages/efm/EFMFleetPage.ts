import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMFleetpage extends BasePage {
  readonly fleetTab: Locator;
  readonly linkFBTReport: Locator;

  readonly linkFBTPayments: Locator;
  readonly linkFBTRecosting: Locator;
  readonly runVehiclesReportFBTCR: Locator;
  readonly runVehicleReportFBTCGR: Locator;
  readonly btnEmailReports: Locator;
  readonly tickboxFirstCompany: Locator;
  readonly btnEmailCompanies: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.fleetTab = this.page.locator(
      'a[href*="/efm/login?report_contract_report_select_date=tm"]',
    );
    this.linkFBTReport = this.page.locator('a[href*="report_fbt=sm"]');

    this.linkFBTPayments = this.page.locator(
      'a[href*="report_fbt_payments=sm"]',
    );
    this.linkFBTRecosting = this.page.locator(
      'a[href*="/efm/login?report_fbt_recosting=sm"]',
    );
    this.runVehiclesReportFBTCR = this.page.locator(
      'input[name="company_fbt_report"]',
    );
    this.runVehicleReportFBTCGR = this.page.locator(
      'input[name="company_group_fbt_report"]',
    );
    this.btnEmailReports = this.page.locator(
      'input[name="email_report_multiple_companies"]',
    );
    this.tickboxFirstCompany = this.page
      .locator('input[type="checkbox"]')
      .first();
    this.btnEmailCompanies = this.page.locator(
      '[name="email_report_multiple_companies"]',
    );
  }

  //Select company by selecting checkbox
  async selectCheckboxForCompanyByName(companyName: string) {
    const companyTickBox = this.page
      .locator(
        `xpath=//a[contains(.,"${companyName}")]/../..//input[@type="checkbox"]`,
      )
      .first();
    await companyTickBox.click();
  }
}
