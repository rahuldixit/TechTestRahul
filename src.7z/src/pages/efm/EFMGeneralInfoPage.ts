import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMGeneralInfoPage extends BasePage {
  readonly generalInfoTable: Locator;
  readonly linkRecostings: Locator;
  readonly btnAddRecostingRequest: Locator;
  readonly linkFBT: Locator;
  readonly linkFBTTracking: Locator;
  readonly tableFBTSummary: Locator;
  readonly valueUniqueID: Locator;
  readonly valueRegistration: Locator;
  readonly valueDescription: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.generalInfoTable = this.page.locator(".middle-box");
    this.linkRecostings = this.page.locator(
      'a[href*="/efm/login?employee_person_prod_recostings=sm"]',
    );
    this.btnAddRecostingRequest = this.page.locator(
      'input[name="create_recosting_request"]',
    );
    this.linkFBT = this.page.locator('a:has-text("FBT ...")');
    this.linkFBTTracking = this.page.locator(
      'a[href*="employee_person_prod_fbt=sm"]',
    );
    this.tableFBTSummary = this.page.locator(".report");
    this.valueUniqueID = this.page
      .locator('tr:has(td:text-is("Unique ID")) td')
      .last();
    this.valueRegistration = this.page
      .locator('tr:has(td:text-is("Registration")) td')
      .last();
    this.valueDescription = this.page
      .locator('tr:has(td:text-is("Description")) td')
      .last();
  }

  //To be checked
  async retrieveGeneralInfoDetails() {
    const generalInfo = await this.page.locator("tbody tr").all();
    for (const row of generalInfo) {
      console.log("Title is", await row.locator("td").first().textContent());
      console.log("Value is", await row.locator("td").last().textContent());
    }
  }
}
