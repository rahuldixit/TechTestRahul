import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMHomePage extends BasePage {
  readonly findCustomersOrProducts: Locator;
  readonly btnSearchCustomer: Locator;
  readonly btnPendingInvoices: Locator;
  readonly searchResultsTable: Locator;
  readonly btnCreateNewEmployee: Locator;
  readonly btnCreateOnePayLessee: Locator;
  readonly btnCreateConsumerFinanceLessee: Locator;
  readonly headerFBTTitle: Locator;
  readonly nameLink: Locator;
  readonly productIDLink: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.findCustomersOrProducts = this.page.locator('input[name="name"]');
    this.btnSearchCustomer = this.page.locator('input[name="find_lessee"]');
    this.btnPendingInvoices = this.page.locator(
      'input[name="pending_brokerage_invoices"]',
    );
    this.searchResultsTable = this.page.locator('tbody[aria-live="polite"]');
    this.btnCreateNewEmployee = this.page.locator(
      'input[name="create_employee"]',
    );
    this.btnCreateOnePayLessee = this.page.locator(
      'input[name="create_fm_one_lessee"]',
    );
    this.btnCreateConsumerFinanceLessee = this.page.locator(
      'input[name="create_consumer_lessee"]',
    );
    this.headerFBTTitle = this.page.locator("span.title");
    this.nameLink = this.page.locator("#lessees_table td a").first();
    this.productIDLink = this.page.locator("#lessees_table td a").nth(1);
  }

  async selectProductByName(customerName: string) {
    await this.page
      .locator('tbody[aria-live="polite"] tr td a')
      .filter({ hasText: customerName })
      .first()
      .click();
  }

  async selectProductByID(productID: string) {
    await this.page
      .locator('tbody[aria-live="polite"] tr td a')
      .filter({ hasText: productID })
      .first()
      .click();
  }

  async waitFor() {
    await this.linkCustomerOrProducts.waitFor();
  }
}
