import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMLoginPage extends BasePage {
  readonly efmUserName: Locator;
  readonly efmPassword: Locator;
  readonly btnLoginEFM: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.efmUserName = this.page.locator('input[name="username"]');
    this.efmPassword = this.page.locator('input[name="passwd"]');
    this.btnLoginEFM = this.page.locator('input[name="login"]');
  }

  async openEFM(url: string) {
    await this.page.goto(url);
  }
}
