import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class EFMRecostingPage extends BasePage {
  readonly headerRecosting: Locator;
  readonly btnAddRecostingRequest: Locator;
  readonly selectSummary: Locator;
  readonly btnSummarySave: Locator;
  readonly linkLatestRequest: Locator;
  readonly btnRecost: Locator;
  readonly btnRecost2: Locator;
  readonly btnRecostConfirm: Locator;
  readonly checkboxManualOverride: Locator;
  readonly btnNextViewSummary: Locator;
  readonly btnNextViewQuote: Locator;
  readonly btnSaveRecosting: Locator;
  readonly textArea: Locator;
  readonly btnConfirmSave: Locator;
  readonly btnEditRecipients: Locator;
  readonly emailRecipients: Locator;
  readonly btnSaveEmailAddress: Locator;
  readonly emailTemplate: Locator;
  readonly btnSendEmail: Locator;
  readonly btnSetToRecosted: Locator;
  readonly btnConfirm: Locator;
  readonly btnSendLater: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headerRecosting = this.page.locator(
      'span:has-text("Recosting Requests")',
    );
    this.btnAddRecostingRequest = this.page.locator(
      'input[value="Add Recosting Request"]',
    );
    this.selectSummary = this.page.locator("#customer_summary_type_id");
    this.btnSummarySave = this.page.locator("#save");
    this.linkLatestRequest = this.page
      .locator(".report")
      .nth(1)
      .locator("tr")
      .nth(1)
      .locator("td a")
      .first();
    this.btnRecost = this.page.locator('input[value="Recost"]');
    this.btnRecost2 = this.page.locator('input[value="Recost ..."]');
    this.btnRecostConfirm = this.page.locator('input[value="Confirm"]');
    this.checkboxManualOverride = this.page.locator('input[type="checkbox"]');
    this.btnNextViewSummary = this.page.locator('input[name="view_summary"]');
    this.btnNextViewQuote = this.page.locator('input[name="view_quote"]');
    this.btnSaveRecosting = this.page.locator('input[name="save"]');
    this.textArea = this.page.locator("textarea");
    this.btnConfirmSave = this.page.locator('input[name="confirm_save"]');
    this.btnEditRecipients = this.page.locator('input[name="edit_recipients"]');
    this.emailRecipients = this.page.locator('input[name="new_to_list"]');
    this.btnSaveEmailAddress = this.page.locator('input[name="save"]');
    this.emailTemplate = this.page.locator("#email_template_name");
    this.btnSendEmail = this.page.locator('input[name="send"]');
    this.btnSetToRecosted = this.page.locator('input[name="set_to_recosted"]');
    this.btnConfirm = this.page.locator('input[name="confirm"]');
    this.btnSendLater = this.page.locator('input[name="cancel"]');
  }

  async getRecostInputLocator(col: number, n: number) {
    const recostInput = this.page.locator(
      `xpath=//input[@type="checkbox"]/../../td[${col}]/input`,
    );
    return recostInput.nth(n);
  }

  async getRecommendedValue(col: number, n: number) {
    const recommendedValue = this.page.locator(
      `xpath=//input[@type="checkbox"]/../../td[${col}]`,
    );
    return (await recommendedValue.nth(n).innerText())
      .trim()
      .replace("$", "")
      .replace(",", "");
  }
}
