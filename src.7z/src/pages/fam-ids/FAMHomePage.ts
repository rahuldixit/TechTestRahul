import { Locator, Page } from "@playwright/test";
import { SuperPage } from "../common/SuperPage";

export class FAMHomePage extends SuperPage {
  readonly imsAUNEM: Locator;
  readonly milesQuoteNum: Locator;
  readonly btnRetrieve: Locator;
  readonly initiateCreditHeader: Locator;
  readonly matchMessage: Locator;
  readonly btnActions: Locator;
  readonly btnSendInvite: Locator;
  readonly creditApplicationSuccess: Locator;
  readonly searchExistingApplicationTab: Locator;
  readonly imsAUNEMForSearch: Locator;
  readonly milesQuoteNumForSearch: Locator;
  readonly employeeNameForSearch: Locator;
  readonly btnSearch: Locator;
  readonly searchResult: Locator;
  readonly imsReferenceLink: Locator;
  readonly milesQuoteValue: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.imsAUNEM = this.page.locator("input#mat-input-0");
    this.milesQuoteNum = this.page.locator("input#mat-input-1");
    this.btnRetrieve = this.page.locator("button.mat-focus-indicator");
    this.initiateCreditHeader = this.page.locator(".title.ng-star-inserted");
    this.matchMessage = this.page.locator(
      ".mat-card.mat-focus-indicator.message",
    );
    this.btnActions = this.page.locator(
      "button.mat-focus-indicator.mat-menu-trigger",
    );
    this.btnSendInvite = this.page.locator(
      "button.mat-focus-indicator.mat-menu-item",
    );
    this.creditApplicationSuccess = this.page.locator(
      "div.title.ng-star-inserted",
    );

    //Search an existing application
    this.searchExistingApplicationTab = this.page.locator("a.command-button");
    this.imsAUNEMForSearch = this.page.locator("input#mat-input-22");
    this.milesQuoteNumForSearch = this.page.locator("input#mat-input-28");
    this.employeeNameForSearch = this.page.locator("input#mat-input-29");
    this.btnSearch = this.page.locator(".mat-focus-indicator.btn-nav");
    this.searchResult = this.page.locator(".mat-row.cdk-row");
    this.imsReferenceLink = this.page.locator("td.mat-column-imsReference a");
    this.milesQuoteValue = this.page.locator("td.mat-column-milesReference");
  }

  async openFAM(url: string) {
    await this.page.goto(url);
  }

  async selectApplicationType(applicationType: string) {
    await this.page.getByRole("radiogroup").getByText(applicationType).check();
  }
}
