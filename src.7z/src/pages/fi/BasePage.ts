import { Locator, Page } from "@playwright/test";
import { SuperPage } from "pages/common/SuperPage";

export class BasePage extends SuperPage {
  readonly home: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.home = this.page.locator('a:text-is("Home")');
  }

  async goToHome() {
    await this.home.click();
  }

  /**
   * This is for tables which typically appear on reporting pages. Example: Reports > Fleet Listing.
   * @returns A locator, so you can use innerText(), waitFor(), click() etc...
   * @param tableIndex There are usually 2 tables within a table. Provide the index for the table you want.
   * tableIndex = 0. The first table is the Registration column.
   * tableIndex = 1. The 2nd table is the rest of the data, which moves with the horizontal scroll bar.
   * @param rowIndex Once you have the correct table, provide the index for the row.
   * @param columnIndex Provide the index for the column.
   */
  async getTableCellLocator({
    tableIndex = 0,
    rowIndex = 0,
    columnIndex = 0,
  }: {
    tableIndex?: number;
    rowIndex?: number;
    columnIndex?: number;
  }) {
    return this.page
      .locator("tbody")
      .nth(tableIndex)
      .locator("tr")
      .nth(rowIndex)
      .locator("td")
      .nth(columnIndex);
  }

  /**
   * Use getTableCellLocator( { } ).waitFor( ) to ensure data has loaded
   * @returns the number of rows
   */
  async getNumberOfTableRows({ tableIndex = 1 }: { tableIndex?: number }) {
    return this.page.locator("tbody").nth(tableIndex).locator("tr").count();
  }

  /**
   * Will return multiple if the text is not unique.
   * @returns the locator(s), so you can use nth(), click(), waitFor() etc...
   */
  async getTableCellLocatorByText(exactText: string, tableIndex = 0) {
    return this.page
      .locator("tbody")
      .nth(tableIndex)
      .locator(':text-is("' + exactText + '")');
  }

  async clickTab(tabName: string) {
    await this.page
      .locator(`a[data-toggle="tab"] :text-is("${tabName}")`)
      .click();
  }
}
