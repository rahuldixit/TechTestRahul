import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIDriverTransferPage extends BasePage {
  readonly registrationValue: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.registrationValue = this.page
      .locator('div:has(>label:has-text("Registration"))')
      .locator("div");
  }
}
