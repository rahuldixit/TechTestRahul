import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIFleetDataManagementPage extends BasePage {
  readonly fieldSearchVehicle: Locator;
  readonly btnSearchVehicle: Locator;
  readonly btnDriverDetails: Locator;
  readonly btnUpdateVehicleLocation: Locator;
  readonly currentLocation: Locator;
  readonly dropdownNewLocation: Locator;
  readonly btnSelectVehicleLocation: Locator;
  readonly sectionBody: Locator;
  readonly newAddress: Locator;
  readonly linkHere: Locator;
  readonly currentDriver: Locator;
  readonly searchDriver: Locator;
  readonly searchForDriver: Locator;
  readonly btnTransferDriver: Locator;
  readonly btnDriverSearch: Locator;
  readonly odometerAllocation: Locator;
  readonly currentOdo: Locator;
  readonly btnOK: Locator;
  readonly btnGoBack: Locator;
  readonly btnPerformCostCentreTransfer: Locator;
  readonly currentCostCentre: Locator;
  readonly selectCostCentreNewLocation: Locator;
  readonly selectCostCentreNewLocations: Locator;
  readonly btnCostCentreTransferApply: Locator;
  readonly btnSubmitChanges: Locator;
  readonly btnSubmitOdoReading: Locator;
  readonly lastOdoReading: Locator;
  readonly btnUpdateVehicleDetails: Locator;
  readonly dropdownVehicleCategory: Locator;
  readonly dropdownVehiclePurpose: Locator;
  readonly dropdownVehicleRole: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.fieldSearchVehicle = this.page.locator("#VehicleSearchString");
    this.btnSearchVehicle = this.page.locator("#SearchVehicleButton");
    this.btnDriverDetails = this.page.locator(
      '[data-original-title="Driver Details"]',
    );
    this.btnUpdateVehicleLocation = this.page.locator(
      '[data-original-title="Update Vehicle Location"]',
    );
    this.currentLocation = this.page.locator(
      'xpath=//label[contains(.,"Current Location")]/..//div',
    );
    this.dropdownNewLocation = this.page.locator("#NewVehicleLocationCode");
    this.btnSelectVehicleLocation = this.page.locator("#selectVehicleButton");
    this.sectionBody = this.page.locator(".section-body");
    this.newAddress = this.page.locator("#searchTextField");
    this.linkHere = this.page.locator('a:text-is("here")');
    this.currentDriver = this.page.locator(
      'xpath=//label[contains(.,"Current Driver")]/..//div',
    );
    this.searchDriver = this.page.locator("#DriverSearch");
    this.searchForDriver = this.page.locator("#DriverSearchString");
    this.btnTransferDriver = this.page.locator("#TransferButton");
    this.btnDriverSearch = this.page.locator("#DriverSearchButton");
    this.odometerAllocation = this.page.locator("#NewAllocationOdo");
    this.currentOdo = this.page.locator(
      'xpath=//label[contains(.,"Current Odo")]/..//div',
    );
    this.btnOK = this.page.locator('button:text-is("OK")');
    this.btnGoBack = this.page.locator('a:text-is("Go Back")');
    this.btnPerformCostCentreTransfer = this.page.locator(
      '[data-original-title="Perform Cost Centre Transfer"]',
    );
    this.currentCostCentre = this.page
      .locator('xpath=//label[contains(.,"Cost Centre")]/..//div')
      .first();
    this.selectCostCentreNewLocation = this.page.locator(
      "#SelectedCostCentreID",
    );
    this.btnCostCentreTransferApply = this.page.locator("#TransferButton");
    this.btnSubmitOdoReading = this.page.locator(
      '[data-original-title="Submit Odo Reading"]',
    );
    this.btnSubmitChanges = this.page.locator("#SubmitButton");
    this.lastOdoReading = this.page.locator(
      'xpath=//label[contains(.,"Last Reading Recorded")]/..//div',
    );
    this.selectCostCentreNewLocations = this.page.locator(
      ".select2-results__option",
    );
    this.btnUpdateVehicleDetails = this.page.locator(
      '[data-original-title="Update Vehicle Details"]',
    );
    this.dropdownVehicleCategory = this.page.locator(
      "#SecondaryVehicleCategory",
    );
    this.dropdownVehiclePurpose = this.page.locator("#VehiclePurpose");
    this.dropdownVehicleRole = this.page.locator("#VehicleRole");
  }

  async clickFirstDriverResult(driver: string) {
    await this.page.locator(`a:text-is("${driver}")`).first().click();
  }
}
