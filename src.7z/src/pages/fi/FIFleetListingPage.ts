import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIFleetListingPage extends BasePage {
  readonly loadingDataTable: Locator;
  readonly tdRegistrationValues: Locator; //multiple
  readonly searchRego: Locator;
  readonly btnSearchRego: Locator;
  readonly firstSearchResult: Locator;
  readonly summaryRegoValue: Locator;
  readonly acccessoriesHeading: Locator;
  readonly inputFileAttachment: Locator;
  readonly reportResults: Locator;
  readonly btnExcel: Locator;
  readonly btnPDF: Locator;
  readonly btnCSV: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.loadingDataTable = this.page.locator("#divLoadingDataTable div");
    this.tdRegistrationValues = this.page
      .locator("#reportTableColumns")
      .locator("tbody a");
    this.searchRego = this.page.locator("#RowSearch");
    this.btnSearchRego = this.page.locator("#SubmitButton");
    this.firstSearchResult = this.page
      .locator("#reportTableColumns span")
      .first();
    this.summaryRegoValue = this.page
      .locator('xpath=//label[contains(.,"Registration")]/..//span')
      .first();
    this.acccessoriesHeading = this.page.locator("#accHeading");
    this.inputFileAttachment = this.page.locator("#file");
    this.reportResults = this.page.locator("#reportResults");
    this.btnExcel = this.page.locator("#btnExportXLSX");
    this.btnPDF = this.page.locator("#btnExportPDF");
    this.btnCSV = this.page.locator("#btnExportCSV");
  }

  async getRegoLinkLocator(rego: string) {
    return this.page
      .locator("#reportTableColumns")
      .locator('tbody a:text-is("' + rego + '")');
  }

  async clickRego(rego: string) {
    await this.page.locator(`a :text-is("${rego}")`).first().click();
  }
}
