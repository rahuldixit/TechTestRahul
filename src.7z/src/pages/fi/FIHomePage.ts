import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";
import { faker } from "@faker-js/faker";

export class FIHomePage extends BasePage {
  readonly homePageLogo: Locator;
  readonly costcentreDropdown: Locator;
  readonly searchBox: Locator;
  readonly searchIcon: Locator;
  readonly widgetSpinner: Locator;
  readonly menuProfile: Locator;

  //For Fleet Manager
  readonly serviceDueWidget: Locator;
  readonly serviceOverdueWidget: Locator;
  readonly manufacturerRecallsByModel: Locator;
  readonly tripsWidget: Locator;
  readonly driverBehaviourWidget: Locator;
  readonly fleetSizeByProductWidget: Locator;
  readonly fuelCardSummaryWidget: Locator;
  readonly projectUtilisationByDistanceWidget: Locator;
  readonly replacementsDueWidget: Locator;
  readonly vehiclesDueForDeliveryWidget: Locator;
  readonly fleetWatchListWidget: Locator;
  readonly incidentVolumeWidget: Locator;
  readonly latestANCAPNewsWidget: Locator;
  readonly latestCarStoriesWidget: Locator;
  readonly totalRepairCostwidget: Locator;
  readonly electricityChargerActivityReportWidget: Locator;
  readonly electricityReportWidget: Locator;
  readonly processManagerSummaryWidget: Locator;

  //For ND
  readonly yourVehicleWidget: Locator;
  readonly kmTrackerWidget: Locator;
  readonly servicingDetailsWidget: Locator;
  readonly fuelEfficiencyWidget: Locator;
  readonly balanceSummaryWidget: Locator;
  readonly comprehensiveInsuranceDetailsWidget: Locator;

  readonly searchedVehicleResults: Locator;
  readonly vehiclesDetailsHeader: Locator;
  readonly activities: Locator;
  readonly reports: Locator;
  readonly btnCreateNew: Locator;
  readonly newQuotationHeader: Locator;
  readonly quoteSearchField: Locator;
  readonly preferredDeliveryDate: Locator;
  readonly postcode: Locator;
  readonly contractKMS: Locator;

  //For NVB Employee
  readonly menuChangeRole: Locator;
  readonly nvbProductSummaryWidget: Locator;
  readonly nvbTransactionsWidget: Locator;
  readonly firstProductDescFromNvbProductSummaryWidget: Locator;
  readonly firstRegistrationInYourVehicleWidget: Locator;

  //For Search Registration Function
  readonly regoNumbers: Locator;

  //Odo Reading (Submit Odo Reading dialog)
  readonly dropdownShowingDataFor: Locator;
  readonly headingSubmitOdoReading: Locator;
  readonly registrationValueInSubmitOdo: Locator;
  readonly valueLastReadingRecorded: Locator;
  readonly fieldNewReading: Locator;
  readonly btnSubmitOdo: Locator;
  readonly submitOdoError: Locator;
  readonly valueLastReadingKm: Locator; // in the KM Tracker widget on home page
  readonly odoSpinner: Locator;
  readonly btnX: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.homePageLogo = this.page.locator("#logo2large");
    this.costcentreDropdown = this.page.locator("a.changecostcentre");
    this.searchBox = this.page.locator("input#search");
    this.searchIcon = this.page.locator(
      "[class*=navbar-search] .icon-search.icon-white",
    );
    this.widgetSpinner = this.page.locator(".spinner");
    this.menuProfile = this.page.locator(".profile");

    //For Fleet manager - Please add new if any
    this.serviceDueWidget = this.page.locator("#DueOverdueWidget");
    this.serviceOverdueWidget = this.page.locator("#OverdueWidget");
    this.manufacturerRecallsByModel = this.page.locator(
      "#ManufacturerRecallsByModelWidget",
    );
    this.tripsWidget = this.page.locator("#TripSummaryWidget");
    this.driverBehaviourWidget = this.page.locator(
      "#driverPerformanceContainer",
    );
    this.fleetSizeByProductWidget = this.page.locator(
      "#LeaseByLeaseFleetWidget",
    );
    this.fuelCardSummaryWidget = this.page.locator(
      "#FuelcardSummaryBySupplier",
    );
    this.projectUtilisationByDistanceWidget = this.page.locator(
      "#VehicleUtilizationWidget",
    );
    this.replacementsDueWidget = this.page.locator("#ReplDueOverdueWidget");
    this.vehiclesDueForDeliveryWidget = this.page.locator(
      "#OrderSummaryWidget",
    );
    this.fleetWatchListWidget = this.page.locator("#FleetWatchListWidget");
    this.incidentVolumeWidget = this.page.locator("#IncidentVolumeWidget");
    this.latestANCAPNewsWidget = this.page.locator(
      ".largeData.RssWidget.RssFleet",
    );
    this.latestCarStoriesWidget = this.page
      .locator(".largeData.RssWidget")
      .last();
    this.totalRepairCostwidget = this.page.locator("#TotalRepairCostWidget");
    this.electricityChargerActivityReportWidget = this.page.locator(
      "#ElectricityChargerActivityReport",
    );
    this.electricityReportWidget = this.page.locator("#ElectricityReport");
    this.processManagerSummaryWidget = this.page.locator(
      "#ProcessManagerSummaryWidget",
    );

    //For ND - Please add new if any
    this.yourVehicleWidget = this.page.locator("div.WidgetTable table").first();
    this.kmTrackerWidget = this.page.locator(".well.fbtTrackerSummary");
    this.servicingDetailsWidget = this.page.locator("#ServicingDetailsWidget");
    this.fuelEfficiencyWidget = this.page.locator("#FuelEfficencyWidget");
    this.balanceSummaryWidget = this.page.locator(".balanceSummary");
    this.comprehensiveInsuranceDetailsWidget = this.page.locator(
      "#driverInsuranceDetailsContainer",
    );

    this.searchedVehicleResults = this.page.locator("div#searchedVehicleList");
    this.vehiclesDetailsHeader = this.page.locator(
      'h3:has-text("Vehicle Details")',
    );
    this.activities = this.page.locator('a:has-text("Activities")');
    this.reports = this.page.locator('a:text-is("Reports")');
    this.btnCreateNew = this.page.locator("#CreateNew");
    this.newQuotationHeader = this.page.locator('h3:has-text("New Quotation")');
    this.quoteSearchField = this.page.locator(".select2-search__field");
    this.contractKMS = this.page.locator("ContractKms");
    this.preferredDeliveryDate = this.page.locator("#DeliveryDate");
    this.postcode = this.page.locator("#Postcode");

    //For NVB Employee
    this.menuChangeRole = this.page.locator(".changerole");
    this.nvbProductSummaryWidget = this.page
      .locator('form:has(>.WidgetHeader:text-is("NVB Product Summary"))')
      .locator("table.largeData");
    this.nvbTransactionsWidget = this.page
      .locator('form:has(>.WidgetHeader:text-is("NVB Transactions"))')
      .locator("table.largeData");
    this.firstProductDescFromNvbProductSummaryWidget = this.page
      .locator('form:has(>.WidgetHeader:text-is("NVB Product Summary"))')
      .locator("table.largeData tr")
      .nth(1)
      .locator("td")
      .nth(1);

    //For Autopak Driver
    this.firstRegistrationInYourVehicleWidget = this.page
      .locator('form:has(>.WidgetHeader:text-is("Your Vehicle(s)"))')
      .locator("table.largeData tr")
      .nth(1)
      .locator("td")
      .nth(1);

    //For Search Function
    this.regoNumbers = this.page.locator("td>[class=driverPerformanceVehicle]"); // multiple

    //Odo Reading
    this.dropdownShowingDataFor = this.page.locator(
      '.dropdown-toggle:text-is("Showing data for: ")',
    );
    this.headingSubmitOdoReading = this.page.locator(
      'h2:text-is("Submit Odometer Reading")',
    );
    this.registrationValueInSubmitOdo = this.page.locator("#Registration");
    this.valueLastReadingRecorded = this.page.locator(
      ":has(>[for=PreviousOdoReading]) span",
    );
    this.fieldNewReading = this.page.getByLabel("New Reading", { exact: true });
    this.btnSubmitOdo = this.page.locator("#submitOdo");
    this.submitOdoError = this.page.locator("#SubmitOdoError");
    this.valueLastReadingKm = this.page
      .locator('[class="well fbtTrackerHistory"]')
      .locator('td:has-text("Last Reading")~td');
    this.odoSpinner = this.page.locator("#odoSpinner");
    this.btnX = this.page.getByRole("button", { name: "×" });
  }

  async selectCostCentreByName(costCentre: string) {
    await this.page
      .locator("ul.dropdown-menu-contained.long li a")
      .filter({ hasText: costCentre })
      .click();
  }

  async selectVehicleByRegistrationID(regID: string) {
    await this.page
      .locator("#outerTable tbody td a")
      .filter({ hasText: regID })
      .click();
  }

  //Select the Activity Menu, then the given sub-menu
  async selectActivityByName(activityname: string) {
    await this.activities.waitFor({ timeout: 30000 });
    await this.activities.click();
    await this.page
      .locator(`[class="dropdown open"] li :text-is("${activityname}")`)
      .click();
  }

  //Select the Reports Menu, then the given sub-menu
  async selectReportByName(reportName: string) {
    await this.reports.waitFor({ timeout: 30000 });
    await this.reports.click();
    await this.page
      .locator(`[class="dropdown open"] li :text-is("${reportName}")`)
      .click();
  }

  //Select the Profile menu, then the given sub-menu
  async selectOptionFromDropdown(option: string) {
    await this.menuProfile.waitFor({ timeout: 10000 });
    await this.menuProfile.click();
    await this.page
      .locator(".dropdown-menu-contained li a")
      .getByText(option)
      .click();
  }

  async selectCostCentreForNewQuotation(costcentrenumber: string) {
    await this.page.locator("div.selectize-input input").type(costcentrenumber);
    await this.page
      .locator("div.selectize-dropdown-content  span")
      .first()
      .click();
  }

  //select the given option, if none given, count the options and select a random option
  async selectQuoteTemplateByValue(quotevalue?: string) {
    const label = "Template";
    const dropDownMenu = this.page.locator("select#" + label);
    if (!quotevalue) {
      // load menu in order to count the options
      await dropDownMenu.click();
      await dropDownMenu.selectOption({ index: 0 });
      const range = await dropDownMenu.locator("option").count();
      await dropDownMenu.selectOption({
        index: faker.number.int({ min: 1, max: range - 1 }),
      });
      this.clickOut("Quote Template");
    } else {
      await dropDownMenu.selectOption(quotevalue);
    }
  }

  //select the given option, if none given, count the options and select a random option
  async selectMakeByName(make?: string) {
    const label = "Make";
    const dropDownMenu = this.page.locator("select#" + label);
    (await this.quoteDetailsSelector(label)).click();
    if (!make) {
      await dropDownMenu.selectOption({ index: 0 });
      const range = await dropDownMenu.locator("option").count();
      await dropDownMenu.selectOption({
        index: faker.number.int({ min: 1, max: range - 1 }),
      });
      this.clickOut(label);
    } else {
      await this.quoteSearchField.type(make);
      await this.page.locator("#select2-Make-results li").click();
    }
  }

  //select the given option, if none given, count the options and select a random option
  async selectModelByName(model?: string) {
    const label = "Model";
    const dropDownMenu = this.page.locator("select#" + label);
    (await this.quoteDetailsSelector(label)).click();
    if (!model) {
      await dropDownMenu.selectOption({ index: 0 });
      const range = await dropDownMenu.locator("option").count();
      await dropDownMenu.selectOption({
        index: faker.number.int({ min: 1, max: range - 1 }),
      });
      this.clickOut(label);
    } else {
      await this.quoteSearchField.type(model);
      await this.page.locator("#select2-Model-results li").click();
    }
  }

  //select the given option, if none given, count the options and select a random option
  async selectDerivativeByValue(derivativevalue?: string) {
    const label = "Derivative";
    const dropDownMenu = this.page.locator("select#" + label);
    (await this.quoteDetailsSelector(label)).click();
    if (!derivativevalue) {
      await dropDownMenu.selectOption({ index: 0 });
      const range = await dropDownMenu.locator("option").count();
      await dropDownMenu.selectOption({
        index: faker.number.int({ min: 1, max: range - 1 }),
      });
      this.clickOut(label);
    } else {
      await this.quoteSearchField.type(derivativevalue);
      await this.page.locator("#select2-Derivative-results li").click();
    }
  }

  //select the down arrow for the dropdown field
  async quoteDetailsSelector(label: string) {
    return this.page
      .locator("[aria-labelledby*=select2-" + label + "]")
      .locator(".select2-selection__arrow");
  }

  //On Home page, select random Registration Number that appears on screen
  async getRandomRegoFromDriverBehaviourWidget() {
    return await this.regoNumbers.nth(faker.number.int({ max: 9 })).innerText();
  }

  //After searching a registration number, click the link in the results
  async clickRegoSearchResultLink(rego: string) {
    const link = this.page.getByRole("link", { name: rego });
    await link.waitFor({ timeout: 90000 });
    await link.click();
  }

  // click out of a field, by clicking on a given label. Text will be matched exactly
  async clickOut(label: string) {
    await this.page.locator('label:text-is("' + label + '")').click();
  }

  async getRegoFromVehicle() {
    await this.page.waitForLoadState("networkidle");
    if (await this.yourVehicleWidget.isEnabled()) {
      const rego = await this.firstRegistrationInYourVehicleWidget.innerText();
      return rego;
    }
  }

  //Get request type from the drop-down menu called "Showing Data For:"
  async getRequestFromShowingDataFor() {
    if (await this.dropdownShowingDataFor.isVisible()) {
      const data = await this.dropdownShowingDataFor.innerText();
      const requestType = data.split(": ")[1];
      return requestType;
    }
    return await this.firstProductDescFromNvbProductSummaryWidget.innerText();
  }

  /*NVB Employee: Select role in the Change Role drop-down at the top of the page
   Example values for role: "NVB Employee" or "Driver"
  */
  async changeRoleFromTopMenu(role: string) {
    await this.menuChangeRole.click();
    await this.page
      .locator("li:has(>.changerole)")
      .locator('li a:has-text("' + role + '")')
      .click();
  }

  async selectNVBProduct(product: string) {
    await this.dropdownShowingDataFor.click();
    await this.page
      .locator(`[class="dropdown open"] li :text-is("${product}")`)
      .click();
  }
}
