import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FILogbookPage extends BasePage {
  readonly headingMotorVehicleRunningSheet: Locator;
  readonly fieldSearchRegistration: Locator;
  readonly dropdownSelectFBTYear: Locator;
  readonly btnEdit: Locator;
  readonly btnStopEditing: Locator;
  readonly btnSave: Locator;
  readonly successMessage: Locator; // only appears for a few seconds

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headingMotorVehicleRunningSheet = this.page.locator(
      'h2:text-is("Motor Vehicle Running Sheet")',
    );
    this.fieldSearchRegistration = this.page.getByRole("textbox", {
      name: "Search Registration",
    });
    this.dropdownSelectFBTYear = this.page.locator("#FBTYear");
    this.btnEdit = this.page.getByRole("button", { name: "Edit" });
    this.btnStopEditing = this.page.getByRole("button", {
      name: "Stop Editing",
    });
    this.btnSave = this.page.getByRole("button", { name: "Save" });
    this.successMessage = this.page.locator("#successMessage");
  }

  // Enter a value into the Trip Summary table.
  // First Row has index 1. First Column has index 0
  async enterValueInTripSummaryTable(
    value: string,
    row: number,
    column: number,
  ) {
    if (row === 0) {
      row = 1;
    }
    const inputCell = this.page
      .getByRole("row")
      .nth(row)
      .getByRole("cell")
      .nth(column)
      .locator("input");
    inputCell.clear();
    inputCell.fill(value);
    // go slowly, because some values don't save correctly
    await this.page.waitForTimeout(100);
  }

  // First Row has index 1
  async clickClearBtn(row: number) {
    await this.page.getByRole("row").nth(row).getByRole("button").click();
  }

  // First Row has index 1
  async getValueInTripSummaryTable(row: number, column: number) {
    return await this.page
      .getByRole("row")
      .nth(row)
      .getByRole("cell")
      .nth(column)
      .locator("span")
      .innerText();
  }

  async selectFirstResultInAutoComplete() {
    await this.page.locator(".ui-autocomplete>li>a").first().click();
  }
}
