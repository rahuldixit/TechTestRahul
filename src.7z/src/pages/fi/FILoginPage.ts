import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FILoginPage extends BasePage {
  readonly loginPageHeader: Locator;
  readonly usernameFI: Locator;
  readonly btnNext: Locator;
  readonly passwordFI: Locator;
  readonly btnLogin: Locator;
  readonly btnCancel: Locator;
  readonly resetPasswordLink: Locator;

  constructor(page: Page) {
    super(page);
    this.loginPageHeader = this.page.locator("#login-panel-title");
    this.usernameFI = this.page.locator("#Username");
    this.btnNext = this.page.locator("#button-next");
    this.passwordFI = this.page.locator("#Password");
    this.btnLogin = this.page.locator('button:has-text("Login")');
    this.btnCancel = this.page.locator(".btn.btn-default");
    this.resetPasswordLink = this.page.locator(".form-group a");
  }

  async openFI(url: string) {
    await this.page.goto(url);
  }
}
