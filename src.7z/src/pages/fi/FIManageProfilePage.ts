import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIManageProfilePage extends BasePage {
  readonly headerManageProfile: Locator;

  //Driver and NVB Employee
  readonly headerBankAccountDetails: Locator;
  readonly checkBoxEditBankAccount: Locator;
  readonly checkboxEditAddress: Locator;
  readonly fieldAccountName: Locator;
  readonly fieldAccountNumber: Locator;
  readonly fieldBsbFirstTriplet: Locator;
  readonly fieldBsbSecondTriplet: Locator;
  readonly textValueBank: Locator;
  readonly headerResidentialAddress: Locator;
  readonly fieldResidentialStreet: Locator;
  readonly fieldResidentialSuburb: Locator;
  readonly fieldResidentialPostCode: Locator;
  readonly fieldResidentialState: Locator;
  readonly fieldResidentialMobileNum: Locator;

  //Autopak Driver
  readonly headerMailAddress: Locator;
  readonly checkBoxSameAsResidentialAddr: Locator;
  readonly fieldMailStreet: Locator;
  readonly fieldMailSuburb: Locator;
  readonly fieldMailPostCode: Locator;
  readonly fieldMailState: Locator;

  //Ts And Cs
  readonly checkboxAuthorizeDebit: Locator;
  readonly checkboxAcknowledgePersonalInfo: Locator;
  readonly btnSave: Locator;
  readonly alertFinishedProcessing: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headerManageProfile = this.page.locator(
      'h2:text-is("Manage Profile")',
    );

    //Driver and NVB Employee
    this.headerBankAccountDetails = this.page.locator(
      'legend:text-is("Bank Account Details")',
    );
    this.checkBoxEditBankAccount = this.page.locator(
      'xpath=//label[contains(.,"Edit Bank Account")]/..//input[@data-val="true"]',
    );
    this.checkboxEditAddress = this.page.locator("#EditAddressDetails");
    this.fieldAccountName = this.page.getByLabel("Account Name");
    this.fieldAccountNumber = this.page.getByLabel("Account Number");
    this.fieldBsbFirstTriplet = this.page.locator(
      "[id*=Profile_Bsb_FirstTriplet]",
    );
    this.fieldBsbSecondTriplet = this.page.locator(
      "[id*=Profile_Bsb_SecondTriplet]",
    );
    this.textValueBank = this.page.locator("#FinancialInstitutionLabel");
    this.headerResidentialAddress = this.page.locator(
      'legend:text-is("Residential Address")',
    );
    this.fieldResidentialStreet = this.page.locator(
      "[id*=Profile_Address_Street]",
    );
    this.fieldResidentialSuburb = this.page.locator(
      "[id*=Profile_Address_Suburb]",
    );
    this.fieldResidentialPostCode = this.page.locator(
      "[id*=Profile_Address_PostCode]",
    );
    this.fieldResidentialState = this.page.locator(
      "[id*=Profile_Address_State]",
    );
    this.fieldResidentialMobileNum = this.page.locator(
      "[id*=Profile_Address_Mobile]",
    );

    //Autopak Driver
    this.headerMailAddress = this.page.locator(
      'legend:text-is("Mail Address")',
    );
    this.checkBoxSameAsResidentialAddr = this.page.getByLabel(
      "Same as Residential Address",
    );
    this.fieldMailStreet = this.page.locator(
      "[id*=Profile_MailAddress_Street]",
    );
    this.fieldMailSuburb = this.page.locator(
      "[id*=Profile_MailAddress_Suburb]",
    );
    this.fieldMailPostCode = this.page.locator(
      "[id*=Profile_MailAddress_PostCode]",
    );
    this.fieldMailState = this.page.locator("[id*=Profile_MailAddress_State]");

    this.checkboxAuthorizeDebit = this.page.locator("#AuthorizeToDebitChkBox");
    this.checkboxAcknowledgePersonalInfo = this.page.locator(
      "#AcknowledgeProvidingInfoChkBox",
    );
    this.btnSave = this.page.locator("#ManageProfileSubmitButton");
    this.alertFinishedProcessing = this.page.locator("[class*=alert]");
  }
}
