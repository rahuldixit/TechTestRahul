import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIProcessManager extends BasePage {
  readonly fromDate: Locator;
  readonly toDate: Locator;
  readonly btnSearch: Locator;
  readonly selectStatus: Locator;
  readonly resultsTable: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.fromDate = this.page.locator("#fromDate");
    this.toDate = this.page.locator("#toDate");
    this.btnSearch = this.page.locator("#SearchButton");
    this.selectStatus = this.page.locator("#status");
    this.resultsTable = this.page.locator("#outerTable");
  }
}
