import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIQuotationPage extends BasePage {
  // Quotation page
  readonly btnCreateNew: Locator;

  // New Quotation page
  readonly labelCostCentre: Locator;
  readonly labelContractTerm: Locator;
  readonly labelServicesEstablishmentFee: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    // Quotation page
    this.btnCreateNew = this.page.locator("#CreateNew");

    // New Quotation page
    this.labelCostCentre = this.page.getByText("Cost Centre", { exact: true });
    this.labelContractTerm = this.page.getByText("Contract Term");
    this.labelServicesEstablishmentFee = this.page
      .locator('td:text-is("Establishment Fee")')
      .first();
  }
}
