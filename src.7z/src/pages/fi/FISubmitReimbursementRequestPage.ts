import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

/*
This page appears for Novated Driver, Autopak Driver and NVB Employee
Novated Driver: Activities > Submit Reimbursement Request
NVB Employee: Activities > Submit Reimbursement Request
Autopak Driver: Activities > Request Reimbursement or Direct Payment
*/
export class FISubmitReimbursementRequestPage extends BasePage {
  readonly headingSubmitReimbursement: Locator;
  readonly headingAccountBalance: Locator;
  readonly headingReimbursementDetails: Locator;
  readonly headingDeclaration: Locator;

  //Novated Driver
  readonly inputRegistrationNovated: Locator;
  readonly inputFuel: Locator;
  readonly inputMaintenanceNovated: Locator;
  readonly inputInsurance: Locator;
  readonly inputInsuranceExcess: Locator;
  readonly inputNSWCtp: Locator;
  readonly uploadRegistrationPDF: Locator;
  readonly uploadFuelPDF: Locator;
  readonly uploadMaintenancePDF: Locator;
  readonly uploadInsurancePDF: Locator;
  readonly uploadInsuranceExcessPDF: Locator;
  readonly uploadNSWCtpPDF: Locator;
  readonly textReimbursementCompleteMessage: Locator;
  readonly textRegistrationFileError: Locator;
  readonly textFuelFileError: Locator;
  readonly textMaintenanceFileError: Locator;
  readonly textInsuranceFileError: Locator;
  readonly textInsuranceExcessFileError: Locator;
  readonly textNSWCtpFileError: Locator;

  //NVB Employee
  readonly headingPleasefillInTheTotals: Locator;
  readonly textYourAvailableBalance: Locator;

  //Autopak Driver
  readonly headingExpeseReimbursementOrDirectpayment: Locator;
  readonly headingOtherRunningCostExpenses: Locator;

  readonly inputRegistration: Locator;
  readonly inputCtp: Locator;
  readonly inputAutoClubMembership: Locator;
  readonly inputComprehensiveInsurance: Locator;
  readonly inputFuelPurchase: Locator;
  readonly inputMaintenance: Locator;
  readonly inputOtherExpenses: Locator;
  readonly checkboxReimbursementDeclaration: Locator;
  readonly uploadReimbursementPDF: Locator;
  readonly btnSubmit: Locator;
  readonly linkHere: Locator;
  readonly tableReimbursement: Locator;
  readonly cellReimbursementTotal: Locator;
  readonly textClaimCompletion: Locator;
  readonly inputComments: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.headingSubmitReimbursement = this.page.locator(
      'h3:has-text("Submit Reimbursement Request")',
    );
    this.headingDeclaration = this.page.locator(
      'legend:has-text("Declaration")',
    );

    //Novated Driver
    this.headingAccountBalance = this.page.locator(
      'legend:has-text("Account Balance")',
    );
    this.headingReimbursementDetails = this.page.locator(
      'legend:has-text("Reimbursements Details")',
    );
    this.textYourAvailableBalance = this.page.locator(
      'p:text-is("Your available balance is ") strong',
    );
    this.inputRegistrationNovated = this.page.locator("#RegistrationExpense");
    this.inputFuel = this.page.locator("#FuelExpense");
    this.inputMaintenanceNovated = this.page.locator("#MaintenanceExpense");
    this.inputInsurance = this.page.locator("#InsuranceExpense");
    this.inputInsuranceExcess = this.page.locator("#InsuranceExcessExpense");
    this.inputNSWCtp = this.page.locator("#NswCTPExpense");
    this.uploadRegistrationPDF = this.page.locator("#fileRegistrationExpense");
    this.uploadFuelPDF = this.page.locator("#fileFuelExpense");
    this.uploadMaintenancePDF = this.page.locator("#fileMaintenanceExpense");
    this.uploadInsurancePDF = this.page.locator("#fileInsuranceExpense");
    this.uploadInsuranceExcessPDF = this.page.locator(
      "#fileInsuranceExcessExpense",
    );
    this.uploadNSWCtpPDF = this.page.locator("#fileNswCTPExpense");
    this.textReimbursementCompleteMessage = this.page.locator(
      'legend:has-text("Reimbursement Request Submitted for")',
    );
    this.textRegistrationFileError = this.page.locator(
      "#fileRegistrationExpense_error",
    );
    this.textFuelFileError = this.page.locator("#fileFuelExpense_error");
    this.textMaintenanceFileError = this.page.locator(
      "#fileMaintenanceExpense_error",
    );
    this.textInsuranceFileError = this.page.locator(
      "#fileInsuranceExpense_error",
    );
    this.textInsuranceExcessFileError = this.page.locator(
      "#fileInsuranceExcessExpense_error",
    );
    this.textNSWCtpFileError = this.page.locator("#fileNswCTPExpense_error");

    //NVB Employee
    this.headingPleasefillInTheTotals = this.page.locator(
      'legend:has-text("Please fill in the totals for reimbursement")',
    );

    //Autopak Driver
    this.headingExpeseReimbursementOrDirectpayment = this.page.locator(
      'legend:has-text("Expense Reimbursements or Direct Payment")',
    );
    this.headingOtherRunningCostExpenses = this.page.locator(
      'legend:has-text("Other Running Cost Expenses")',
    );

    this.inputRegistration = this.page.locator("#RegistrationExpense_Amount");
    this.inputCtp = this.page.locator("#CTPExpense_Amount");
    this.inputAutoClubMembership = this.page.locator(
      "#AutoClubMembershipExpense_Amount",
    );
    this.inputComprehensiveInsurance = this.page.locator(
      "#ComprehensiveInsuranceExpense_Amount",
    );
    this.inputFuelPurchase = this.page.locator("#FuelExpense_Amount");
    this.inputMaintenance = this.page.locator("#MaintenanceExpense_Amount");
    this.inputOtherExpenses = this.page.locator("#OtherExpense_Amount");
    this.checkboxReimbursementDeclaration = this.page.locator(
      "#aceeptReimbursementDeclaration",
    );
    this.uploadReimbursementPDF = this.page.locator("#file");
    this.btnSubmit = this.page.locator("#SubmitButton");
    this.linkHere = this.page.locator('a:text-is("here")');
    this.tableReimbursement = this.page.locator("#outerTable");
    this.cellReimbursementTotal = this.tableReimbursement
      .locator("xpath=//tbody[1]/tr/td")
      .last();
    this.textClaimCompletion = this.page.locator("#content .container");
    this.inputComments = this.page.locator("#Comments");
  }

  async getLastItem(date: string) {
    return this.tableReimbursement.locator(`:text-is("${date}")`).last();
  }

  async getLastEntryCellData(row: number, cell: number) {
    const rows = await this.tableReimbursement
      .locator("xpath=//tbody[1]/tr")
      .all();
    const rowElement = rows[rows.length - 8 + row];
    return (await rowElement.locator("td").nth(cell).innerText())
      .replace("$", "")
      .replace(",", "")
      .trim();
  }
}
