import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FITermsConditionsPage extends BasePage {
  readonly agreeTCs: Locator;
  readonly btnProceed: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.agreeTCs = this.page.locator("input#AgreeTnC");
    this.btnProceed = this.page.locator(".btn-primary");
  }
}
