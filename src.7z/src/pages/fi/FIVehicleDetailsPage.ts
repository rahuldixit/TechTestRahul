import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class FIVehicleDetailsPage extends BasePage {
  readonly vehicleDetailsHeading: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.vehicleDetailsHeading = this.page.getByRole("heading", {
      name: "Vehicle Details",
    });
  }

  async getRegoValue() {
    return await this.page
      .locator("#Summary")
      .locator("[class=control-group]")
      .locator("span")
      .innerText();
  }
}
