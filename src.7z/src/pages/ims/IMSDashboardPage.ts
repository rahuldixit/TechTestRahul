import { FrameLocator, Locator, Page } from "@playwright/test";
import { SuperPage } from "../common/SuperPage";

export class IMSDashboardPage extends SuperPage {
  readonly btnCreate: Locator;
  readonly issueTable: Locator;
  readonly createIssueDialog: Locator;
  readonly selectLeadTypeNewOpp: Locator;
  readonly selectLeadTypeEndOfTermOpp: Locator;
  readonly typeCRM: Locator;
  readonly selectCRM: Locator;
  readonly selectTitle: Locator;
  readonly firstName: Locator;
  readonly surName: Locator;
  readonly mobileNum: Locator;
  readonly contactEmail: Locator;
  readonly postcode: Locator;
  readonly selectLeadSource: Locator;
  readonly assignToMe: Locator;
  readonly contractRef: Locator;
  readonly descriptionFrame: FrameLocator;
  readonly descriptionBox: Locator;
  readonly btnSubmitIssue: Locator;
  readonly selectNewIssue: Locator;
  readonly spinner: Locator;
  readonly fileAttachedMsg: Locator;
  readonly fileUploadError: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnCreate = this.page.locator("a#create_link");
    this.issueTable = this.page.locator(".issue-table").first();
    this.createIssueDialog = this.page.locator("#create-issue-dialog");
    this.selectLeadTypeNewOpp = this.page.locator(
      "label[for='customfield_10133-1']",
    );
    this.selectLeadTypeEndOfTermOpp = this.page.locator(
      "label[for='customfield_10133-2']",
    );
    this.typeCRM = this.page.locator("input#react-select-2-input");
    this.selectCRM = this.page.locator(".connect-react-select__option");
    this.selectTitle = this.page.locator("select#customfield_23960");
    this.firstName = this.page.locator("input#customfield_23961");
    this.surName = this.page.locator("input#customfield_23962");
    this.mobileNum = this.page.locator("input#customfield_12660");
    this.contactEmail = this.page.locator("input#customfield_10140");
    this.postcode = this.page.locator("input#customfield_20395");
    this.selectLeadSource = this.page.locator("select#customfield_10131");
    this.assignToMe = this.page.locator("button#assign-to-me-trigger");
    this.contractRef = this.page.locator("input#customfield_23963");
    this.descriptionFrame = this.page.frameLocator(".cke_wysiwyg_frame");
    this.descriptionBox = this.descriptionFrame.locator("body.cke_editable");
    this.btnSubmitIssue = this.page.locator("input#create-issue-submit");
    this.selectNewIssue = this.page.locator("a.issue-created-key.issue-link");
    this.spinner = this.page.locator(".aui-spinner.spinner");
    this.fileAttachedMsg = this.page.getByText(
      "has been attached successfully to this issue.",
    );
    this.fileUploadError = this.page.locator(
      ".upload-progress-bar__error-message",
    );
  }

  async selectCRMFromDropdown(customerName: string) {
    await this.typeCRM.fill(customerName);
    await this.page.waitForSelector(".connect-react-select__menu", {
      timeout: 10000,
    });
    await this.selectCRM.filter({ hasText: customerName }).first().click();
  }

  async selectCreatedIssue() {
    await this.selectNewIssue.isVisible();
    await this.selectNewIssue.click({ timeout: 20000 });
  }

  async waitFor() {
    await this.btnCreate.waitFor();
  }
}
