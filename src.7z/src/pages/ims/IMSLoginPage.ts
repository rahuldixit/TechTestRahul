import { Page, Locator } from "@playwright/test";
import { SuperPage } from "../common/SuperPage";

export class IMSLoginPage extends SuperPage {
  readonly imsUsername: Locator;
  readonly imsPassword: Locator;
  readonly imsLogInButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.imsUsername = this.page.locator('input[name="os_username"]');
    this.imsPassword = this.page.locator('input[name="os_password"]');
    this.imsLogInButton = this.page.locator("#login-form-submit");
  }

  async openIMS(url: string) {
    await this.page.goto(url, { timeout: 70000 });
  }
}
