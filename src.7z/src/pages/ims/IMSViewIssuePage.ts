import { Locator, Page } from "@playwright/test";
import { SuperPage } from "../common/SuperPage";

export class IMSViewIssuePage extends SuperPage {
  readonly pageHeader: Locator;
  readonly issueLink: Locator;
  readonly quoteLink: Locator;
  readonly creditAppLink: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.pageHeader = this.page.locator("h1#summary-val");
    this.issueLink = this.page.locator("a.issue-link");
    this.quoteLink = this.page.locator("div.je_rdata_container.je_html a");
    this.creditAppLink = this.page.locator("div.je_rdata_container.je_wiki");
  }

  async clickOnQuoteLink() {
    await this.quoteLink.last().click();
  }

  async clickOnCreditAppLink() {
    return await this.creditAppLink.first().click();
  }

  async waitFor() {
    await this.pageHeader.waitFor();
  }
}
