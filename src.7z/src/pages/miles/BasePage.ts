import { Locator, Page } from "@playwright/test";
import { SuperPage } from "pages/common/SuperPage";

export class BasePage extends SuperPage {
  readonly loadingSpinner: Locator;
  readonly progressLoader: Locator;
  readonly quickNavigation: Locator;
  readonly btnClose: Locator; // close button on System Error dialog
  readonly btnOK: Locator; // OK button on dialog
  readonly btnCancel: Locator;
  readonly btnMsgCollapser: Locator;
  readonly btnMsgCollapserContractModifactionPopup: Locator;
  readonly homeTab: Locator;
  readonly systemErrorMsg: Locator;
  readonly collapserErrorMsgs: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.loadingSpinner = this.page.locator(".loadingIndicator");
    this.progressLoader = this.page.locator(".progress");
    this.quickNavigation = this.page.locator(
      "input#sofid_id_quicknavigation_field",
    );
    this.btnClose = this.page
      .getByLabel("Close", { exact: true })
      .locator("visible=true");
    this.btnMsgCollapser = this.page
      .locator('[eventproxy*="button_msgcollapser"]')
      .locator("visible=true")
      .locator("img");
    this.btnMsgCollapserContractModifactionPopup = this.page
      .locator("[eventproxy*=ContractModificationPopup]")
      .locator('[eventproxy*="button_msgcollapser"]')
      .locator("visible=true")
      .locator("img");
    this.btnOK = this.page
      .locator("[class*=Button],[class*=button]")
      .locator(':text-is("OK")')
      .locator("visible=true")
      .last();
    this.btnCancel = this.page
      .getByLabel("Cancel", { exact: true })
      .locator("visible=true");
    this.homeTab = this.page.locator(".tabButtonBottom").first();
    this.systemErrorMsg = this.page
      .locator(".messageWindowError")
      .locator("div");
    // There can be multiple Error Messages in the Collapser
    this.collapserErrorMsgs = this.page
      .locator("[class*=messageGridError] a")
      .locator("visible=true");
  }

  //Type requestID in quick navigation and select the value from dropdown
  async enterAndSelectValueInQuickNavigation(requestID: string) {
    // check if requestID is already open in a tab by getting count of existing elements
    const requestTab = await this.page
      .locator('td[class*="tabButtonBottom"]')
      .filter({ hasText: requestID })
      .first()
      .count();
    // IF not already open in a tab
    if (requestTab <= 0) {
      const lastChar = requestID.charAt(requestID.length - 1);
      await this.quickNavigation.type(requestID, { delay: 10 });
      await this.page.keyboard.press("Backspace", { delay: 1000 });
      await this.page.keyboard.type(lastChar, { delay: 1000 });
      let results = await this.page
        .locator(".silkDropdownList td div")
        .filter({ hasText: requestID })
        .count();
      if (results <= 0) {
        await this.page.keyboard.press("Backspace", { delay: 1000 });
        await this.page.keyboard.type(lastChar, { delay: 1500 });
        //below is for when a search option has been added.
        results = await this.page
          .locator(".silkDropdownList td div")
          .filter({ hasText: requestID })
          .count();
        if (results <= 0)
          await this.page.keyboard.press("Enter", { delay: 1000 });
        return;
      }
      await this.page
        .locator(".silkDropdownList td div")
        .filter({ hasText: requestID })
        .first()
        .click();
    }
    // ELSE click on the tab
    else {
      await this.page
        .locator('td[class*="tabButtonBottom"]')
        .filter({ hasText: requestID })
        .first()
        .click();
    }
    await this.closeBtnMsgCollapser();
  }

  //Click textbox and then search (i.e.magnifying glass)
  async clickSearchByLabel(label: string, index = 0) {
    await this.page
      .locator(".silkFormCell")
      .locator("visible=true")
      .filter({ hasText: label })
      .nth(index)
      .locator("input")
      .click();
    await this.page
      .locator(".silkFormCell")
      .locator("visible=true")
      .filter({ hasText: label })
      .nth(index)
      .locator('span[role="button"]')
      .click();
  }

  //Applicable for clicking search/calendar/dropdown icon in a focused textbox
  async clickBtnInFocusedTextBox(label: string, index = 0, exact = false) {
    if (exact) {
      await this.page
        .getByLabel(label, { exact: true })
        .locator("visible=true")
        .click();
    } else {
      await this.page
        .locator("[class*=silkFormCell]")
        .locator("visible=true")
        .filter({ hasText: label })
        .nth(index)
        .locator("input")
        .last()
        .click();
    }
    await Promise.all([
      this.page
        .locator(".silkTextItemControlFocused")
        .locator("visible=true")
        .locator('span[role="button"]')
        .first()
        .click(),
      this.page.waitForLoadState("domcontentloaded"),
    ]);
  }

  //Applicable for all elements with class - silkFormCell
  async enterValueByLabel(label: string, value: string, index = 0) {
    const tdContainingText = this.page
      .locator("[class^='silkFormCell']")
      .filter({ hasText: label })
      .locator("visible=true");
    const textBox = this.page
      .locator("tr")
      .filter({ has: tdContainingText })
      .locator("visible=true")
      .locator("td input")
      .nth(index);
    await this.page.waitForLoadState("domcontentloaded");
    await textBox.click();
    await textBox.clear();
    await textBox.type(value, { delay: 10 });
    const inputValue = await textBox.inputValue();
    if (inputValue !== value) {
      await this.enterValueByLabel(label, value, index);
    }
  }

  /*Applicable for elements with class beginning with silkFormCell 
  where above function doesn't apply
  */
  async enterValueByLabel2(
    label: string,
    value: string,
    delayInMs = 0,
    index = 0,
  ) {
    const lastChar = value.charAt(value.length - 1);
    const textBox = await this.page
      .locator("[class*=silkFormCell]")
      .getByLabel(label, { exact: true })
      .locator("visible=true")
      .nth(index)
      .or(this.page.getByLabel(label, { exact: true }).locator("visible=true"))
      .first();
    await textBox.clear();
    await textBox.type(value, { delay: 10 });
    await textBox.press("Backspace", { delay: delayInMs });
    await textBox.type(lastChar, { delay: delayInMs });
    const inputValue = await textBox.inputValue();
    if (inputValue !== value) {
      await textBox.clear();
      await this.enterValueByLabel2(label, value, delayInMs, index);
    }
  }

  /**
   * Use for fields which don't have typical label css.
   * @param locator the Locator for the input field
   * @param value the text to be entered
   * @param delayInMs use this if the automation is going too fast
   */
  async enterValueByLocator({
    locator,
    value,
    delayInMs = 0,
  }: {
    locator: Locator;
    value: string;
    delayInMs?: number;
  }) {
    await locator.clear({ force: true });
    await locator.type(value, { delay: 10 });
    await this.page.waitForTimeout(delayInMs);
    const inputValue = await locator.inputValue();
    if (inputValue !== value) {
      await locator.clear({ force: true });
      await this.enterValueByLocator({ locator, value, delayInMs });
    }
  }

  //Applicable for all elements with class - silkFormCellExtended
  async enterDetailsByLabel(label: string, value: string, index = 0) {
    const tdContainingText = this.page
      .locator("[class^='silkFormCellExtended']")
      .filter({ hasText: label });
    const textBox = this.page
      .locator("tr")
      .filter({ has: tdContainingText })
      .locator("visible=true")
      .nth(index)
      .locator("td input")
      .last();
    await textBox.click({ force: true });
    await textBox.type(value, { delay: 10 });
    await this.page.keyboard.press("Space", { delay: 100 });
    await this.page.keyboard.press("Backspace", { delay: 400 });
    const inputValue = await textBox.inputValue();
    if (inputValue !== value) {
      await textBox.clear();
      await this.enterDetailsByLabel(label, value, index);
    }
  }

  //Enter operators (Ex: Like, > or <= etc.) by Label in Search contract page
  async enterOperatorsByLabel({
    label,
    operator,
    index = 0,
    subIndex = 0,
  }: {
    label: string;
    operator: string;
    index?: number;
    subIndex?: number;
  }) {
    const tdContainingText = this.page
      .locator("[class^='silkFormCellExtended']")
      .filter({ hasText: label });
    const textBox = this.page
      .locator("tr")
      .filter({ has: tdContainingText })
      .nth(index)
      .locator("td input")
      .nth(subIndex);
    await textBox.fill(operator);
  }

  //Retrieve the value from field by Label
  async retrieveValueByLabel(label: string, index = 0) {
    const textField = await this.getInputLocatorByLabel(label, index);
    return (await textField.innerText()) || (await textField.inputValue());
  }

  // Retrieve the Locator so you can perform your own actions on it
  async getInputLocatorByLabel(label: string, index = 0) {
    const textField = this.page
      .locator("[class^=silkFormCell]")
      .locator("visible=true")
      .filter({ hasText: label })
      .nth(index)
      .locator("table input")
      .or(this.page.getByLabel(label, { exact: true }).locator("visible=true"))
      .first();
    return textField;
  }

  /**
   * Select the first value from the filtered table.
   * If the last column is a link, choose a different column to click on
   * @param columnIndexToClick refers to the column that will be clicked
   */
  async selectFirstRowFromTable(columnIndexToClick = -1) {
    await this.page
      .locator(".silkListGridBody table")
      .locator("visible=true")
      .last()
      .locator("tr")
      .first()
      .locator("td")
      .nth(columnIndexToClick)
      .dblclick();
  }

  //Select by the value visible - before using this function, open the drop-down
  async selectValueFromDropdown(value: string) {
    await this.page.waitForTimeout(1000);
    const showAll = this.page
      .getByText("Show All")
      .locator("visible=true")
      .last();
    if ((await showAll.isVisible()) && (await showAll.isEnabled())) {
      await this.page.waitForTimeout(1000);
      await showAll.click();
    }

    const dropdownOption = this.page
      .locator("[class*=listGrid],[role=menuitem]")
      .locator(':text-is("' + value + '")')
      .locator("visible=true");
    await dropdownOption.click();
  }

  /**
   * Waits for loading to be completed.
   * Exits earlier if loading has completed.
   * Checks every 1 second
   * @param timeoutInSeconds
   */
  async waitUntilLoadingFinishes(timeoutInSeconds = 30) {
    const isLoading = await this.loadingSpinner.first().isVisible();
    if (isLoading && timeoutInSeconds) {
      await this.page.waitForTimeout(1000);
      await this.waitUntilLoadingFinishes(--timeoutInSeconds);
    }
  }

  // Waits for package balance and vehicle information to load in Miles sidebar
  async waitUntilPackageBalanceLoads(timeoutInSeconds = 10) {
    const isLoading = await this.progressLoader.last().isVisible();
    if (isLoading && timeoutInSeconds) {
      await this.page.waitForTimeout(1000);
      await this.waitUntilLoadingFinishes(--timeoutInSeconds);
    }
  }

  // Click out of a field to register changes, by clicking on a label of a DIFFERENT field
  async clickOut(label: string) {
    await this.page
      .getByText(label, { exact: true })
      .locator("visible=true")
      .first()
      .click();
  }

  // Get Active tab number as a string. First try using .locator("visible=true")
  // if this is retrieving the previous tab's url, use <locator on new tab>.waitfor() first
  async getActiveTabValue() {
    const url = this.page.url();
    const tabValue = url.split("tab_")[1];
    return tabValue;
  }

  // Close button message collapser if it is open - Main Contract page
  async closeBtnMsgCollapser(timeout = 50) {
    this.waitUntilLoadingFinishes();
    await this.page.waitForLoadState();
    await this.page.waitForTimeout(timeout);
    if (await this.btnMsgCollapser.isVisible()) {
      const collapser = await this.btnMsgCollapser.getAttribute("src");
      if (collapser?.includes("button_up")) await this.btnMsgCollapser.click();
    }
  }

  // Close button message collapser if it is open - Contract Modification popup
  async closeBtnMsgCollapserContractModificationPopup() {
    if (await this.btnMsgCollapserContractModifactionPopup.isVisible()) {
      const collapser =
        await this.btnMsgCollapserContractModifactionPopup.getAttribute("src");
      if (collapser?.includes("button_up"))
        await this.btnMsgCollapserContractModifactionPopup.click();
    }
  }

  // TABLE FUNCTIONS

  /* Table results
  Provide the index for the table - usually 0 or 1
  tableName = the label in the section header before the table
  */

  // use waitForTableDataToLoad() before using this
  async getNumberOfTableRows(tableName: string, index = -1) {
    const table = this.getTableLocator(tableName, index);
    return (await table).locator("tr").count();
  }

  async getValueInTableCell(
    tableName: string,
    index = -1,
    rowIndex = 0,
    columnIndex = 0,
  ) {
    const value = await this.getTableCellLocator(
      tableName,
      index,
      rowIndex,
      columnIndex,
    );
    return await value.innerText();
  }

  async clickLinkInTableCell(
    tableName: string,
    index = 0,
    rowIndex = 0,
    columnIndex = 0,
  ) {
    const cell = await this.getTableCellLocator(
      tableName,
      index,
      rowIndex,
      columnIndex,
    );
    await cell.locator("a").click();
  }

  // returns the Locator, so you can click(), innerText() or waitFor() etc...
  async getTableCellLocator(
    tableName: string,
    index = -1,
    rowIndex = 0,
    columnIndex = 0,
  ) {
    const table = this.getTableLocator(tableName, index);
    return (await table)
      .locator("tr")
      .nth(rowIndex)
      .locator("td[class*=cell],td[class*=Cell]")
      .nth(columnIndex);
  }

  async getTableLocator(tableName: string, index = -1) {
    return this.page
      .locator(
        '[eventproxy*=sectionstack]:has([aria-label="' + tableName + '"])',
      )
      .locator("visible=true")
      .locator(".listTable>tbody")
      .nth(index);
  }

  // Wait for table data to load. It will wait for a max of timeoutInSeconds
  async waitForTableDataToLoad(
    tableName: string,
    index = -1,
    timeoutInSeconds = 4,
  ) {
    const tableHasLoaded = await (await this.getTableLocator(tableName, index))
      .first()
      .isVisible();
    if (!tableHasLoaded && timeoutInSeconds) {
      await this.page.waitForTimeout(1000);
      await this.waitForTableDataToLoad(tableName, index, --timeoutInSeconds);
    }
  }

  async tickTableCheckbox(
    tableName: string,
    tableIndex = 0,
    rowIndex = 0,
    colIndex = 0,
  ) {
    const checkbox = (
      await this.getTableCellLocator(tableName, tableIndex, rowIndex, colIndex)
    ).locator("span");
    if ((await checkbox.getAttribute("class"))?.includes("checkboxFalse")) {
      await checkbox.click();
    }
  }

  async untickTableCheckbox(
    tableName: string,
    tableIndex: number,
    rowIndex: number,
    colIndex: number,
  ) {
    const checkbox = (
      await this.getTableCellLocator(tableName, tableIndex, rowIndex, colIndex)
    ).locator("span");
    if ((await checkbox.getAttribute("class"))?.includes("checkboxTrue")) {
      await checkbox.click();
    }
  }

  async getTableColumnData(tableName: string, index = -1, columnIndex: number) {
    const table = this.getTableLocator(tableName, index);
    return (await table)
      .locator(`tr>td:nth-child(${columnIndex})`)
      .allInnerTexts();
  }

  async getTableDataTextList(tableName: string, index = -1) {
    return (await this.getTableLocator(tableName, index)).allInnerTexts();
  }
  // END of NEW TABLE FUNCTIONS

  // For selecting an editable table cell in the highlighed row
  // Might need to click on the row to highlight it first
  async clickTableCellValue(cellColumnIndex: number) {
    await this.page
      .locator(".silkListGridBody")
      .locator("[class*=silkTextItemControl]")
      .locator("visible=true")
      .nth(cellColumnIndex)
      .click();
  }

  // For selecting an editable table cell and entering a value
  async enterTableCellValue(cellColumnIndex: number, value: string) {
    await this.clickTableCellValue(cellColumnIndex);
    await this.page.keyboard.type(value);
  }

  // For selecting an editable table cell and clicking the button in the cell
  async selectBtnInTableCell(cellColumnIndex: number) {
    await this.clickTableCellValue(cellColumnIndex);
    await Promise.all([
      this.page
        .locator(".silkTextItemControlFocused")
        .locator("visible=true")
        .locator('span[role="button"]')
        .first()
        .click(),
      this.page.waitForLoadState("domcontentloaded"),
    ]);
  }

  // Use when system dialog can be ignored - For EXPECTED errors
  async dismissSystemDialog(errormsg?: string, timeoutInSeconds = 5) {
    await this.waitUntilLoadingFinishes();
    const error = await this.getSystemErrorMsg();
    if (!error && timeoutInSeconds) {
      await this.page.waitForTimeout(1000);
      await this.dismissSystemDialog(errormsg, --timeoutInSeconds);
    } else {
      if ((error && !errormsg) || (errormsg && error.includes(errormsg)))
        await this.btnClose.click();
    }
  }

  // returns true if the field is focused
  async isFieldFocused(label: string) {
    const fieldClass = await this.page
      .getByLabel(label)
      .locator("visible=true")
      .getAttribute("class");
    return fieldClass && fieldClass.includes("Focused");
  }

  // click a field for the given label
  async clickField(label: string, index = 0) {
    await this.page
      .getByLabel(label, { exact: true })
      .locator("visible=true")
      .nth(index)
      .click({ force: true });
  }

  // return true if a system error dialog is on the screen
  async hasSystemError() {
    return this.systemErrorMsg.isVisible();
  }

  // returns an empty string if there is no error found
  async getSystemErrorMsg() {
    if (await this.hasSystemError()) {
      return this.systemErrorMsg.innerText();
    }
    return "";
  }

  async hasCollapserErrors() {
    return await this.collapserErrorMsgs.isVisible();
  }

  async getNumberOfCollapserErrors() {
    return await this.collapserErrorMsgs.count();
  }

  async getNthCollapserError(n = 0) {
    if (await this.hasCollapserErrors()) {
      return this.collapserErrorMsgs.nth(n).innerText();
    }
    return "";
  }

  // provide the name of the tab you want to switch to (tabs at the bottom. Eg Quote, LTC, VO)
  async clickBottomTab(partialName: string) {
    await this.page
      .locator("td.tabButtonBottom")
      .filter({ hasText: partialName })
      .first()
      .click();
  }

  /**
   * The vertical Menu items on the left in the Menu section
   * @param partialTabName examples: LTC, AQ, VO, Quote or quote number etc...
   * partialTabName only required only where you click a bottom tab and immediately want to click a menu
   */
  async clickMenuItem(menuName: string, partialTabName?: string) {
    // IF clicking a menu in a new tab, wait for the new active tab to load
    const menu = await this.getMenuItemLocator(menuName, partialTabName);
    await menu.click();
    await this.waitUntilLoadingFinishes();
  }

  async getMenuItemLocator(exactMenuName: string, partialTabName?: string) {
    // IF clicking a menu in a new tab, wait for the new active tab to load
    if (partialTabName) {
      const tab = this.page
        .locator("td[class^=tabButtonBottom]")
        .filter({ hasText: partialTabName })
        .first();
      await tab.waitFor();
      await tab.click();
      await this.page.waitForTimeout(1000);
    }
    const tabNum = await this.getActiveTabValue();
    const menu = this.page.locator(
      `td:has([id^=id_menu_${tabNum}_valueCell] :text-is("${exactMenuName}"))`,
    );
    return menu;
  }

  /**
   * For any tab on the page, but not the bottom tabs (not LTC, not AQ)
   * Tab Examples: Summary, Pricing, Distance, Additional Details, More
   * @param exactName
   */
  async clickHorizontalTab(exactName: string) {
    const tab = this.page
      .locator('[class*=tabButtonTop]:text-is("' + exactName + '")')
      .locator("visible=true");
    await tab.click();
  }

  /**
   * Get checkbox locator (not checkboxes in tables)
   * @param exactName
   */
  async getCheckBoxLocator(exactName: string) {
    return this.page
      .locator(`td:has([class*=CheckBox] :text-is("${exactName}")) td>img`)
      .locator("visible=true");
  }

  /**
   * For checkboxes in the main area (not checkboxes in tables)
   * @param exactName
   */
  async tickCheckBox(exactName: string) {
    const checkBox = await this.getCheckBoxLocator(exactName);
    const attribute = await checkBox.getAttribute("src");
    if (attribute && attribute.includes("unchecked")) {
      await checkBox.click(); // check() doesn't work here
    }
  }

  /**
   * For checkboxes in the main area (not checkboxes in tables)
   * @param exactName
   */
  async untickCheckBox(exactName: string) {
    const checkBox = await this.getCheckBoxLocator(exactName);
    const attribute = await checkBox.getAttribute("src");
    if (attribute && !attribute.includes("unchecked")) {
      await checkBox.click(); // uncheck() doesn't work here
    }
  }

  // In Search Results
  async sortDescending(columnName: string) {
    const columnHeader = await this.getColumnHeaderLocator(columnName);
    await columnHeader.click();
    const sort = await columnHeader.locator("img").getAttribute("src");
    if (sort && sort.includes("sort_ascending")) {
      await columnHeader.click();
    }
  }

  // In Search Results
  async sortAscending(columnName: string) {
    const columnHeader = await this.getColumnHeaderLocator(columnName);
    await columnHeader.click();
    const sort = await columnHeader.locator("img").getAttribute("src");
    if (sort && sort.includes("sort_descending")) {
      await columnHeader.click();
    }
  }

  async getColumnHeaderLocator(columnName: string) {
    return this.page
      .locator('[role=button]:has(:text-is("' + columnName + '"))')
      .locator("visible=true");
  }
}
