import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesSearchBulkOperations extends BasePage {
  readonly btnSearch: Locator;
  readonly inputFile: Locator;
  readonly inputAllocate: Locator;
  readonly inputPost: Locator;
  readonly btnRefresh: Locator;

  readonly btnExecuteNow: Locator;
  readonly uploadedFileTimestamp: Locator;
  readonly htmlFile: Locator;
  readonly linkHTMLFile: Locator;
  readonly btnGeneric: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.btnSearch = this.page
      .locator('xpath=//td[contains(.,"Search")][contains(@class,"Button")]')
      .last();

    this.inputFile = this.page.locator(
      "xpath=//td[contains(.,'Input File')]/../td[1]//div",
    );
    this.inputAllocate = this.page.locator(
      "xpath=//td[contains(.,'Allocate')]/../td[1]//div",
    );
    this.inputPost = this.page.locator(
      "xpath=//td[contains(.,'Post')]/../td[1]//div",
    );
    this.btnRefresh = this.page.getByLabel("Refresh").locator("visible=true");

    this.btnExecuteNow = this.page.getByLabel("Execute Now");
    this.uploadedFileTimestamp = this.page
      .locator('xpath=//td[contains(.,"Ended")][1]/../..//td[3]')
      .first();
    this.htmlFile = this.page.locator("a >> text=.html").last();
    this.linkHTMLFile = this.page.locator("a.silkClickableLink").nth(4);
    this.btnGeneric = this.page.locator(':text-is("Generic")');
  }

  async waitForFileSelectionItem(fileName: string) {
    const fileLocator = this.page
      .getByRole("cell", { name: `${fileName}` })
      .locator("span");
    if (await fileLocator.isVisible()) {
      await fileLocator.waitFor();
    } else {
      await fileLocator.waitFor({ state: "hidden" });
    }
  }
}
