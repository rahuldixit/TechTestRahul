import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesContactPage extends BasePage {
  readonly btnSave: Locator;
  readonly menuNovatedCustomer: Locator;
  readonly searchResultsCustomerId: Locator; // Search Results under Novated Customer
  readonly addAddress: Locator;
  readonly addPhone: Locator;
  readonly addEmail: Locator;
  readonly createQuote: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnSave = this.page
      .getByRole("button", { name: "SaveSave pending changes" })
      .locator("visible=true");
    this.menuNovatedCustomer = this.page.locator(
      'tr[role=treeitem] :text-is("Novated Customer")',
    );
    this.searchResultsCustomerId = this.page
      .locator("[eventproxy*=search_result] a.silkClickableLink")
      .locator("visible=true")
      .first();
    this.addAddress = this.page
      .locator('[aria-label="Add (Alt+Ins)"]')
      .locator("visible=true")
      .first();
    this.addPhone = this.page
      .locator('[aria-label="Add (Alt+Ins)"]')
      .locator("visible=true")
      .nth(1);
    this.addEmail = this.page
      .locator('[aria-label="Add (Alt+Ins)"]')
      .locator("visible=true")
      .nth(2);
    this.createQuote = this.page.getByLabel(
      "Create QuoteCreate a quote for this driver (F9)",
    );
  }
}
