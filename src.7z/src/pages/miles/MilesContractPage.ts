import { Locator, Page, expect } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesContractPage extends BasePage {
  readonly longTermContracts: Locator;
  readonly pendingQuotesEmptyMsg: Locator;
  readonly licensePlateInContext: Locator; // in the Context section on the left

  //create New Vehicle Order
  readonly btnVehicle: Locator;
  readonly btnOpenVehicle: Locator;
  readonly btnRefresh: Locator;

  //Modify Contract
  readonly btnModifyContract: Locator;
  readonly btnModify: Locator; // in Contract Modification window
  readonly fieldChangeReason: Locator;
  readonly changeReasonInNewVersion: Locator; // displayed after the new version created

  //Formal Extension
  readonly btnEyeIconNextToCurrentOdo: Locator; //General > Vehicle section > Current Odo field

  //Lease Service - locators in the Lease Service menu
  readonly leaseServiceTabAdditionalDetails: Locator;
  readonly btnEditIncludedServices: Locator;
  readonly btnSave: Locator;

  //Existing Vehicle Orders
  readonly orderStatusFirstRowInVO: Locator;
  readonly referenceStatusFirstRowInVO: Locator;
  readonly vehicleOrderTypeFirstRowInVO: Locator;

  //Versions
  readonly btnCompare: Locator;

  //Version Comparison
  readonly sectionQuoteDetails1: Locator; // there are 2 sections with the same name on this page

  //cost centre change window
  readonly btnNext: Locator;
  readonly btnTransfer: Locator;
  readonly btnTransferDropDown: Locator;
  readonly btnTransferContact: Locator;
  readonly btnNewContract: Locator;
  readonly btnSearch: Locator;
  readonly driverLink: Locator;
  readonly btnUnlinkPerson: Locator;

  //Billing Overview
  readonly dropdownServiceType: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.longTermContracts = this.page
      .locator('span:has-text("Long Term Contracts")')
      .locator("visible=true");
    this.pendingQuotesEmptyMsg = this.page
      .locator("[eventproxy*=PendingQuotes]")
      .locator(".emptyMessage")
      .locator("visible=true");
    this.licensePlateInContext = this.page
      .locator(".licensePlateContent")
      .locator("visible=true");

    //create New Vehicle Order
    this.btnVehicle = this.page
      .getByLabel("VehicleCreate a vehicle order")
      .locator("visible=true");
    this.btnOpenVehicle = this.page
      .getByLabel("Open VehicleOpen the Assigned Fleet Vehicle")
      .locator("visible=true");
    this.btnRefresh = this.page
      .getByLabel("RefreshReload the page data")
      .locator("visible=true");

    //Modify Contract
    this.btnModifyContract = this.page
      .getByLabel("Modify ContractInitiate contract modification")
      .locator("visible=true");
    this.btnModify = this.page
      .getByLabel("Modify", { exact: true })
      .locator("visible=true");
    this.fieldChangeReason = this.page
      .getByLabel("Change Reason")
      .locator("visible=true");
    this.changeReasonInNewVersion = this.page
      .locator("[eventproxy*=ContractContextVersion]")
      .locator("[class*=cell]")
      .locator("visible=true")
      .nth(6);

    //Formal Extension
    this.btnEyeIconNextToCurrentOdo = this.page
      .locator('tr:has(label:text-is("Current Odo"))')
      .locator("img");

    //Lease Service
    this.leaseServiceTabAdditionalDetails = this.page
      .locator('[class^=tabButtonTop]:text-is("Additional Details")')
      .locator("visible=true");
    this.btnEditIncludedServices = this.page
      .getByLabel("EditChoose applicable Lease Services")
      .locator("visible=true");
    this.btnSave = this.page
      .locator('[aria-label="SaveSave pending changes"]')
      .locator("visible=true");

    //Existing Vehicle Orders
    this.orderStatusFirstRowInVO = this.page
      .locator("[eventproxy*=VehicleOrders]")
      .locator("visible=true")
      .locator("table")
      .nth(3)
      .locator("tr[role=listitem]")
      .nth(0) // first row
      .locator("td")
      .nth(4); // fifth column
    this.referenceStatusFirstRowInVO = this.page
      .locator("[eventproxy*=VehicleOrders]")
      .locator("visible=true")
      .locator("table")
      .nth(3)
      .locator("tr[role=listitem]")
      .nth(0) // first row
      .locator("td")
      .nth(0) // first column
      .locator("a");
    this.vehicleOrderTypeFirstRowInVO = this.page
      .locator("[eventproxy*=VehicleOrders]")
      .locator("visible=true")
      .locator("table")
      .nth(3)
      .locator("tr[role=listitem]")
      .nth(0) // first row
      .locator("td")
      .nth(1); // 2nd column

    //Versions
    this.btnCompare = this.page
      .getByLabel("CompareCompare Quotes")
      .locator("visible=true");

    //Version Comparison
    this.sectionQuoteDetails1 = this.page
      .locator('.sectionStack :text-is("Quote Details")')
      .locator("visible=true")
      .first();

    this.btnNext = this.page
      .locator(':text-is("Next")')
      .locator("visible=true")
      .first();
    this.btnTransfer = this.page
      .getByLabel("Transfer")
      .locator("visible=true")
      .first();
    this.btnTransferDropDown = this.page
      .locator("tr")
      .filter({ hasText: "Change ReasonChange Date" })
      .locator("span")
      .locator("visible=true")
      .first();
    this.btnTransferContact = this.page
      .getByLabel(
        "Transfer ContactTransfer this contact to another business unit (F4)",
      )
      .locator("visible=true");
    this.btnNewContract = this.page
      .getByText("New contract version 2 has been created and activated.")
      .locator("visible=true");
    this.btnSearch = this.page
      .getByLabel("SearchExecute selection")
      .locator("visible=true")
      .last();
    this.driverLink = this.page
      .locator("td")
      .filter({ hasText: "A new contact ID" })
      .locator("a")
      .locator("visible=true");

    // Billing Overview
    this.dropdownServiceType = this.page
      .locator("tr")
      .filter({ hasText: "ServiceType" })
      .locator('input[name="silk_search_condValue"]');

    this.btnUnlinkPerson = this.page
      .getByLabel(
        "Unlink PersonRemove the linked person from this contact (F7)",
      )
      .locator("visible=true");
  }

  // Clicks the existing Selected Service
  // In Lease Service > Included Services > Edit > Selected Services
  async selectSelectedServices(leaseService: string) {
    await this.page
      .locator("[eventproxy*=ComponentPicker_selectedComps]")
      .locator('td>div:text-is("' + leaseService + '")')
      .locator("visible=true")
      .click();
  }

  // Ticks the checkbox in the Available Services
  // In Lease Service > Included Services > Edit > Available Services
  async tickCheckboxAvailableServices(leaseService: string) {
    await this.page
      .locator('div:has(>div>div:text-is("' + leaseService + '"))')
      .locator("div span[id*=extra_icon]")
      .locator("visible=true")
      .last()
      .click();
  }

  /**
   * Location: Versions > (tick two contract versions) > Compare > (2nd) Quote Details section.
   * Gets left and right values from the table for the given service.
   * @param serviceName
   * @param hasSubService If true, then it will get the first "$" in the row below the service
   */
  async getLeftAndRightValuesInQuoteDetailsComparison(
    serviceName: string,
    hasSubService = false,
  ) {
    const tableName = "Quote Details";
    const leftTableIndex = 1;
    const rightTableIndex = 3;
    let leftValue;
    let rightValue;
    // hasSubComponent is true when the given component won't have any $ values
    await this.sectionQuoteDetails1.click();
    if (hasSubService) {
      leftValue = await (
        await this.getTableLocator(tableName, leftTableIndex)
      )
        .locator('tr:has(td>:text-is("' + serviceName + '"))~tr')
        .first()
        .locator('div:has-text("$")')
        .first()
        .innerText();
      rightValue = await (
        await this.getTableLocator(tableName, rightTableIndex)
      )
        .locator('tr:has(td>:text-is("' + serviceName + '"))~tr')
        .first()
        .locator('div:has-text("$")')
        .first()
        .innerText();
    }
    // hasSubComponent is false when the $ values will be on the same row as the component
    else {
      leftValue = await (
        await this.getTableLocator(tableName, leftTableIndex)
      )
        .locator('tr:has(td>:text-is("' + serviceName + '"))')
        .first()
        .locator('div:has-text("$")')
        .first()
        .innerText();
      rightValue = await (
        await this.getTableLocator(tableName, rightTableIndex)
      )
        .locator('tr:has(td>:has-text("' + serviceName + '"))')
        .first()
        .locator('div:has-text("$")')
        .first()
        .innerText();
    }
    return {
      leftValue: leftValue,
      rightValue: rightValue,
    };
  }

  /**
   * In a Contract which has been recalculated,
   * verifies that the Recalculate column has been ticked for the given service
   * @param serviceName
   */
  async verifyRecalculateIsTickedInLeaseService(serviceName: string) {
    const recalculated = this.page
      .locator('tr:has(:text-is("' + serviceName + '"))')
      .locator("visible=true")
      .locator("img[class*=Checkbox]");
    expect(await recalculated.getAttribute("src")).toContain("checked");
  }
}
