import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesCustomerPage extends BasePage {
  readonly menuFinancial: Locator;
  readonly btnAddBankAccounts: Locator;
  readonly fieldAccountNumber: Locator; // in the Bank Accounts table
  readonly dropdownCheckType: Locator;
  readonly btnSave: Locator;
  readonly createDriver: Locator;
  readonly editDriver: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.menuFinancial = this.page
      .locator('tr[role=treeitem] :text-is("Financial")')
      .locator("visible=true");
    this.btnAddBankAccounts = this.page
      .getByRole("tab", { name: "Bank Accounts", exact: true })
      .getByLabel("Add (Alt+Ins)");
    this.fieldAccountNumber = this.page
      .locator("[eventproxy*=grid_CustomerBankAccountAccount] td tr")
      .locator("visible=true")
      .nth(2);
    this.dropdownCheckType = this.page
      .locator("[eventproxy*=grid_CustomerBankAccountAccount] td tr")
      .locator("visible=true")
      .nth(0);
    this.btnSave = this.page
      .getByRole("button", { name: "SaveSave pending changes" })
      .locator("visible=true");
    this.createDriver = this.page
      .locator(":text-is('Create Driver')")
      .locator("visible=true");
    this.editDriver = this.page
      .getByRole("tab", { name: "Contact Details" })
      .getByRole("button")
      .locator("visible=true");
  }
}
