import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesDirectCreditPage extends BasePage {
  readonly btnAdd: Locator;
  readonly btnNew: Locator;
  readonly btnSave: Locator;
  readonly selectionBox: Locator;
  readonly selectionDropdownIcon: Locator;
  readonly btnSearch: Locator;
  readonly btnAssign: Locator;
  readonly btnAllocate: Locator;
  readonly btnPost: Locator;
  readonly btnAssignPurchaseInvoice: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.btnAdd = this.page.getByLabel("Add (Alt+Ins)").locator("visible=true");
    this.btnNew = this.page
      .getByLabel("NewRegister a new object.")
      .locator("visible=true");
    this.btnSave = this.page
      .getByLabel("SaveSave pending changes")
      .locator("visible=true");
    this.selectionBox = this.page.locator('input[name="selection"]');
    this.selectionDropdownIcon = this.page
      .locator("[class^=silkTextItemPickerIcon] img")
      .locator("visible=true");
    this.btnSearch = this.page
      .getByLabel("Search")
      .locator("visible=true")
      .last();
    this.btnAssign = this.page
      .getByLabel("Assign payment to purchaise invoices (F3)")
      .locator("visible=true")
      .last();
    this.btnAllocate = this.page
      .getByLabel("AllocateAllocate the payment document (Shift+F9)")
      .locator("visible=true");
    this.btnPost = this.page
      .getByLabel("PostPost the payment document (F9)")
      .locator("visible=true");
    this.btnAssignPurchaseInvoice = this.page
      .getByLabel("Purchase InvoiceAssign payment to purchaise invoices (F3)")
      .locator("visible=true");
  }
}
