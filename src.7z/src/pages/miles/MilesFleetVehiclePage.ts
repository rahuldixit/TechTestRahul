import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesFleetVehiclePage extends BasePage {
  readonly btnSave: Locator;
  readonly btnAddRegisteredLicensePlates: Locator; // plus button under Registered Licence Plates
  readonly licenseNumberField: Locator;
  readonly btnTodayDateChooser: Locator;
  readonly btnDeliver: Locator;
  readonly menuRibbon: Locator; // the top menu which can scroll horizontally
  readonly menuRibbonScrollRight: Locator; // appears after hovering over the menu ribbon
  readonly btnDeliverDialog: Locator; // Deliver button on Express Delivery dialog
  readonly contextStatus: Locator; // the Fleet Vehicle status in the Context box
  readonly checkboxAcknowledge14days: Locator;
  readonly btnExpressDelivery: Locator;
  //Formal Extension
  readonly btnAddForVehicleEvents: Locator; //Distance Registration > plus button for Vehicle Events

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnSave = this.page
      .getByLabel("SaveSave pending changes")
      .locator("visible=true");
    this.btnAddRegisteredLicensePlates = this.page
      .getByLabel("Registered License Plates", { exact: true })
      .getByLabel("Add (Alt+Ins)")
      .locator("visible=true");
    this.licenseNumberField = this.page
      .getByText("License Number")
      .locator("visible=true");
    this.btnTodayDateChooser = this.page
      .locator(".dateChooserBorderedBottomButton")
      .filter({ hasText: "Today" });
    this.btnDeliver = this.page
      .getByLabel("to the customer or driver")
      .locator("visible=true");
    this.menuRibbon = this.page.getByRole("cell", { name: "File" });
    this.menuRibbonScrollRight = this.page
      .locator('[src*="scroll_arrow_right"]')
      .locator("visible=true");
    this.btnDeliverDialog = this.page.getByLabel("Deliver", { exact: true });
    this.contextStatus = this.page
      .locator("[class*=silkContextCell]")
      .locator('input[name="A587"]');
    this.checkboxAcknowledge14days = this.page
      .locator(".silkFormCheckBox")
      .locator("visible=true")
      .locator('text="Acknowledge delivery more than 14 days in the past"');

    //Formal Extension
    this.btnAddForVehicleEvents = this.page
      .locator('div:has(>[aria-label="Vehicle Events"])')
      .locator("visible=true")
      .locator('[aria-label="Add (Alt+Ins)"]');
    this.btnExpressDelivery = this.page
      .getByText("Express Delivery")
      .locator("visible=true");
  }

  /*
    This table appears in the Distance Registration menu.
    Use after clicking the plus button to add a new row
    inputColumnIndex: only count the colums that you can actually modify
     */
  async enterValueInVehicleEventsTable(
    value: string,
    inputColumnIndex: number,
  ) {
    const textBox = this.page
      .locator("[eventproxy*=grid_CostCenterEventsFleetVehicle]")
      .locator("tbody [role=listitem]")
      .nth(0)
      .locator("td input")
      .nth(inputColumnIndex);
    await textBox.type(value);
    const inputValue = await textBox.inputValue();
    if (inputValue !== value) {
      await textBox.clear();
      await this.enterValueInVehicleEventsTable(value, inputColumnIndex);
    }
  }

  //Tick the checkbox in the Valid column. Tick the first row
  async clickCheckboxInVehicleEventsTable(checkboxIndex: number) {
    await this.page
      .locator("[eventproxy*=grid_CostCenterEventsFleetVehicle]")
      .locator("tbody [role=listitem]")
      .nth(0)
      .locator("td .silkGridCheckBox")
      .nth(checkboxIndex)
      .click();
  }

  //get value in Vehicle Events table under Distance Registration
  async getValueInVehicleEventsTable(rowIndex: number, columnIndex: number) {
    return await this.page
      .locator("[eventproxy*=grid_CostCenterEventsFleetVehicle]")
      .locator("visible=true")
      .locator("tbody [role=listitem]")
      .nth(rowIndex)
      .locator("td")
      .nth(columnIndex)
      .innerText();
  }
}
