import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesHomePage extends BasePage {
  readonly home: Locator;
  readonly salesTab: Locator;
  readonly contractsTab: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.home = this.page
      .locator(".breadCrumb")
      .locator("visible=true")
      .first();
    this.salesTab = this.page
      .getByText("Sales", { exact: true })
      .locator("visible=true");
    this.contractsTab = this.page
      .getByText("Contracts", { exact: true })
      .locator("visible=true")
      .first();
  }

  /**
   * On the Home Page, click any menu or sub menu that appears in the horizontal menu.
   * It doesn't matter if you need to scroll to see it.
   * Eg: Sales, Relation Management, Fleet, Contracts, Short Term ....
   * You can use this function regardless of how many levels there are.
   * Eg: Accounting > Accounts Payable > Direct Credit > Direct Credit
   * @param exactName
   */
  async clickHorizontalPortalNav(exactName: string) {
    await this.page
      .locator("td.portalBranchTitle, td.portalLeafTitle")
      .locator("visible=true")
      .locator(':text-is("' + exactName + '")')
      .click();
  }

  async goToHome() {
    await this.homeTab.click();
    await this.home.click();
    await this.page.waitForTimeout(1000);
  }
}
