import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesLoginPage extends BasePage {
  readonly milesUsername: Locator;
  readonly milesPassword: Locator;
  readonly btnMilesLogin: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.milesUsername = this.page.locator('input[name="username"]');
    this.milesPassword = this.page.locator('input[name="password"]');
    this.btnMilesLogin = this.page.locator(".buttonRounded");
  }

  async openMilesURL(url: string) {
    await this.page.goto(url);
  }
}
