import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";
import { faker } from "@faker-js/faker";

export class MilesNewSalesRequestPage extends BasePage {
  readonly addIcon: Locator;
  readonly btnSearch: Locator;
  readonly searchCustomerOrCostCentre: Locator;
  readonly selectCustomerOrCostCentre: Locator;
  readonly btnSave: Locator;
  readonly btnCalculate: Locator;
  readonly btnValidate: Locator;
  readonly menuItemVehicle: Locator;
  readonly vehicleDeliveryTab: Locator;
  readonly vehicleDeliveryLocation: Locator;
  readonly btnApprove: Locator;
  readonly menuItemSummary: Locator;
  readonly quoteNumber: Locator;
  readonly gridHeightSelector: Locator;

  //For new contract
  readonly includedServicesRow0Opener: Locator;
  readonly gridHeightLeaseService: Locator;
  readonly thirdPartyService: Locator;
  readonly btnContract: Locator;
  readonly contractLink: Locator;
  readonly contractReferenceNumber: Locator;
  readonly btnRefresh: Locator;

  //For Amendment Quote / Edit Equipment
  readonly btnEditEquipment: Locator;
  readonly filterAccessory: Locator;
  readonly btnFreeform: Locator;
  readonly fieldDescription: Locator;
  readonly btnOKFreeform: Locator;
  readonly newContractVersion: Locator;

  //For General Restructure on TPSC page
  readonly bottomContractVersion: Locator;
  readonly topContractVersion: Locator;

  //Lease Service
  readonly btnEditLeaseService: Locator;
  readonly btnMoreLeaseService: Locator;
  readonly btnFunderPreApprovalGranted: Locator;
  readonly checkBoxValueFunderPreApprovalGranted: Locator;

  //for copy
  readonly newRequest: Locator;
  readonly otherFields: Locator;
  readonly btnCopy: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    //For new quote
    this.btnSearch = this.page.getByLabel("SearchExecute selection").first();
    this.searchCustomerOrCostCentre = this.page
      .locator(".silkTextItemControlFocused")
      .locator('span[role="button"]');
    this.selectCustomerOrCostCentre = this.page
      .locator(".listTable td.cellSelectedOver")
      .first();
    this.addIcon = this.page.getByLabel("Add (Alt+Ins)").first();
    this.btnSave = this.page
      .getByLabel("SaveSave pending changes")
      .locator("visible=true");
    this.btnCalculate = this.page
      .getByLabel("CalculateCalculate the entire quote (F5)")
      .locator("visible=true");
    this.btnValidate = this.page
      .getByLabel("ValidateValidate the quote (F6)")
      .locator("visible=true");
    this.menuItemVehicle = this.page.locator("div#id_menu_3_valueCell1");
    this.vehicleDeliveryTab = this.page
      .locator(".tabBarTop")
      .getByLabel("Delivery", { exact: true });
    this.vehicleDeliveryLocation = this.page.locator('textarea[name="A2726"]');
    this.btnApprove = this.page
      .getByLabel("ApproveApprove the quote (F7)")
      .locator("visible=true");
    this.menuItemSummary = this.page.locator("div#id_menu_3_valueCell0");
    this.quoteNumber = this.page.locator('input[name="A10250"]');
    this.gridHeightSelector = this.page.locator('input[name="gridHeightItem"]');

    //For new contract
    this.includedServicesRow0Opener = this.page
      .locator("[id*=open_icon_0]")
      .last();
    this.gridHeightLeaseService = this.page
      .locator('input[name="gridHeightItem"]')
      .locator("visible=true");
    this.thirdPartyService = this.page
      .locator('input[name="_compTPService"]')
      .locator("visible=true");
    this.btnContract = this.page
      .getByLabel("ContractGenerate contract")
      .locator("visible=true")
      .or(
        this.page
          .getByLabel("ContractCreate a new contract version")
          .locator("visible=true"),
      )
      .first();
    this.contractLink = this.page
      .locator(".messageGridConfirmation_both a")
      .last();
    this.contractReferenceNumber = this.page
      .getByLabel("Reference", { exact: true })
      .locator("visible=true");
    this.btnRefresh = this.page
      .getByLabel("RefreshReload the page data")
      .locator("visible=true");

    //For Amendment Quote
    this.btnEditEquipment = this.page
      .getByLabel("EditEdit vehicle equipment")
      .locator("visible=true");
    this.filterAccessory = this.page
      .getByLabel("Accessory")
      .locator("visible=true");
    this.btnFreeform = this.page.getByLabel("FreeformAdd a freeform option");
    this.fieldDescription = this.page
      .locator("[eventproxy*=FreeFormOptions]")
      .getByLabel("Description");
    this.btnOKFreeform = this.page
      .locator("[eventproxy*=Addfreeform]")
      .getByLabel("OK");
    this.newContractVersion = this.page
      .getByText("New contract version ")
      .locator("visible=true");

    //For General Restructure
    this.bottomContractVersion = this.page
      .locator("[id*=table]")
      .locator("[class*=checkbox]")
      .locator("visible=true")
      .last();
    this.topContractVersion = this.page
      .locator("[id*=table]")
      .locator("[class*=checkbox]")
      .locator("visible=true")
      .first();

    //Lease Service
    this.btnEditLeaseService = this.page
      .getByLabel("EditChoose applicable Lease Services")
      .locator("visible=true");

    this.btnMoreLeaseService = this.page.getByText("More");

    this.btnFunderPreApprovalGranted = this.page
      .getByText("Funder Pre-Approval Granted?")
      .first();

    this.checkBoxValueFunderPreApprovalGranted = this.page
      .locator('tr:has(>:text-is("Funder Pre-Approval Granted?"))')
      .locator("visible=true")
      .locator(".silkFormCheckBoxImg img");

    this.newRequest = this.page
      .locator("[role=menuitem]")
      .locator(':text-is("New Request")')
      .locator("visible=true");
    this.otherFields = this.page
      .getByLabel("Other Fields")
      .locator("visible=true");
    this.btnCopy = this.page
      .getByLabel("Copy...Copy selected quote", { exact: true })
      .locator("visible=true");
  }

  async selectGridHeightForFundingArrangementInQuote(index = 0) {
    await this.gridHeightSelector.nth(index).click();
    const gridHeight = this.page
      .getByRole("cell", { name: "Autofit" })
      .locator("span");
    await gridHeight.click();
  }

  async selectFundingArrangementOption(option: string) {
    await this.page
      .locator("div[id*=grid_LeaseService]")
      .filter({ hasText: option })
      .click();
  }

  async selectQuotationTemplateFromDropdown(template: string) {
    await this.page
      .locator(".tallCellSelected")
      .filter({ hasText: template })
      .last()
      .click();
  }

  async clickEditEquipment() {
    await this.btnEditEquipment.scrollIntoViewIfNeeded();
    await this.btnEditEquipment.click({ force: true });
    await this.waitUntilLoadingFinishes();
  }

  // selects a random accessory to be added in the Equipment
  async selectRandomAccessory() {
    const accessoryOptions = this.page
      .locator("[eventproxy*=ConfigOptionPickerCatalogOptions]")
      .locator("[class*=checkbox]")
      .locator("visible=true");
    await accessoryOptions.nth(1).click({ clickCount: 2, delay: 100 });
    const range = await accessoryOptions.count();
    const randomNumber = faker.number.int({ max: range - 2 });
    await accessoryOptions.nth(randomNumber).click();
  }

  // return Locator for Lease service is available in Lease Service > Included Services
  async getLeaseServiceLocator(leaseService: string) {
    const leaseServiceRow = this.page
      .locator("div[id*=grid_LeaseService]")
      .locator('div:text-is("' + leaseService + '")')
      .locator("visible=true");
    return leaseServiceRow;
  }

  // return the value in Lease Price column in Lease Service > Included Services
  async getLeasePriceLocator(leaseService: string) {
    return this.page
      .locator('tr:has(div:text-is("' + leaseService + '")) td>div')
      .locator("visible=true")
      .nth(1); // column for Lease Price
  }

  // return value in GST/VATI column in Lease Service > Included Services
  async getGSTLocator(leaseService: string) {
    return this.page
      .locator('tr:has(div:text-is("' + leaseService + '")) td>div')
      .locator("visible=true")
      .nth(2); // column for GST
  }

  /* 
  When TPS Component link is short, need to click on the link. Because the div isn't a link.
  When TPS Component link is long, some of it is hidden, 
  so need to click on the div which is covered by the link.
  */
  async clickTPSComponent(fundOption: string) {
    if (fundOption.length >= 19) {
      await this.page
        .locator("div:has(>.silkClickableLink)")
        .locator("visible=true")
        .click();
    } else {
      await this.page
        .locator("a.silkClickableLink")
        .locator("visible=true")
        .click();
    }
  }

  //Lease Service > Edit > Available Serices
  //Need to double-click to drill down.
  async dblClickAvailableService(serviceName: string) {
    const service = this.page
      .locator("[id*=grid_leaseServiceComponentPicker]")
      .locator("visible=true")
      .locator(':text-is("' + serviceName + '")');
    await service.dblclick();
  }

  /*
  Lease Service > Edit > Available Serices
  Ticks or Un-ticks a checkbox
  Don't tick parent services, only tick/untick actual service
  */
  async toggleCheckboxForAvailableService(name: string) {
    const checkbox = await this.getCheckboxLocatorForAvailableService(name);
    await checkbox.click();
  }

  async getCheckboxLocatorForAvailableService(name: string) {
    return this.page
      .locator('td:has(:text-is("' + name + '")).treeTallCell')
      .locator("visible=true")
      .locator("span[style*=checked]")
      .last();
  }

  // Ensures a checkbox is ticked in Lease Service > Edit > Available Serices
  async tickCheckboxForAvailableService(name: string) {
    const checkbox = await this.getCheckboxLocatorForAvailableService(name);
    const attribute = await checkbox.getAttribute("style");
    if (attribute && attribute.includes("unchecked")) {
      await this.toggleCheckboxForAvailableService(name);
    }
  }

  // Ensures a checkbox is unticked in Lease Service > Edit > Available Serices
  async untickCheckboxForAvailableService(name: string) {
    const checkbox = await this.getCheckboxLocatorForAvailableService(name);
    const attribute = await checkbox.getAttribute("style");
    if (attribute && !attribute.includes("unchecked")) {
      await this.toggleCheckboxForAvailableService(name);
    }
  }

  async toggleFunderPreApprovalGranted() {
    await this.clickMenuItem("Lease Service");
    await this.clickHorizontalTab("More");
    await this.btnFunderPreApprovalGranted.click();
    await this.btnSave.click();
    await this.page.waitForSelector(
      '[aria-label="SaveSave pending changes"] .iconButtonDisabled',
    );
  }
}
