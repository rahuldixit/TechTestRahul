import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesPaymentsPage extends BasePage {
  readonly btnAllocate: Locator;
  readonly btnPost: Locator;

  constructor(page: Page) {
    super(page);
    this.btnAllocate = this.page
      .locator('.iconButton:text-is("Allocate")')
      .locator("visible=true");
    this.btnPost = this.page
      .locator('.iconButton:text-is("Post")')
      .locator("visible=true");
  }
}
