import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesPurchaseInvoicePage extends BasePage {
  readonly btnSave: Locator;
  readonly btnValidate: Locator;
  readonly btnAllocate: Locator;
  readonly btnApprove: Locator;
  readonly btnPost: Locator;

  // Warning dialog - "The following warnings have been generated, are you sure you want to continue?"
  readonly btnYes: Locator;
  readonly warningDialogText: Locator;

  // Contents Menu
  readonly tabDeliveryCost: Locator; // appears in Contents after double-clicking an invoice line
  readonly linkRUCInitialCost: Locator;
  readonly btnDispute: Locator;
  readonly btnUndispute: Locator;
  readonly btnCreditNote: Locator;

  //Recharge Section
  readonly customerApproved: Locator;

  readonly btnAdd: Locator;
  readonly btnNew: Locator;
  readonly btnSearchIcon: Locator;
  readonly btnSearch: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnSave = this.page
      .getByLabel("SaveSave pending changes")
      .locator("visible=true");
    this.btnAllocate = this.page
      .getByLabel("AllocateAllocate the purchase invoice")
      .locator("visible=true");
    this.btnValidate = this.page
      .getByLabel("ValidateValidate the purchase invoice")
      .locator("visible=true");
    this.btnApprove = this.page
      .getByLabel("ApproveApprove the purchase invoice")
      .locator("visible=true");
    this.btnPost = this.page
      .getByLabel("PostPost the purchase invoice")
      .locator("visible=true");

    this.btnAdd = this.page
      .getByLabel("Add (Ctrl+Insert)")
      .locator("visible=true");
    this.btnNew = this.page
      .getByLabel("NewRegister a new object.")
      .locator("visible=true");

    // Warning dialog
    this.btnYes = this.page.getByLabel("Yes").locator("visible=true");
    this.warningDialogText = this.page // to read the text get the aria-label attribute
      .locator(".messageWindowInformation")
      .locator("visible=true")
      .locator("[eventproxy^=isc_SilkLabel][aria-label]");

    // Contents Menu
    this.tabDeliveryCost = this.page
      .getByLabel("Delivery Cost")
      .locator(".tabButtonTop")
      .locator("visible=true");
    this.linkRUCInitialCost = this.page
      .locator('a:text-is("RUC Initial Cost")')
      .locator("visible=true");
    this.btnDispute = this.page
      .locator('[class*=iconButton]:has(span:text-is("Dispute"))')
      .locator("visible=true");
    this.btnUndispute = this.page
      .locator('[class*=iconButton]:has(span:text-is("Undispute"))')
      .locator("visible=true");
    this.btnCreditNote = this.page
      .getByLabel("Credit NoteCreate a credit note for the purchase invoice.")
      .locator("visible=true");

    this.customerApproved = this.page
      .locator(':has(td:text-is("Customer Approved"))>td.silkFormCheckBoxImg')
      .locator("visible=true");
    this.btnSearchIcon = this.page
      .locator(".silkTextItemPickerIcon img")
      .locator("visible=true");
    this.btnSearch = this.page
      .getByLabel("SearchExecute selection")
      .locator("visible=true")
      .last();
  }

  // PI > Contents > Invoice Lines table > double-click on the Vehicle
  async doubleClickVehicleInInvoiceLines(vehicleDescription: string) {
    if (vehicleDescription.length > 50) {
      vehicleDescription = vehicleDescription.substring(0, 50);
    }
    const item = this.page
      .locator("[eventproxy*=GeneralViewGrid]")
      .locator('td>div:has-text("' + vehicleDescription + '")');
    await item.dblclick();
  }

  // PI > Contents > Delivery Cost tab > edit Price for given type
  async updateDeliveryCostPrice(
    deliveryCostType: string,
    updateValueBy: number,
  ) {
    const price = this.page
      .locator('tr:has(a:text-is("' + deliveryCostType + '"))')
      .locator("visible=true")
      .locator("td")
      .nth(1); // column index 1
    const value = await price.innerText();
    const valueNum =
      Number(value.replace("$", "").replace(",", "")) + updateValueBy;
    await price.click();
    await this.page.keyboard.press("Backspace"); // price.clear() didn't work here
    await this.page.keyboard.type(valueNum.toString()); // price.type() didn't work here
  }
}
