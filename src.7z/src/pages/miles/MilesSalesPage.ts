import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesSalesPage extends BasePage {
  readonly salesRequests: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.salesRequests = this.page.locator('span:has-text("Requests")').first();
  }
}
