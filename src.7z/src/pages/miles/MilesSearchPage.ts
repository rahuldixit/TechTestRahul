import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";
import { SEARCH_CONTRACT_LABELS } from "../../../enums/milesapp";

export class MilesSearchPage extends BasePage {
  readonly selectionBox: Locator;
  readonly selectionDropdownIcon: Locator;
  readonly btnSearch: Locator;
  readonly referenceColumn: Locator;
  readonly searchResultList: Locator;
  readonly noContracts: Locator;
  readonly btnOpenObject: Locator;
  readonly btnLast: Locator; // to go to the last page in search results

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.selectionDropdownIcon = this.page
      .locator("[class^=silkTextItemPickerIcon] img")
      .last();
    this.selectionBox = this.page
      .locator('input[name="selection"]')
      .locator("visible=true");
    this.btnSearch = this.page.getByLabel("SearchExecute selection").last();
    this.referenceColumn = this.page
      .locator('.headerButton div:has-text("Reference")')
      .first();
    this.noContracts = this.page.locator("td.emptyMessage");
    this.searchResultList = this.page
      .locator("td[class*=cellSelected]")
      .locator("visible=true")
      .first()
      .or(
        this.page
          .locator("[eventproxy*=search_result]")
          .locator("td[class*=cellSelected]")
          .locator("visible=true")
          .first(),
      )
      .first();
    this.btnOpenObject = this.page
      .getByLabel("OpenOpen the detail page for the selected object (Ctrl+O)")
      .locator("visible=true");
    this.btnLast = this.page.getByLabel("Last").locator("visible=true");
  }

  async sortReferenceColumn() {
    await this.referenceColumn.click();
  }

  async enterContractStatus(contractStatus: string) {
    await this.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.CONTRACT_STATUS,
      contractStatus,
    );
  }

  async enterBillingStatus(billingStatus: string) {
    await this.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.BILLING_STATUS,
      billingStatus,
    );
  }

  async enterEndDate(date: string) {
    await this.enterDetailsByLabel(SEARCH_CONTRACT_LABELS.END_DATE, date);
  }

  async openFirstObjectFromList() {
    await this.btnOpenObject.click();
  }

  //Created for quomo Refinance and Formal Ext contracts - Please don't modify
  async retrieveContractDetailsFromTable(headerName: string) {
    await this.page
      .locator("td.headerButton")
      .first()
      .waitFor({ state: "visible" });
    const allHeaders = this.page.locator("td.headerButton");
    const headerTexts = await allHeaders.allInnerTexts();
    const index = headerTexts.indexOf(headerName);
    const value = this.page
      .locator("div.silkListGridBody")
      .nth(2)
      .locator("td")
      .nth(index - 2);
    return await value.textContent();
  }
}
