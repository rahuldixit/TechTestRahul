import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesSearchSalesRequestsPage extends BasePage {
  readonly newIcon: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.newIcon = this.page.getByLabel("NewRegister a new object.");
  }
}
