import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesSideBarPage extends BasePage {
  readonly btncreatePackage: Locator;
  readonly btnUpdatePackage: Locator;
  readonly updatePackageDropdown: Locator;
  readonly accountInformation: Locator;
  readonly packageInformation: Locator;
  readonly packageBalance: Locator;
  readonly packageService: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;

    this.btncreatePackage = this.page.locator("#btnCreatePackage");
    this.btnUpdatePackage = this.page.locator("button#btnUpdatePackage");
    this.updatePackageDropdown = this.page.locator("#updatepackagedropdown");
    this.accountInformation = this.page.locator(
      'span:has-text("Account Information")',
    );
    this.packageInformation = this.page.locator(
      'span:has-text("Package Information")',
    );
    this.packageBalance = this.page.locator(".card-title.right");
    this.packageService = this.page.locator('th:has-text("Package Service")');
  }

  async openMilesSidebar(
    url: string,
    sroid: string,
    contractReferenceNumber: string,
  ) {
    const sideBarUrl = `${url}/sidebar?sroid=${sroid}&objectId=${contractReferenceNumber}`;
    console.log("SideBar URL: " + sideBarUrl);
    await this.page.goto(sideBarUrl);
  }

  //Retrieves account and package information of the selected contract
  async retrieveContractInformation(fieldName: string) {
    const contractInfo = await this.page
      .locator(".row.dataRow")
      .filter({ hasText: fieldName })
      .locator(".col.s9")
      .innerText();
    return contractInfo;
  }

  //Retrieves actual balance from Package balance
  async retrieveActualBalance() {
    const thcontaining = this.page
      .locator("th.amount")
      .filter({ hasText: "Actual" });
    const actualBalance = this.page
      .locator("table")
      .filter({ has: thcontaining })
      .locator("tfoot td.amount")
      .nth(0)
      .innerText();
    return actualBalance;
  }

  //Retrieves pending balance from Package balance
  async retrievePendingBalance() {
    const thcontaining = this.page
      .locator("th.amount")
      .filter({ hasText: "Pending" });
    const pendingBalance = this.page
      .locator("table")
      .filter({ has: thcontaining })
      .locator("tfoot td.amount")
      .nth(1)
      .innerText();
    return pendingBalance;
  }

  //Retrieves available balance from Package balance
  async retrieveAvailableBalance() {
    const thcontaining = this.page
      .locator("th.amount")
      .filter({ hasText: "Available" });
    const availableBalance = this.page
      .locator("table")
      .filter({ has: thcontaining })
      .locator("tfoot td.amount")
      .nth(2)
      .innerText();
    return availableBalance;
  }

  async retrieveAvailableBalanceByServiceNameFromPackageBalance() {
    const table = this.page.locator(".widget-body table");
    await table.waitFor({ state: "visible" });
    const rows = await table.locator("tbody tr").all();

    const values = await Promise.all(
      rows.map(async (r) => {
        return {
          servicename: await r.locator("label").innerText(),
          availBal: await r.locator("td").last().innerText(),
        };
      }),
    );
    return values;
  }
}
