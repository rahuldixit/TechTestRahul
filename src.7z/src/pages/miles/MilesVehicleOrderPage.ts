import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class MilesVehicleOrderPage extends BasePage {
  readonly btnSearch: Locator;
  readonly btnTodayDateChooser: Locator;
  readonly btnSave: Locator;
  readonly btnRefresh: Locator;
  readonly btnValidate: Locator;
  readonly btnApprove: Locator;
  readonly btnNewInvoice: Locator;
  readonly contextStatus: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.btnSearch = this.page.getByLabel("SearchExecute selection").first();
    this.btnTodayDateChooser = this.page
      .locator(".dateChooserBorderedBottomButton")
      .filter({ hasText: "Today" });
    this.btnSave = this.page
      .getByRole("button", { name: "SaveSave pending changes" })
      .locator("visible=true");
    this.btnRefresh = this.page
      .getByRole("button", { name: "RefreshReload the page data" })
      .locator("visible=true");
    this.btnValidate = this.page
      .getByLabel("ValidateValidate the vehicle order")
      .locator("visible=true");
    this.btnApprove = this.page
      .getByLabel("ApproveApprove the vehicle order")
      .locator("visible=true");
    this.btnNewInvoice = this.page
      .getByLabel("New InvoiceCreate an invoice")
      .locator("visible=true");
    this.contextStatus = this.page
      .locator("[class*=silkContextCell]")
      .locator('input[name="A10282"]')
      .locator("visible=true");
  }
}
