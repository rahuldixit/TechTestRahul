import { Locator, Page } from "@playwright/test";
import { SuperPage } from "../common/SuperPage";

export class NBAHomePage extends SuperPage {
  readonly loggedUser: Locator;
  readonly specifiedContractRadioBtn: Locator;
  readonly specifyContractID: Locator;
  readonly btnRetrieve: Locator;
  readonly contractCheckbox: Locator;
  readonly btnReviewDetails: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.loggedUser = this.page.locator("span.spanauth");
    this.specifiedContractRadioBtn = this.page.locator(
      'label:has-text("Specified Contract")',
    );
    this.specifyContractID = this.page.locator("input#txtcontractlist");
    this.btnRetrieve = this.page.locator("input#btnretrieveid");
    this.contractCheckbox = this.page
      .locator('input[name="item.ISSELECTED"]')
      .first();
    this.btnReviewDetails = this.page.locator(".float-right.reviewButton");
  }

  async downloadContractDetailsToExcel() {
    const downloadPromise = this.page.waitForEvent("download");
    await this.btnReviewDetails.click();
    const download = await downloadPromise;
    return await download.path();
  }
}
