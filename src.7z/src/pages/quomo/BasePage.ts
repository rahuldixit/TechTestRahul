import { Locator, Page } from "@playwright/test";
import { SuperPage } from "pages/common/SuperPage";

export class BasePage extends SuperPage {
  //Common locators used while submitting quote attributes
  readonly quoteEmployeeNumber: Locator;
  readonly quoteAnnualSalary: Locator;
  readonly selectPostcode: Locator;
  readonly quotePostcode: Locator;
  readonly payCycleDropdown: Locator;
  readonly selectPayCycle: Locator;
  readonly btnContinue: Locator;
  readonly btnCancel: Locator;
  readonly verifySalaryInfoDialog: Locator;
  readonly btnConfirm: Locator;
  readonly btnCancelVerification: Locator;
  readonly quoteHeading: Locator;
  readonly quoteStatus: Locator;
  readonly contractPane: Locator;
  readonly currentContractTab: Locator;
  readonly modalDialogTitle: Locator;
  readonly btnClose: Locator;
  readonly tabPackageDetails: Locator;
  readonly radioButtonZLEVExempt: Locator;
  readonly btnNo: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.quoteEmployeeNumber = this.page.locator(
      'input[name="employeeNumber"]',
    );
    this.quoteAnnualSalary = this.page.locator('input[name="annualSalary"]');
    this.quotePostcode = this.page.locator('input[name="location"]');
    this.selectPostcode = this.page.locator("span.mdc-list-item__primary-text");
    this.payCycleDropdown = this.page.locator(
      "[name=selectedPayrollFrequency]",
    );
    this.selectPayCycle = this.page.locator("span.mdc-list-item__primary-text");
    this.btnContinue = this.page.locator(
      'span[class*=button]:text-is("Continue")',
    );
    this.btnCancel = this.page.locator('span[class*=button]:text-is("Cancel")');
    this.verifySalaryInfoDialog = this.page
      .locator('div:has-text(" Verify salary information ")')
      .last();
    this.btnConfirm = this.page.locator('span:has-text("Confirm")');
    this.btnCancelVerification = this.page.locator('span:has-text("Cancel")');
    this.quoteHeading = this.page.locator("div.quoteHeading div");
    this.quoteStatus = this.page.locator("div.status");
    this.contractPane = this.page.locator('div[data-cy="cy-SummaryContract"]');
    this.currentContractTab = this.page
      .locator('span:has-text("Current contract")')
      .last();
    // modial dialogs can appear on top of each other, there could be 2 on the screen
    // This will get the last one which should be in front. Or the error
    this.modalDialogTitle = this.page
      .locator("div[id*=mat-mdc-dialog-title]")
      .last()
      .or(this.page.locator('[class*="errorTitle"]'))
      .last();
    this.btnClose = this.page.locator('span[class*=button]:text-is("Close")');
    this.tabPackageDetails = this.page.getByText("Package details");
    this.radioButtonZLEVExempt = this.page.locator(
      'xpath=//label[contains(.,"ZLEV exempt - No FBT liability as per electric car discount bill 2022")]/..//input',
    );
    this.btnNo = this.page.locator('span[class*=button]:text-is("No")');
  }

  async selectPostcodeInAttributes(postCode: string) {
    await this.quotePostcode.clear();
    await this.quotePostcode.click();
    await this.quotePostcode.type(postCode, { delay: 10 });
    // Need to wait for drop-down options to update
    await this.page.waitForTimeout(700);
    await this.page.waitForSelector("div.mat-mdc-autocomplete-panel", {
      timeout: 30000,
    });
    await this.selectPostcode.first().click();
  }

  // Given a locator, this will type the value and check that it matches
  async typeValueIntoLocator(locator: Locator, value: string) {
    await locator.clear();
    await locator.type(value, { delay: 10 });
    const inputValue = await locator.inputValue();
    if (inputValue !== value) {
      await this.typeValueIntoLocator(locator, value);
    }
  }

  async selectDropDownOption(optionName: string, selector?: Locator) {
    if (selector) {
      await selector.locator(`mat-option :text-is("${optionName}")`).click();
    } else {
      this.page.getByRole("option", { name: optionName }).click();
    }
  }
}
