import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class QuomoIndicativeQuotePage extends BasePage {
  readonly toggleOppurtunityBar: Locator;
  readonly employeeName: Locator;
  readonly employeeMobNum: Locator;
  readonly employeePayCycle: Locator;
  readonly employer: Locator;
  readonly addPaintandTrim: Locator;
  readonly btnSave: Locator;
  readonly indicativeQuoteStatus: Locator;
  readonly indicativeQuoteCard: Locator;
  readonly contractDetails: Locator;
  readonly btnCreateFirm: Locator;
  readonly verifyAttributesHeader: Locator;
  readonly preferredDeliveryDate: Locator;
  readonly notes: Locator;
  readonly firmQuoteCard: Locator;
  readonly validationError: Locator;
  readonly quoteLinkInCard: Locator;
  readonly inputEmployerArrangedInsuranceAmount: Locator;
  readonly inputFuelMonthly: Locator;
  readonly inputMaintenanceMonthly: Locator;
  readonly inputTyresMonthly: Locator;
  readonly warningMessageFuel: Locator;
  readonly warningMessageMaintenance: Locator;
  readonly warningMessageTyres: Locator;
  readonly dropdownVariationReasonInFuel: Locator;
  readonly dropdownVariationReasonInMaintenance: Locator;
  readonly dropdownVariationReasonInTyres: Locator;

  //quotes actions
  readonly quoteCardCheckboxes: Locator;
  readonly actionsDropdown: Locator;
  readonly compare: Locator;
  readonly discard: Locator;
  readonly discardStatus: Locator;
  readonly restore: Locator;
  readonly showDiscarded: Locator;
  readonly hideDiscarded: Locator;
  readonly compareQuoteDialog: Locator;
  // Send & View VSSS
  readonly btnSendVSSS: Locator;
  readonly sendVSSSDialog: Locator;
  readonly emailTo: Locator;
  readonly subject: Locator;
  readonly personalisedMessage: Locator;
  readonly emailPreview: Locator;
  readonly btnSend: Locator;
  readonly sendingVSSSEmail: Locator;
  readonly toggleDropDown: Locator;
  readonly viewVSSS: Locator;
  readonly vsssPDF: Locator;
  // Trade advantage
  readonly tradeAdvantageDownArrowKey: Locator;
  readonly emailHistoryOption: Locator;
  readonly employerApprovalOption: Locator;
  readonly emailHistoryDetails: Locator;
  readonly pdfFsgAuditTab: Locator;
  readonly pdfFsgAuditHistory: Locator;
  readonly checkWindowHeader: Locator;
  readonly approverEmail: Locator;
  readonly selectDocument: Locator;
  readonly confirmCheckbox: Locator;
  readonly btnCloseHistory: Locator;

  // Submit order
  readonly btnSubmitOrder: Locator;
  readonly submitOrderDialogHeader: Locator;
  readonly deliveryContactName: Locator;
  readonly deliveryContactemail: Locator;
  readonly deliveryContactPhone: Locator;
  readonly deliveryLocation: Locator;
  readonly financeApproverRefNum: Locator;
  readonly employeeNumber: Locator;
  readonly submitSuccessfulDialog: Locator;
  readonly submitSuccessfulMessage: Locator;
  //Retrieve values from Attributes header
  readonly retrieveAttributeValues: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.toggleOppurtunityBar = this.page.locator(
      "div.ng-tns-c288-1.opportunityAction",
    );
    this.employeeName = this.page.locator('div[data-cy="cy-EmployeeLabel"]');
    this.employeeMobNum = this.page.locator('div[data-cy="cy-MobilePhone"]');
    this.employeePayCycle = this.page.locator('div[data-cy="cy-PayCycle"]');
    this.employer = this.page.locator('div[data-cy="cy-EmployerName"]');
    this.addPaintandTrim = this.page.locator("a.ng-star-inserted");
    this.btnSave = this.page.locator('button[data-cy="cy-QuoteSave"]');
    this.indicativeQuoteStatus = this.page.locator(
      "div.mat-mdc-tooltip-trigger.quoteStatus.ng-star-inserted",
    );
    this.indicativeQuoteCard = this.page
      .locator("div.quoteCard")
      .filter({ hasText: "Indicative" });

    this.contractDetails = this.page.locator("div.contractDetails");
    this.btnCreateFirm = this.page.locator(
      'button[data-cy="cy-CreateFirmButton"]',
    );
    this.verifyAttributesHeader = this.page.locator(".mat-mdc-dialog-title");
    this.preferredDeliveryDate = this.page
      .locator('input[name="preferredDeliveryDateControl"]')
      .last();
    this.notes = this.page.locator("textarea.mat-mdc-input-element");
    this.firmQuoteCard = this.page
      .locator("div.quoteCard")
      .filter({ hasText: "Firm" });
    this.validationError = this.page
      .locator("app-error-page.ng-star-inserted")
      .first();
    this.quoteLinkInCard = this.page.locator("a.mat-mdc-tooltip-trigger");
    this.inputEmployerArrangedInsuranceAmount = this.page.locator(
      '[data-cy="cy-EmployeearrangedInsuranceAmount"]',
    );
    this.inputFuelMonthly = this.page
      .locator("app-services-fuel")
      .getByLabel("Monthly");
    this.inputMaintenanceMonthly = this.page
      .locator("app-services-maintenance")
      .getByLabel("Monthly");
    this.inputTyresMonthly = this.page
      .locator("app-services-tyre")
      .getByLabel("Monthly");
    this.warningMessageFuel = this.page
      .locator("app-services-fuel")
      .filter({ has: page.locator("div.message") });
    this.warningMessageMaintenance = this.page
      .locator("app-services-maintenance")
      .filter({ has: page.locator("div.message") });
    this.warningMessageTyres = this.page
      .locator("app-services-tyre")
      .filter({ has: page.locator("div.message") });
    this.dropdownVariationReasonInFuel = this.page
      .locator("app-services-fuel")
      .locator('[class*=form-field-flex]:has(:text-is("Variation reason"))');
    this.dropdownVariationReasonInMaintenance = this.page
      .locator("app-services-maintenance")
      .locator('[class*=form-field-flex]:has(:text-is("Variation reason"))');
    this.dropdownVariationReasonInTyres = this.page
      .locator("app-services-tyre")
      .locator('[class*=form-field-flex]:has(:text-is("Variation reason"))');

    //quotes actions
    this.quoteCardCheckboxes = this.page.locator(
      "app-quote-card .mdc-checkbox__native-control",
    );
    this.actionsDropdown = this.page.locator('label:has-text("Actions")');
    this.compare = this.page.locator('span:has-text("Compare")');
    this.discard = this.page.getByRole("menuitem", {
      name: "Discard",
      exact: true,
    });
    this.discardStatus = this.page.locator(".discarded.ng-star-inserted");
    this.restore = this.page.locator('span:has-text("Restore")');
    this.showDiscarded = this.page.getByRole("menuitem", {
      name: "Show discarded",
    });
    this.hideDiscarded = this.page.getByRole("menuitem", {
      name: "Hide discarded",
    });
    this.compareQuoteDialog = this.page.locator("div.mdc-dialog__container");
    // Send & View VSSS
    this.btnSendVSSS = this.page.locator(
      'button[data-cy="cy-CreateFirmButton"]',
    );
    this.sendVSSSDialog = this.page.locator("div.container");
    this.emailTo = this.page.locator("textarea[name='to']");
    this.subject = this.page.locator("textarea[name='subject']");
    this.personalisedMessage = this.page.locator("textarea#message");
    this.emailPreview = this.page.locator("table.master-table");
    this.btnSend = this.page.locator('button[type="submit"]');
    this.sendingVSSSEmail = this.page.locator(
      "div.mat-mdc-snack-bar-label.mdc-snackbar__label",
    );
    this.toggleDropDown = this.page
      .locator("button.mat-mdc-menu-trigger.accessoryMenu")
      .last();
    this.viewVSSS = this.page.locator('span:has-text("View VSSS")');
    this.vsssPDF = this.page.locator("div.pdfViewer");
    //Trade advantage
    this.tradeAdvantageDownArrowKey = this.page
      .locator("button.mat-mdc-menu-trigger.accessoryMenu")
      .first();
    this.emailHistoryOption = this.page.locator(
      'span:has-text("Email History")',
    );
    this.employerApprovalOption = this.page.locator(
      'span:has-text("Employer approval")',
    );
    this.emailHistoryDetails = this.page.locator(
      "div.email-history.ng-star-inserted",
    );
    this.pdfFsgAuditTab = this.page
      .getByRole("tab", { name: "PDS/FSG audit" })
      .locator("span")
      .nth(1);
    this.pdfFsgAuditHistory = this.page.locator("div.pds-fsg-audit");
    this.checkWindowHeader = this.page.locator("header");
    this.approverEmail = this.page.locator('input[name="to"]');
    this.selectDocument = this.page.locator(
      "div.attachment div div.mdc-checkbox",
    );
    this.confirmCheckbox = this.page.locator("input#confirm-input");
    this.btnCloseHistory = this.page.getByRole("button", { name: "Close" });
    // Submit order
    this.btnSubmitOrder = this.page.locator('span:has-text("Submit order")');
    this.submitOrderDialogHeader = this.page.locator("div.submit-order__title");
    this.deliveryContactName = this.page.locator('input[name="deliveryName"]');
    this.deliveryContactemail = this.page.locator(
      'input[name="deliveryEmail"]',
    );
    this.deliveryContactPhone = this.page.locator(
      'input[name="deliveryPhone"]',
    );
    this.deliveryLocation = this.page.locator('input[name="location"]');
    this.financeApproverRefNum = this.page.locator(
      'input[name="approvalReferenceNo"]',
    );
    this.employeeNumber = this.page.locator('input[name="employeeNumber"]');
    this.submitSuccessfulDialog = this.page.locator("div.cdk-overlay-pane");
    this.submitSuccessfulMessage = this.page
      .locator("div div.dialogTitle")
      .last();
    //Retrieve values from Attributes header
    this.retrieveAttributeValues = this.page.locator(
      "div.attributeValue.ng-tns-c288-1 span",
    );
  }

  async getOppurtunityID() {
    const attributeName = this.page
      .locator("div.headerItem.ng-tns-c288-1")
      .filter({ hasText: "Opportunity id" });
    const oppurtunityID = attributeName.locator("div").last().innerText();
    return oppurtunityID;
  }

  async getEmailAddress() {
    const attributeName = this.page
      .locator("div.headerItem.ng-tns-c288-1")
      .filter({ hasText: "Email" });
    const emailAddress = attributeName.locator("div").last().innerText();
    return emailAddress;
  }

  async getEmployeeAnnualSalary() {
    const attributeName = this.page
      .locator("div.headerItem.ng-tns-c288-1")
      .filter({ hasText: "Annual salary" });
    const annualSalary = attributeName.locator("div").last().innerText();
    return annualSalary;
  }

  async getEmployeePostcode() {
    const attributeName = this.page
      .locator("div.headerItem.ng-tns-c288-1")
      .filter({ hasText: "Postcode" });
    const postcode = attributeName.locator("div").last().innerText();
    return postcode;
  }

  async getEmployeeNumber() {
    const attributeName = this.page
      .locator("div.headerItem.ng-tns-c288-1")
      .filter({ hasText: "Employee number" });
    const employeeNumber = attributeName.locator("div").last().innerText();
    return employeeNumber;
  }

  async carColourSelection(colour: string) {
    await this.page
      .locator("div.mdc-form-field")
      .getByLabel(colour)
      .scrollIntoViewIfNeeded();
    await this.page.locator("div.mdc-form-field").getByLabel(colour).click();
  }

  async selectNoInComprehensiveInsurance() {
    const optionNo = this.page
      .locator(`app-services-comprehensive-insurance .answer`)
      .locator('label:has-text("No")');

    await optionNo.first().click();
    await optionNo.nth(1).click();
    await optionNo.last().click();
    // await this.page.locator('input[name="mat-radio-group-29"]').last().scrollIntoViewIfNeeded()
    // await this.page.locator('input[name="mat-radio-group-29"]').last().click();
    // await this.page.locator('input[name="mat-radio-group-32"]').last().click();
    // await this.page.locator('input[name="mat-radio-group-35"]').last().click();
  }

  async inputValueInServiceType(serviceType: Locator, monthlyAmount: number) {
    await serviceType.clear();
    await serviceType.type(String(monthlyAmount), { delay: 10 });
    const inputValue = await serviceType.inputValue();
    if (inputValue !== String(monthlyAmount)) {
      await this.inputValueInServiceType(serviceType, monthlyAmount);
    }
  }

  async getPricingDifferenceByType() {
    const amountFields = this.page.locator("td span.amount.ng-star-inserted");
    await amountFields.first().waitFor({ state: "visible" });
    const rowsContainingAmount = await this.page
      .locator("tr")
      .filter({ has: amountFields })
      .all();

    const values = await Promise.all(
      rowsContainingAmount.map(async (r) => {
        const header = await r.locator("th").textContent();
        const value = await r.locator(amountFields).textContent();
        return {
          header,
          value,
        };
      }),
    );
    return values;
  }

  // the serviceTitle is the title that appears in the Contract tab in the same row as the radio button
  // Note: this function will work for most radio buttons, but not the the ones in the 3 LeaseGuard questions.
  async selectRadioButton(label: string, serviceTitle?: string) {
    if (serviceTitle) {
      await this.page
        .locator(`.serviceTitleBar:has(:text-is("${serviceTitle}"))`)
        .getByRole("radiogroup")
        .locator(`:text-is("${label}")`)
        .click();
    } else {
      await this.page
        .getByRole("radiogroup")
        .locator(`:text-is("${label}")`)
        .click();
    }
  }
}
