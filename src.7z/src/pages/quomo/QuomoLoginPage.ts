import { Page, Locator } from "@playwright/test";
import { BasePage } from "./BasePage";

export class QuomoLoginPage extends BasePage {
  readonly textboxTicketNum: Locator;
  readonly quomoSearchButton: Locator;
  readonly quomoCloseButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.textboxTicketNum = this.page.locator("input.ng-pristine");
    this.quomoSearchButton = this.page.locator('span:has-text("Search")');
    this.quomoCloseButton = this.page.locator('span:has-text("Close")');
  }

  async openQuomo(url: string) {
    await this.page.goto(url, { timeout: 30000 });
  }
}
