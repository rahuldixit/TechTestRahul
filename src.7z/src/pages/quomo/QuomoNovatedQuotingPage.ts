import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class QuomoNovatedPage extends BasePage {
  readonly acknowledgeBtn: Locator;
  readonly vehicleMakeandModel: Locator;
  readonly selectVehicle: Locator;
  readonly btnFindCars: Locator;
  readonly expandorCollapseQuotes: Locator;
  readonly checkboxZlev: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.acknowledgeBtn = this.page.locator(
      'span[class*=button]:text-is("Acknowledge")',
    );
    this.vehicleMakeandModel = this.page.locator(
      "input.mat-mdc-chip-input.mat-mdc-input-element",
    );
    this.selectVehicle = this.page.locator("span.mdc-list-item__primary-text");
    this.btnFindCars = this.page.locator('span:has-text("Find cars")');
    this.expandorCollapseQuotes = this.page.locator("span.separatorQuotes");
    this.checkboxZlev = this.page.getByLabel("ZLEV eligible vehicles");
  }

  async selectVehicleMakeandModel(vehicleModel: string) {
    await this.vehicleMakeandModel.type(vehicleModel);
    await this.page.waitForSelector("div.mat-mdc-autocomplete-panel", {
      timeout: 10000,
    });
    await this.selectVehicle.getByText(vehicleModel, { exact: true }).click();
  }

  async findCars() {
    await this.btnFindCars.click();
  }

  async waitFor() {
    await this.modalDialogTitle.waitFor();
  }
}
