import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class QuomoRefinanceQuotePage extends BasePage {
  readonly existingLeaseTitle: Locator;
  readonly btnQuoteRefinance: Locator;
  readonly btnQuoteExtension: Locator;
  readonly refQuoteAttributeDialog: Locator;
  readonly refQuoteCurrentOdometer: Locator;
  readonly refQuoteAnnualKM: Locator;
  readonly regExpiryDate: Locator;
  readonly refQuoteRefinanceTerm: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.existingLeaseTitle = this.page.locator("div.ltc-title");
    this.btnQuoteRefinance = this.page.locator(
      'span:has-text("Quote refinance")',
    );
    this.btnQuoteExtension = this.page.locator(
      'span:has-text("Quote extension")',
    );
    this.refQuoteAttributeDialog = this.page.locator(
      "div.quote-refinance-dialog",
    );
    this.refQuoteCurrentOdometer = this.page.locator(
      'input[name="currentOdometer"]',
    );
    this.regExpiryDate = this.page.locator(
      'input[name="registrationExpiryDateControl"]',
    );
    this.refQuoteAnnualKM = this.page.locator('input[name="annualKM"]');
    this.refQuoteRefinanceTerm = this.page.locator(
      'input[name="refinanceTerm"]',
    );
  }
}
