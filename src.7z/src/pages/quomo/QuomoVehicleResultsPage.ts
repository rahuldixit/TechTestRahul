import { Locator, Page } from "@playwright/test";
import { BasePage } from "./BasePage";

export class QuomoVehicleResultsPage extends BasePage {
  readonly showorHideSearch: Locator;
  readonly checkPageHeader: Locator;
  readonly searchedVehicleCount: Locator;
  readonly btnCollapseAll: Locator;
  readonly btnReset: Locator;
  readonly checkStatus: Locator;
  readonly vehicleInfo: Locator;
  readonly btnConfigure: Locator;
  readonly quoteAttributeTitle: Locator;
  readonly quoteAnnualKm: Locator;
  readonly procurementTypeDropdown: Locator;
  readonly selectProcurement: Locator;
  readonly quoteTerm: Locator;
  readonly purchaseTypeDropdown: Locator;
  readonly selectPurchaseType: Locator;
  readonly inputBuildDate: Locator;
  readonly inputRegistrationExpiry: Locator;
  readonly inputCurrentOdometer: Locator;
  readonly dropdownVehicleSource: Locator;
  readonly selectVehicleSource: Locator;
  readonly inputFBTCostBase: Locator;
  readonly inputZLEVFirstHeldDate: Locator;
  readonly inputZLEVFirstPurchasePrice: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.showorHideSearch = this.page.locator(
      "span.separatorSearch.ng-star-inserted",
    );
    this.checkPageHeader = this.page.locator(".mainItems.mainHeader");
    this.searchedVehicleCount = this.page.locator(".mainItems.resultCount");
    this.btnCollapseAll = this.page.locator('span:has-text("Collapse all")');
    this.btnReset = this.page.locator('span:has-text("Reset")');
    this.checkStatus = this.page.locator("div.status");
    this.vehicleInfo = this.page.locator("div.vehicleInfoRow");
    this.btnConfigure = this.page.locator("div.expandCollapseConfigure button");
    this.quoteAttributeTitle = this.page.locator("div.opportunityDialogTitle");
    this.quoteAnnualKm = this.page.locator('input[name="annualKms"]');
    this.procurementTypeDropdown = this.page.locator(
      "[name=selectedProcurementType]",
    );
    this.selectProcurement = this.page.locator(
      "span.mdc-list-item__primary-text",
    );

    this.quoteTerm = this.page.locator('input[name="term"]');
    this.purchaseTypeDropdown = this.page.locator(
      "[name=selectedPurchaseType]",
    );
    this.selectPurchaseType = this.page.locator(
      "span.mdc-list-item__primary-text",
    );
    this.inputBuildDate = this.page.locator('[name="buildDateControl"]');
    this.inputRegistrationExpiry = this.page.locator(
      '[name="registrationExpiryDateControl"]',
    );
    this.inputCurrentOdometer = this.page.locator('[name="currentOdometer"]');
    this.dropdownVehicleSource = this.page.locator(
      '[name="vehicleSourceSelect"]',
    );
    this.selectVehicleSource = this.page.locator(".mat-mdc-select-panel");
    this.inputFBTCostBase = this.page.locator('[name="fbtCostBase"]');
    this.inputZLEVFirstHeldDate = this.page.locator(
      '[name="evFirstHeldDateControl"]',
    );
    this.inputZLEVFirstPurchasePrice = this.page.locator(
      '[name="evfirstPurchasePriceOverride"]',
    );
  }

  async selectExpandByVehicleName(vehicleName: string) {
    const brandName = this.page
      .locator("div.makeBrand")
      .getByText(vehicleName, { exact: true });
    await this.page
      .locator("div.groupContent.ng-star-inserted")
      .filter({ has: brandName })
      .locator("button.exCoButton")
      .click();
  }

  async selectVehicleToConfigure() {
    await this.checkStatus.first().isVisible();
    await this.vehicleInfo.first().isVisible();
    await this.btnConfigure.first().click();
  }

  async waitFor() {
    await this.searchedVehicleCount.waitFor();
  }
}
