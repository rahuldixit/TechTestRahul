import { Page, expect } from "@playwright/test";
import { QuomoRefinanceQuotePage } from "../../pages/quomo/QuomoRefinanceQuotePage";
import { faker } from "@faker-js/faker";

export class VerifyBalanceInQuote {
  page: Page;
  quomoRefQuote: QuomoRefinanceQuotePage;

  constructor(page: Page) {
    this.page = page;
    this.quomoRefQuote = new QuomoRefinanceQuotePage(page);
  }

  async submitRefinanceQuoteAttributes({
    currentOdo = faker.number.int({ min: 100000, max: 150000 }) + "",
    annualKM = faker.number.int({ min: 100000, max: 150000 }) + "",
    postcode,
    registrationExpDate,
    payCycle,
    refTerm,
    annualSal = faker.number.int({ min: 100000, max: 150000 }) + "",
  }: {
    currentOdo?: string;
    annualKM?: string;
    postcode: string;
    registrationExpDate: string;
    payCycle?: string;
    refTerm: string;
    annualSal?: string;
  }) {
    await expect(this.quomoRefQuote.existingLeaseTitle).toBeVisible({
      timeout: 5000,
    });
    await this.quomoRefQuote.btnQuoteRefinance.click();
    await expect(this.quomoRefQuote.refQuoteAttributeDialog).toBeVisible({
      timeout: 5000,
    });
    await this.page.waitForLoadState("domcontentloaded");
    await this.quomoRefQuote.selectPostcodeInAttributes(postcode);
    await this.quomoRefQuote.refQuoteAnnualKM.fill(annualKM);
    await this.quomoRefQuote.regExpiryDate.fill(registrationExpDate);
    await this.quomoRefQuote.refQuoteCurrentOdometer.fill(currentOdo);

    !!payCycle &&
      (await this.quomoRefQuote.payCycleDropdown.click(),
      await this.quomoRefQuote.selectPayCycle
        .filter({ hasText: payCycle })
        .click());
    await this.quomoRefQuote.refQuoteRefinanceTerm.fill(refTerm);
    await this.quomoRefQuote.quoteAnnualSalary.fill(annualSal);
    await this.quomoRefQuote.btnContinue.click();
    await expect(this.quomoRefQuote.verifySalaryInfoDialog).toBeVisible({
      timeout: 5000,
    });
    await this.quomoRefQuote.btnConfirm.click();
  }

  async submitFormalExtensionQuoteAttributes({
    currentOdo = faker.number.int({ min: 100000, max: 150000 }) + "",
    annualKM = faker.number.int({ min: 100000, max: 150000 }) + "",
    postcode,
    registrationExpDate,
    payCycle,
    refTerm,
    annualSal = faker.number.int({ min: 100000, max: 150000 }) + "",
  }: {
    currentOdo?: string;
    annualKM?: string;
    postcode: string;
    registrationExpDate: string;
    payCycle?: string;
    refTerm: string;
    annualSal?: string;
  }) {
    await expect(this.quomoRefQuote.existingLeaseTitle).toBeVisible({
      timeout: 5000,
    });
    await this.quomoRefQuote.btnQuoteExtension.click();
    await expect(this.quomoRefQuote.refQuoteAttributeDialog).toBeVisible({
      timeout: 5000,
    });
    await this.page.waitForLoadState("domcontentloaded");
    await this.quomoRefQuote.refQuoteCurrentOdometer.type(currentOdo);
    await this.quomoRefQuote.selectPostcodeInAttributes(postcode);
    await this.quomoRefQuote.refQuoteAnnualKM.fill(annualKM);
    await this.quomoRefQuote.regExpiryDate.fill(registrationExpDate);

    !!payCycle &&
      (await this.quomoRefQuote.payCycleDropdown.click(),
      await this.quomoRefQuote.selectPayCycle
        .filter({ hasText: payCycle })
        .click());
    await this.quomoRefQuote.refQuoteRefinanceTerm.fill(refTerm);
    await this.quomoRefQuote.quoteAnnualSalary.fill(annualSal);
    await this.quomoRefQuote.btnContinue.click();
    await expect(this.quomoRefQuote.verifySalaryInfoDialog).toBeVisible({
      timeout: 5000,
    });
    await this.quomoRefQuote.btnConfirm.click();
  }

  async verifyIndicativeRefinanceQuoteHeader() {
    await this.quomoRefQuote.quoteHeading.first().isVisible({ timeout: 5000 });
    await expect(this.quomoRefQuote.quoteHeading.first()).toHaveText(
      "Indicative refinance quote",
      { timeout: 15000 },
    );
  }

  async verifyIndicativeExtensionQuoteHeader() {
    await this.quomoRefQuote.quoteHeading.first().isVisible({ timeout: 5000 });
    await expect(this.quomoRefQuote.quoteHeading.first()).toHaveText(
      "Indicative extension quote",
      { timeout: 15000 },
    );
  }

  async retrieveAvailableBalanceByServiceName() {
    await this.quomoRefQuote.contractPane.click();
    await this.quomoRefQuote.currentContractTab.scrollIntoViewIfNeeded();
    await this.quomoRefQuote.currentContractTab.click();
    const table = this.page
      .locator(".mat-accordion")
      .filter({ hasText: "Available balance summary" });
    const rows = await table.locator(".row.ng-star-inserted").all();

    const values = await Promise.all(
      rows.map(async (r) => {
        return {
          servicename: await r.locator("div.col1").first().innerText(),
          availBal: await r.locator("div.cols").last().innerText(),
        };
      }),
    );
    return values;
  }
}
