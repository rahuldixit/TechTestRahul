import { Page } from "@playwright/test";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";

export class MsOnlineLogin {
  msOnlineLoginPage: MsOnlineLoginPage;

  constructor(page: Page) {
    this.msOnlineLoginPage = new MsOnlineLoginPage(page);
  }

  async loginIntoMicrosoftAccount(email: string, password: string) {
    await this.msOnlineLoginPage.doLogin(email, password);
  }
}
