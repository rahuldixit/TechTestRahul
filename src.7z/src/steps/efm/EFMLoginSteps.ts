import { EFMLoginPage } from "../../pages/efm/EFMLoginPage";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { Page } from "@playwright/test";

export class LoginIntoEFM {
  efmLoginPage: EFMLoginPage;
  efmHomePage: EFMHomePage;
  page: Page;

  constructor(page: Page) {
    this.efmLoginPage = new EFMLoginPage(page);
    this.efmHomePage = new EFMHomePage(page);
    this.page = page;
  }

  async loginIntoEFM(url: string, username: string, password: string) {
    console.log("URL: " + url);
    console.log("Username: " + username);
    await this.efmLoginPage.openEFM(url);
    await this.efmLoginPage.efmUserName.fill(username);
    await this.efmLoginPage.efmPassword.fill(password);
    await this.efmLoginPage.btnLoginEFM.click();
    await this.page.waitForTimeout(7 * 1000);
    await this.efmHomePage.waitFor();
    await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });
  }
}
