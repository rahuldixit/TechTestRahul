import { Page, expect } from "@playwright/test";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { EFMRecostingPage } from "../../pages/efm/EFMRecostingsPage";
import { FDTPage } from "../../pages/efm/EFMFDTDataEntryPage";
import { EFMAdminPage } from "../../pages/efm/EFMAdminPage";
import { EFMFleetpage } from "../../pages/efm/EFMFleetPage";
import { EFMPaymentsPage } from "../../pages/efm/EFMFBTPaymentsPage";
import { EFMReportsPage } from "../../pages/efm/EFMFBTReportsPage";
import { EFMClientsPage } from "../../pages/efm/EFMClientsPage";

export class NavigateToPage {
  readonly page: Page;
  efmHomePage: EFMHomePage;
  efmRecostingPage: EFMRecostingPage;
  efmFDTPage: FDTPage;
  efmAdminPage: EFMAdminPage;
  efmFleetPage: EFMFleetpage;
  efmPaymentsPage: EFMPaymentsPage;
  efmReportsPage: EFMReportsPage;
  efmClientsPage: EFMClientsPage;

  constructor(page: Page) {
    this.page = page;
    this.efmHomePage = new EFMHomePage(page);
    this.efmRecostingPage = new EFMRecostingPage(page);
    this.efmFDTPage = new FDTPage(page);
    this.efmAdminPage = new EFMAdminPage(page);
    this.efmFleetPage = new EFMFleetpage(page);
    this.efmPaymentsPage = new EFMPaymentsPage(page);
    this.efmReportsPage = new EFMReportsPage(page);
    this.efmClientsPage = new EFMClientsPage(page);
  }

  async navigateToRecostingPage() {
    await this.efmHomePage.linkRecosting.click();
    await expect(this.efmRecostingPage.headerRecosting).toBeVisible();
  }

  async navigateToFDTDataEntryPage() {
    await this.efmFDTPage.linkFDTDataEntry.click();
    await expect(this.efmFDTPage.productHeader).toBeVisible();
  }

  async navigateToAdminPage() {
    await this.efmHomePage.linkAdmin.click();
    await this.efmHomePage.clickSideMenu("Running Processes");
    await expect(this.efmAdminPage.headingEFMProcessMonitoring).toBeVisible();
    await expect(this.efmAdminPage.headingRunPostTransactions).toBeVisible();
  }

  async navigateToFBTReports() {
    await this.efmHomePage.linkFleet.click();
    await this.efmFleetPage.linkFBTReport.click();
    await expect(this.efmReportsPage.headingFBTReports).toBeVisible();
    await expect(this.efmReportsPage.headingFBTCompanyReport).toBeVisible();
  }

  async navigateToFBTPayments() {
    await this.efmHomePage.linkFleet.click();
    await this.efmFleetPage.linkFBTPayments.click();
    await expect(this.efmPaymentsPage.headingFBTPayments).toBeVisible();
    await expect(this.efmPaymentsPage.headingRunStandardFBT).toBeVisible();
  }

  async navigateToClients() {
    await this.efmHomePage.linkClients.click();
    await expect(this.efmClientsPage.headerClients).toBeVisible();
  }
}
