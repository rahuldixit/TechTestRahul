import { Page } from "@playwright/test";
import { EFMRecostingPage } from "../../pages/efm/EFMRecostingsPage";
import { readOutlookEmails } from "utils/emailReader";

export class RecostingSteps {
  recostingsPage: EFMRecostingPage;
  readonly page: Page;

  constructor(page: Page) {
    this.recostingsPage = new EFMRecostingPage(page);
    this.page = page;
  }

  async completeRecostRequest(data: any) {
    await this.recostingsPage.clickSideMenu("Recostings");
    await this.recostingsPage.btnAddRecostingRequest.click();
    await this.recostingsPage.selectSummary.click();
    await this.recostingsPage.selectSummary.selectOption({
      label: data.summaryOption,
    });
    await this.recostingsPage.btnSummarySave.click();
    await this.recostingsPage.linkLatestRequest.click();
    await this.recostingsPage.btnRecost.click();
    await this.recostingsPage.btnRecost2.click();
    await this.recostingsPage.btnRecostConfirm.click();
    await this.setManualOverrides();
    await this.recostingsPage.btnNextViewSummary.click();
    await this.recostingsPage.btnNextViewQuote.click();
    await this.recostingsPage.btnSaveRecosting.click();
    await this.recostingsPage.textArea.type(data.description);
    await this.recostingsPage.btnConfirmSave.click();
    await this.editEmailRecipientsAndSendEmail(data);
  }

  async verifyRecostEmailSubject(
    expectedSubject: string,
    username: string,
    password: string,
  ) {
    await readOutlookEmails(this.page, username, password, expectedSubject);
  }

  async getOverrideValue(recommendedValue: string) {
    return (Number(recommendedValue) + Number(0.01)).toFixed(2).toString();
  }

  async setManualOverrides() {
    const recostInput = await this.recostingsPage.getRecostInputLocator(4, 0);
    const recommendedValue = await this.recostingsPage.getRecommendedValue(
      3,
      0,
    );
    const overrideValue = await this.getOverrideValue(recommendedValue);
    await recostInput.clear();
    await recostInput.type(overrideValue);
    for (let i = 0; i < 9; i++) {
      const recostInput = await this.recostingsPage.getRecostInputLocator(6, i);
      const recommendedValue = await this.recostingsPage.getRecommendedValue(
        5,
        i + 1,
      );
      const overrideValue = await this.getOverrideValue(recommendedValue);
      await recostInput.clear();
      await recostInput.type(overrideValue);
    }
    for (let i = 0; i < 6; i++) {
      const recostInput = await this.recostingsPage.getRecostInputLocator(3, i);
      const recommendedValue = await this.recostingsPage.getRecommendedValue(
        2,
        i + 10,
      );
      const overrideValue = await this.getOverrideValue(recommendedValue);
      await recostInput.clear();
      await recostInput.type(overrideValue);
    }
  }

  async editEmailRecipientsAndSendEmail(data: any) {
    await this.recostingsPage.btnEditRecipients.click();
    await this.recostingsPage.emailRecipients.clear();
    await this.recostingsPage.emailRecipients.type(data.emailAddress);
    await this.recostingsPage.btnSaveEmailAddress.click();
    await this.recostingsPage.emailTemplate.selectOption({
      label: data.templateDescription,
    });
    await this.recostingsPage.btnSendEmail.click();
    await this.recostingsPage.btnSetToRecosted.click();
    await this.recostingsPage.btnSetToRecosted.click();
    await this.recostingsPage.btnConfirm.click();
    await this.recostingsPage.btnSendLater.click();
    await this.page.waitForLoadState();
  }
}
