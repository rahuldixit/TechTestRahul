import { EFMLoginPage } from "../../pages/efm/EFMLoginPage";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { EFMReportsPage } from "../../pages/efm/EFMFBTReportsPage";
import { EFMPaymentsPage } from "../../pages/efm/EFMFBTPaymentsPage";
import { Page, expect } from "@playwright/test";

export class RunReports {
  efmLoginPage: EFMLoginPage;
  efmHomePage: EFMHomePage;
  efmReportsPage: EFMReportsPage;
  efmPaymentsPage: EFMPaymentsPage;
  page: Page;

  constructor(page: Page) {
    this.efmLoginPage = new EFMLoginPage(page);
    this.efmHomePage = new EFMHomePage(page);
    this.efmReportsPage = new EFMReportsPage(page);
    this.efmPaymentsPage = new EFMPaymentsPage(page);
    this.page = page;
  }

  async runFBTPaymentEOY(companyName: string) {
    await this.efmPaymentsPage.btnRunReportFBTEndOfYear.click();
    await expect(this.efmHomePage.headerFBTTitle).toContainText(
      "Run FBT End Of Year Process: Select company.",
      { timeout: 10000 },
    );
    await this.efmPaymentsPage.selectCompanyByName(companyName);
    await this.efmPaymentsPage.btnRunFBTEOY.click();
    await expect(this.efmHomePage.headerFBTTitle).toContainText(
      "FBT end of year payment is being generated",
    );
    //Report will be emailed but takes time - Wait time to be determined after email access is sorted.
  }

  async runAdHocFBTPaymentReport(
    companyName: string,
    startDate: string,
    startMonth: string,
    startYear: string,
    endDate: string,
    endMonth: string,
    endYear: string,
  ) {
    await this.efmPaymentsPage.btnRunReportInForeground.click();
    await expect(this.efmHomePage.headerFBTTitle).toContainText(
      "Run FBT Ad Hoc Payment Process: Select company",
      { timeout: 10000 },
    );
    await this.efmPaymentsPage.selectCompanyByName(companyName);
    await expect(this.efmHomePage.headerFBTTitle).toContainText(
      "Run FBT Ad Hoc Payment Process: Select date range",
      { timeout: 10000 },
    );
    await this.efmPaymentsPage.dateFromDay.fill(startDate);
    await this.efmPaymentsPage.selectFromMonthDropDown(startMonth);
    await this.efmPaymentsPage.dateFromYear.fill(startYear);
    await this.efmPaymentsPage.dateToDay.fill(endDate);
    await this.efmPaymentsPage.selectToMonthDropDown(endMonth);
    await this.efmPaymentsPage.dateToYear.fill(endYear);
  }

  async runFBTCompanyVehiclesReportForSingleCompany() {}

  async runFBTCompanyVehiclesReportForMultipleCompanies() {}

  async runFBTCompanyGroupVehiclesReport() {}

  async clickViewPDF() {
    const popupPromise = this.page.waitForEvent("popup");
    await this.efmPaymentsPage.btnViewAsPDF.click();
    const popup = await popupPromise;
    return popup;
  }
}
