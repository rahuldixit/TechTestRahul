import { Page, expect } from "@playwright/test";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { EFMClientsPage } from "../../pages/efm/EFMClientsPage";

export class SearchClients {
  efmHomePage: EFMHomePage;
  efmClientsPage: EFMClientsPage;

  constructor(page: Page) {
    this.efmHomePage = new EFMHomePage(page);
    this.efmClientsPage = new EFMClientsPage(page);
  }

  async searchClient(client: string) {
    await this.efmClientsPage.findClients.type(client);
    await this.efmClientsPage.btnSearchClient.click();
  }

  async verifySearchResult() {
    await this.efmClientsPage.clientSearchResult.waitFor();
    await expect(this.efmClientsPage.clientSearchResult).toBeVisible();
  }
}
