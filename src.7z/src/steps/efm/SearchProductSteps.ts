import { Page, expect } from "@playwright/test";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";

export class SearchProducts {
  efmHomePage: EFMHomePage;

  constructor(page: Page) {
    this.efmHomePage = new EFMHomePage(page);
  }

  async searchProduct(productID: string) {
    await this.efmHomePage.linkCustomerOrProducts.click();
    await this.efmHomePage.findCustomersOrProducts.fill(productID);
    await this.efmHomePage.btnSearchCustomer.click();
    await expect(this.efmHomePage.searchResultsTable).toBeVisible();
  }

  async searchCustomer(clientName: string) {
    await this.efmHomePage.linkCustomerOrProducts.click();
    await this.efmHomePage.findCustomersOrProducts.fill(clientName);
    await this.efmHomePage.btnSearchCustomer.click();
    await expect(this.efmHomePage.searchResultsTable).toBeVisible();
  }

  async verifySearchResults({
    expectedName,
    expectedProductID,
    expectedMilesContractRef,
    expectedFMP,
    expectedLeaseType,
    expectedProductDescription,
    expectedState,
    expectedClient,
  }: {
    expectedName: string;
    expectedProductID: string;
    expectedMilesContractRef: string;
    expectedFMP: string;
    expectedLeaseType: string;
    expectedProductDescription: string;
    expectedState: string;
    expectedClient: string;
  }) {
    const actualName =
      await this.efmHomePage.getValueInSearchResultsFirstRow("Name");
    const actualProductID =
      await this.efmHomePage.getValueInSearchResultsFirstRow("Product ID");
    const actualMilesContractRef =
      await this.efmHomePage.getValueInSearchResultsFirstRow(
        "Miles Contract Ref",
      );
    const actualFMP =
      await this.efmHomePage.getValueInSearchResultsFirstRow("FMP");
    const actualLeaseType =
      await this.efmHomePage.getValueInSearchResultsFirstRow("Lease Type");
    const actualProductDescription =
      await this.efmHomePage.getValueInSearchResultsFirstRow(
        "Product Description",
      );
    const actualState =
      await this.efmHomePage.getValueInSearchResultsFirstRow("State");
    const actualClient =
      await this.efmHomePage.getValueInSearchResultsFirstRow("Client");
    expect(actualName).toEqual(expectedName);
    expect(actualProductID).toEqual(expectedProductID);
    expect(actualMilesContractRef).toEqual(expectedMilesContractRef);
    expect(actualFMP).toEqual(expectedFMP);
    expect(actualLeaseType).toEqual(expectedLeaseType);
    expect(actualProductDescription).toEqual(expectedProductDescription);
    expect(actualState).toEqual(expectedState);
    expect(actualClient).toEqual(expectedClient);
  }

  async clickName() {
    await this.efmHomePage.nameLink.click();
  }

  async clickProductID() {
    await this.efmHomePage.productIDLink.click();
  }
}
