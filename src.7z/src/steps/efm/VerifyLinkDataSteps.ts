import { Page, expect } from "@playwright/test";
import { EFMClientPage } from "pages/efm/EFMClientPage";

export class VerifyLinkData {
  efmClientPage: EFMClientPage;
  page: Page;

  constructor(page: Page) {
    this.efmClientPage = new EFMClientPage(page);
    this.page = page;
  }

  async verifyCustomerData(data: any) {
    await this.efmClientPage.verifyField("Contact Name", data.contactName);
    await this.efmClientPage.verifyField("Unique ID", data.uniqueID);
    await this.efmClientPage.verifyField("Lessee Type", data.lesseeType);
    await this.efmClientPage.verifyField(
      "Customer Description/Name",
      data.customerDescription,
    );
    await this.efmClientPage.verifyField("Salary", data.salary);
    await this.efmClientPage.verifyField("Position", data.position);
    await this.efmClientPage.verifyField(
      "Employee Payroll No",
      data.employeePayrollNo,
    );
    await this.efmClientPage.verifyField(
      "Payroll Frequency",
      data.payrollFrequency,
    );
    await this.efmClientPage.verifyField(
      "EVO CustomerID(s)",
      data.evoCustomerID,
    );
    await this.efmClientPage.verifyField(
      "Miles Contact ID",
      data.milesContactID,
    );
    await this.efmClientPage.verifyField("Date of Birth", data.dateOfBirth);
    await this.efmClientPage.verifyField(
      "Primary Email Address",
      data.primaryEmailAddress,
    );
    await this.efmClientPage.verifyField(
      "Primary Email Notification",
      data.primaryEmailNotification,
    );
  }

  async verifyProvisionAmounts(productDetails: string) {
    expect(await this.efmClientPage.productDetails.innerText()).toBe(
      productDetails,
    );
  }

  async verifyProductDetails(data: any) {
    await this.efmClientPage.verifySelectField(
      "Contract Type",
      data.contractType,
    );
    await this.efmClientPage.verifySelectField("Consultant", data.consultant);
    await this.efmClientPage.verifySelectField(
      "Product Type",
      data.productType,
    );
    await this.efmClientPage.verifySelectField(
      "Benefit Type",
      data.benefitType,
    );
    await this.efmClientPage.verifyInputField(
      "Registration",
      data.registration,
    );
    await this.efmClientPage.verifyInputField("NVIC", data.NVIC);
    await this.efmClientPage.verifyRadioButton(
      "Purchase Type",
      data.purchaseType,
    );
    await this.efmClientPage.verifyField("Miles Salpack", data.salPack);
    await this.efmClientPage.verifyInputField(
      "Miles Contract ID",
      data.contractID,
    );
    await this.efmClientPage.verifyInputField(
      "Miles Contract Reference",
      data.contractReference,
    );
    await this.efmClientPage.verifyInputField("Year", data.year);
    await this.efmClientPage.verifyInputField("Make", data.make);
    await this.efmClientPage.verifyInputField("Model", data.model);
    await this.efmClientPage.verifyInputField("Series", data.series);
    await this.efmClientPage.verifyInputField("Body Type", data.bodyType);
    await this.efmClientPage.verifyInputField("Engine No.", data.engineNo);
    await this.efmClientPage.verifyInputField("VIN", data.vin);
    await this.efmClientPage.verifySelectField(
      "Transmission",
      data.transmission,
    );
    await this.efmClientPage.verifyInputField(
      "Vehicle Colour",
      data.vehicleColour,
    );
  }
}
