import { Page, expect } from "@playwright/test";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { EFMGeneralInfoPage } from "../../pages/efm/EFMGeneralInfoPage";
import { EFMFBTTrackingPage } from "../../pages/efm/EFMFBTTrackingPage";

export class ViewProductDetails {
  efmHomePage: EFMHomePage;
  efmGeneralInfoPage: EFMGeneralInfoPage;
  efmFBTTrackingPage: EFMFBTTrackingPage;

  constructor(page: Page) {
    this.efmHomePage = new EFMHomePage(page);
    this.efmGeneralInfoPage = new EFMGeneralInfoPage(page);
    this.efmFBTTrackingPage = new EFMFBTTrackingPage(page);
  }

  async verifyProductInGeneralInfo(productID: string) {
    await this.efmGeneralInfoPage.clickSideMenu("Contract Details ...");
    await this.efmGeneralInfoPage.clickSideMenu("General Info");
    await this.efmGeneralInfoPage.valueUniqueID.waitFor();
    const value = await this.efmGeneralInfoPage.valueUniqueID.innerText();
    expect(value).toEqual(productID);
  }

  async getRegistrationInGeneralInfo() {
    return await this.efmGeneralInfoPage.valueRegistration.innerText();
  }

  async getDescriptionInGeneralInfo() {
    return await this.efmGeneralInfoPage.valueDescription.innerText();
  }

  async goToFBTTracking() {
    await this.efmGeneralInfoPage.linkFBT.click();
    await this.efmGeneralInfoPage.linkFBTTracking.click();
    await this.efmFBTTrackingPage.headingFBTSummaryFor.waitFor();
  }

  //Verify FBT Tracking page has the same Registration and Description as the Product
  async verifyFBTTracking(rego: string, desc: string) {
    await this.efmFBTTrackingPage.headingFBTSummaryFor.waitFor();
    await expect(this.efmFBTTrackingPage.tableFBTSummary).toBeVisible();
    const heading =
      await this.efmFBTTrackingPage.headingFBTSummaryFor.innerText();
    expect(heading).toContain(rego);
    expect(heading).toContain(desc);
  }
}
