import { Page } from "@playwright/test";
import { EFMHomePage } from "../../pages/efm/EFMHomePage";
import { EFMFleetpage } from "pages/efm/EFMFleetPage";

export class VerifyReport {
  efmHomePage: EFMHomePage;
  efmFleetPage: EFMFleetpage;
  page: Page;

  constructor(page: Page) {
    this.efmHomePage = new EFMHomePage(page);
    this.efmFleetPage = new EFMFleetpage(page);
    this.page = page;
  }

  async gotoCompanyReport() {
    await this.efmHomePage.clickHorizontalTopMenu("Fleet");
    await this.efmFleetPage.clickSideMenu("FBT Reports");
    await this.efmFleetPage.runVehiclesReportFBTCR.click();
  }

  async gotoCompanyGroupReport() {
    await this.efmHomePage.clickHorizontalTopMenu("Fleet");
    await this.efmFleetPage.clickSideMenu("FBT Reports");
    await this.efmFleetPage.runVehicleReportFBTCGR.click();
  }

  async runVehicleReport(companies: string[]) {
    for (let i = 0; i < companies.length; i++) {
      await this.efmFleetPage.selectCheckboxForCompanyByName(companies[i]);
    }
    await this.efmFleetPage.btnEmailCompanies.click();
  }
}
