import { Page, expect } from "@playwright/test";
import { FAMHomePage } from "../../pages/fam-ids/FAMHomePage";

export class SearchExistingApplication {
  famHomePage: FAMHomePage;

  constructor(page: Page) {
    this.famHomePage = new FAMHomePage(page);
  }

  async searchExistingApplication(
    leadnum: string,
    milesquotenum: string,
    employeename: string,
  ) {
    await this.famHomePage.searchExistingApplicationTab.click();
    await this.famHomePage.imsAUNEMForSearch.fill(leadnum);
    await this.famHomePage.milesQuoteNumForSearch.fill(milesquotenum);
    await this.famHomePage.employeeNameForSearch.fill(employeename);
    await this.famHomePage.btnSearch.click();
    await expect(this.famHomePage.searchResult).toBeVisible();
    expect(this.famHomePage.imsReferenceLink).toEqual(leadnum);
    expect(this.famHomePage.milesQuoteValue).toEqual(milesquotenum);
  }
}
