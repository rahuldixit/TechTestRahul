import { Page, expect } from "@playwright/test";
import { FAMHomePage } from "../../pages/fam-ids/FAMHomePage";
import { verifyEmailAndLaunchOnlineFinanceApplication } from "../../../utils/emailReader";

export class StartNewApplication {
  famHomePage: FAMHomePage;

  constructor(page: Page) {
    this.famHomePage = new FAMHomePage(page);
  }

  async startNewApplication(
    url: string,
    emailAddr: string,
    password: string,
    leadNum: string,
    milesQuoteNum: string,
    applicationType: string,
  ) {
    await this.famHomePage.openFAM(url);
    await this.famHomePage.imsAUNEM.fill(leadNum);
    await this.famHomePage.milesQuoteNum.fill(milesQuoteNum);
    await this.famHomePage.selectApplicationType(applicationType);
    await this.famHomePage.btnRetrieve.click();
    await expect(this.famHomePage.initiateCreditHeader).toBeVisible();
    await expect(this.famHomePage.matchMessage).toHaveText(
      "✓ IMS and Miles details match",
    );
    await this.famHomePage.btnSendInvite.click();
    await expect(this.famHomePage.creditApplicationSuccess).toHaveText(
      "Credit application initiated successfully",
    );
    await verifyEmailAndLaunchOnlineFinanceApplication(
      emailAddr,
      password,
      milesQuoteNum,
      //subject will be added when test is completed
    );
  }
}
