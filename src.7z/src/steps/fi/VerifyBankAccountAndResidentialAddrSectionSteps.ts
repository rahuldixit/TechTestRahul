import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIManageProfilePage } from "../../pages/fi/FIManageProfilePage";

export class VerifyBankAndResidentialSection {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiManageProfilePage: FIManageProfilePage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiManageProfilePage = new FIManageProfilePage(page);
  }

  async goToManageProfile() {
    this.fiHomePage.selectOptionFromDropdown("Manage Profile");
    await this.fiManageProfilePage.headerBankAccountDetails.waitFor({
      timeout: 60000,
    });
  }

  async verifyAutoPakDriverForManageProfilePage() {
    expect(this.fiManageProfilePage.headerManageProfile).toBeVisible();
    expect(this.fiManageProfilePage.headerBankAccountDetails).toBeVisible();
    expect(this.fiManageProfilePage.headerResidentialAddress).toBeVisible();
    expect(this.fiManageProfilePage.headerMailAddress).toBeVisible();
    expect(this.fiManageProfilePage.checkBoxEditBankAccount).toBeVisible();
    expect(this.fiManageProfilePage.fieldAccountName).toBeVisible();
    expect(this.fiManageProfilePage.fieldAccountNumber).toBeVisible();
    expect(this.fiManageProfilePage.fieldBsbFirstTriplet).toBeVisible();
    expect(this.fiManageProfilePage.fieldBsbSecondTriplet).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialStreet).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialSuburb).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialPostCode).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialState).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialMobileNum).toBeVisible();
    expect(
      this.fiManageProfilePage.checkBoxSameAsResidentialAddr,
    ).toBeVisible();
    expect(this.fiManageProfilePage.fieldMailStreet).toBeVisible();
    expect(this.fiManageProfilePage.fieldMailSuburb).toBeVisible();
    expect(this.fiManageProfilePage.fieldMailPostCode).toBeVisible();
    expect(this.fiManageProfilePage.fieldMailState).toBeVisible();
  }

  async verifyNvbEmployeeForManageProfilePage() {
    expect(this.fiManageProfilePage.headerManageProfile).toBeVisible();
    expect(this.fiManageProfilePage.headerBankAccountDetails).toBeVisible();
    expect(this.fiManageProfilePage.headerResidentialAddress).toBeVisible();
    expect(this.fiManageProfilePage.fieldAccountName).toBeVisible();
    expect(this.fiManageProfilePage.fieldAccountNumber).toBeVisible();
    expect(this.fiManageProfilePage.fieldBsbFirstTriplet).toBeVisible();
    expect(this.fiManageProfilePage.fieldBsbSecondTriplet).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialStreet).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialSuburb).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialPostCode).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialState).toBeVisible();
    expect(this.fiManageProfilePage.fieldResidentialMobileNum).toBeVisible();
  }
}
