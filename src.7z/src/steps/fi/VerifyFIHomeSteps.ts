import { Page } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";

export class FIHome {
  fiHomePage: FIHomePage;
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
  }

  async verifyWidgetsForFleetManager() {
    await this.page.waitForSelector(".WidgetContent div.Chart", {
      timeout: 10000,
    });
    await this.page.waitForSelector(".WidgetContent table", { timeout: 60000 });
    await this.fiHomePage.serviceDueWidget.isVisible();
    await this.fiHomePage.serviceOverdueWidget.isVisible();
    await this.fiHomePage.manufacturerRecallsByModel.isVisible();
    await this.fiHomePage.tripsWidget.isVisible();
    await this.fiHomePage.driverBehaviourWidget.isVisible();
    await this.fiHomePage.fleetSizeByProductWidget.isVisible();
    await this.fiHomePage.fuelCardSummaryWidget.isVisible();
    await this.fiHomePage.projectUtilisationByDistanceWidget.isVisible();
    await this.fiHomePage.replacementsDueWidget.isVisible();
    await this.fiHomePage.vehiclesDueForDeliveryWidget.isVisible();
    await this.fiHomePage.fleetWatchListWidget.isVisible();
    await this.fiHomePage.incidentVolumeWidget.isVisible();
    await this.fiHomePage.latestANCAPNewsWidget.isVisible();
    await this.fiHomePage.latestCarStoriesWidget.isVisible();
    await this.fiHomePage.totalRepairCostwidget.isVisible();
    await this.fiHomePage.electricityChargerActivityReportWidget.isVisible();
    await this.fiHomePage.electricityReportWidget.isVisible();
    await this.fiHomePage.processManagerSummaryWidget.isVisible();
  }

  async verifyWidgetsForNovatedDriver() {
    await this.page.waitForSelector(".WidgetContent table", { timeout: 60000 });
    await this.fiHomePage.latestANCAPNewsWidget.isVisible();
    await this.fiHomePage.latestCarStoriesWidget.isVisible();
    await this.fiHomePage.yourVehicleWidget.isVisible();
    await this.fiHomePage.kmTrackerWidget.isVisible();
    await this.fiHomePage.servicingDetailsWidget.isVisible();
    await this.fiHomePage.fuelEfficiencyWidget.isVisible();
    await this.fiHomePage.balanceSummaryWidget.isVisible();
    await this.fiHomePage.comprehensiveInsuranceDetailsWidget.isVisible();
  }

  async selectCostCentre(costcentre: string) {
    await this.fiHomePage.costcentreDropdown.click();
    await this.fiHomePage.selectCostCentreByName(costcentre);
    await this.page.waitForSelector(".WidgetContent table", { timeout: 60000 });
  }

  async verifyWidgetsForNvbEmployee() {
    await this.page.waitForSelector(".WidgetContent table", { timeout: 60000 });
    await this.fiHomePage.nvbProductSummaryWidget.waitFor();
    await this.fiHomePage.nvbTransactionsWidget.waitFor();
  }

  async getNVBProductSummaryTexts() {
    return await this.fiHomePage.nvbProductSummaryWidget.allInnerTexts();
  }

  async getNVBTransactionsTexts() {
    return await this.fiHomePage.nvbTransactionsWidget.allInnerTexts();
  }
}
