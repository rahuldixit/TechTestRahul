import { Page } from "@playwright/test";
import { FILoginPage } from "../../pages/fi/FILoginPage";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";
import { FITermsConditionsPage } from "../../pages/fi/FITerms&ConditionsPage";

export class LoginIntoFI {
  fiLoginPage: FILoginPage;
  fiHomePage: FIHomePage;
  fiTermsConditionsPage: FITermsConditionsPage;
  msLoginPage: MsOnlineLoginPage;
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
    this.fiLoginPage = new FILoginPage(page);
    this.fiHomePage = new FIHomePage(page);
    this.fiTermsConditionsPage = new FITermsConditionsPage(page);
    this.msLoginPage = new MsOnlineLoginPage(page);
  }

  async loginAsFleetManager(url: string, username: string, password: string) {
    await this.fiLoginPage.openFI(url);
    await this.fiLoginPage.usernameFI.fill(username);
    await this.fiLoginPage.btnNext.click();
    await this.msLoginPage.password.waitFor({ timeout: 10000 });
    await this.msLoginPage.password.fill(password);
    await this.msLoginPage.signIn.click();
    if (await this.fiTermsConditionsPage.agreeTCs.isVisible()) {
      await this.fiTermsConditionsPage.agreeTCs.click();
      await this.fiTermsConditionsPage.btnProceed.click();
    }
    await this.msLoginPage.staySignedInNo.click();
    await this.fiHomePage.homePageLogo.waitFor({ timeout: 80000 });
    await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });
    console.log("URL: " + url);
    console.log("Username: " + username);
    await this.page.waitForLoadState("networkidle");
    await this.fiHomePage.changeRoleFromTopMenu("Fleet Manager (M)");
  }

  // Login for Novated Driver, Autopak Driver, NVB Employee
  async loginAsDriverOrEmployee(
    url: string,
    username: string,
    password: string,
  ) {
    await this.fiLoginPage.openFI(url);
    await this.fiLoginPage.usernameFI.fill(username);
    await this.fiLoginPage.btnNext.click();
    await this.fiLoginPage.passwordFI.fill(password);
    await this.fiLoginPage.btnLogin.click();
    await this.fiHomePage.homePageLogo.waitFor({ timeout: 80000 });
    /*await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });*/
    console.log("URL: " + url);
    console.log("Username: " + username);
  }
}
