import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIFleetDataManagementPage } from "../../pages/fi/FIFleetDataManagementPage";
import { FIDriverTransferPage } from "../../pages/fi/FIDriverTransferPage";
import { faker } from "@faker-js/faker";

export class FleetDataManagement {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiFleetDataManagementPage: FIFleetDataManagementPage;
  fiDriverTransfer: FIDriverTransferPage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiFleetDataManagementPage = new FIFleetDataManagementPage(page);
    this.fiDriverTransfer = new FIDriverTransferPage(page);
  }

  async goToFleetDataManagement() {
    await this.fiHomePage.selectActivityByName("Fleet Data Management");
  }

  async enterAndSearchVehicleInFleetDataManagement(rego: string) {
    await this.fiFleetDataManagementPage.fieldSearchVehicle.waitFor({
      timeout: 90000,
    });
    await this.fiFleetDataManagementPage.fieldSearchVehicle.type(rego);
    await this.fiFleetDataManagementPage.btnSearchVehicle.click();
  }

  async goToDriverTransfer() {
    await this.fiFleetDataManagementPage.btnDriverDetails.waitFor({
      timeout: 90000,
    });
    await this.fiFleetDataManagementPage.btnDriverDetails.click();
  }

  async getActualRegoFromDriverTransfer() {
    await this.fiDriverTransfer.registrationValue.waitFor({ timeout: 90000 });
    return await this.fiDriverTransfer.registrationValue.innerText();
  }

  async updateVehicleLocationUsingNewAddressField(
    location1: string,
    location2: string,
  ) {
    await this.fiFleetDataManagementPage.btnUpdateVehicleLocation.click();
    if (
      (
        await this.fiFleetDataManagementPage.currentLocation.innerText()
      ).includes(location1)
    ) {
      await this.enterLocation(location2);
      await this.confirmLocation(location2);
      return location2;
    } else {
      await this.enterLocation(location1);
      await this.confirmLocation(location1);
      return location1;
    }
  }

  async updateVehicleLocationUsingNewLocationDropdown(
    location1: string,
    location2: string,
  ) {
    await this.fiFleetDataManagementPage.btnUpdateVehicleLocation.click();
    if (
      (
        await this.fiFleetDataManagementPage.currentLocation.innerText()
      ).includes(location1)
    ) {
      await this.selectLocation(location2);
      await this.confirmLocation(location2);
      return location2;
    } else {
      await this.selectLocation(location1);
      await this.confirmLocation(location1);
      return location1;
    }
  }

  async enterLocation(location: string) {
    await this.fiFleetDataManagementPage.newAddress.type(location);
  }

  async selectLocation(location: string) {
    await this.fiFleetDataManagementPage.dropdownNewLocation.click();
    await this.fiFleetDataManagementPage.dropdownNewLocation.selectOption({
      label: location,
    });
  }

  async confirmLocation(location: string) {
    await this.fiFleetDataManagementPage.btnSelectVehicleLocation.click();
    await this.fiFleetDataManagementPage.btnSelectVehicleLocation.click(); //confirm button has exact same locator id hence clicked twice
    expect(
      await this.fiFleetDataManagementPage.sectionBody.innerText(),
    ).toContain("To Location: " + location);
    await this.fiFleetDataManagementPage.linkHere.click();
  }

  async verifyVehicleLocationUpdated(location: string) {
    await this.fiFleetDataManagementPage.btnUpdateVehicleLocation.click();
    expect(
      await this.fiFleetDataManagementPage.currentLocation.innerText(),
    ).toBe(location);
    await this.goToFleetDataManagement();
  }

  async updateDriverDetails(driver1: string, driver2: string) {
    await this.fiFleetDataManagementPage.btnDriverDetails.click();
    if (
      (await this.fiFleetDataManagementPage.currentDriver.innerText()).includes(
        driver1,
      )
    ) {
      await this.enterDriver(driver2);
      return driver2;
    } else {
      await this.enterDriver(driver1);
      return driver1;
    }
  }

  async enterDriver(driver: string) {
    await this.fiFleetDataManagementPage.searchDriver.click();
    await this.fiFleetDataManagementPage.searchForDriver.type(driver);
    await this.fiFleetDataManagementPage.btnDriverSearch.click();
    await this.fiFleetDataManagementPage.clickFirstDriverResult(driver);
    const currentOdo =
      await this.fiFleetDataManagementPage.currentOdo.innerText();
    await this.fiFleetDataManagementPage.odometerAllocation.type(
      (Number(currentOdo.trim()) + 1).toString(),
    );
    await this.fiFleetDataManagementPage.btnTransferDriver.click();
    await this.fiFleetDataManagementPage.btnOK.click();
    await this.fiFleetDataManagementPage.btnGoBack.click();
  }

  async verifyDriverUpdated(driver: string) {
    const driverFormatted = driver.split(" ")[1] + ", " + driver.split(" ")[0];
    await this.fiFleetDataManagementPage.btnDriverDetails.click();
    expect(await this.fiFleetDataManagementPage.currentDriver.innerText()).toBe(
      driverFormatted,
    );
  }

  async performCostCentreTransfer(costCentre?: string) {
    await this.fiFleetDataManagementPage.btnPerformCostCentreTransfer.click();
    const currentCostCentre =
      await this.fiFleetDataManagementPage.currentCostCentre.innerText();
    await this.fiFleetDataManagementPage.selectCostCentreNewLocation.click({
      force: true,
    });
    if (!costCentre) {
      const costCentres = (
        await this.fiFleetDataManagementPage.selectCostCentreNewLocations.allInnerTexts()
      ).filter((centre) => {
        return !(
          centre.includes("Obsolete") ||
          centre.includes("OBSOLETE") ||
          centre.includes(currentCostCentre)
        );
      });

      costCentre =
        costCentres[faker.number.int({ min: 1, max: costCentres.length - 1 })];
    }
    await this.fiFleetDataManagementPage.selectCostCentreNewLocation.selectOption(
      {
        label: costCentre,
      },
    );
    await this.fiFleetDataManagementPage.odometerAllocation.type(
      faker.number.int({ min: 1000, max: 10000 }).toString(),
    );
    await this.fiFleetDataManagementPage.btnCostCentreTransferApply.click();
    await this.fiFleetDataManagementPage.btnOK.click();
    await this.fiFleetDataManagementPage.btnGoBack.click();
    return costCentre;
  }

  async verifyCostCentreUpdated(costCentre: string) {
    await this.fiFleetDataManagementPage.btnPerformCostCentreTransfer.click();
    expect(
      await this.fiFleetDataManagementPage.currentCostCentre.innerText(),
    ).toBe(costCentre);
  }

  async updateOdoReading() {
    await this.fiFleetDataManagementPage.btnSubmitOdoReading.click();
    const currentOdo =
      await this.fiFleetDataManagementPage.lastOdoReading.innerText();
    const newOdoReading = (Number(currentOdo.trim()) + 1).toString();
    await this.fiFleetDataManagementPage.odometerAllocation.type(newOdoReading);
    await this.fiFleetDataManagementPage.btnSubmitChanges.click();
    await this.fiFleetDataManagementPage.btnOK.click();
    await this.fiFleetDataManagementPage.btnGoBack.click();
    return newOdoReading.trim();
  }

  async verifyOdoReadingUpdated(odoReading: string) {
    await this.fiFleetDataManagementPage.btnSubmitOdoReading.click();
    expect(
      (await this.fiFleetDataManagementPage.lastOdoReading.innerText()).trim(),
    ).toBe(odoReading);
  }

  async updateVehicleDetails(
    vehicleCategory?: string,
    vehiclePurpose?: string,
    vehicleRole?: string,
  ) {
    await this.fiFleetDataManagementPage.btnUpdateVehicleDetails.click();

    let vehicleCategoryCurrent = "";
    if (
      (await this.fiFleetDataManagementPage.dropdownVehicleCategory
        .locator('[selected="selected"]')
        .count()) == 0
    ) {
      vehicleCategoryCurrent = "Select..";
    } else {
      vehicleCategoryCurrent =
        await this.fiFleetDataManagementPage.dropdownVehicleCategory
          .locator('[selected="selected"]')
          .innerText();
    }
    await this.fiFleetDataManagementPage.dropdownVehicleCategory.click();
    if (!vehicleCategory) {
      const vehicleCategories = (
        await this.fiFleetDataManagementPage.dropdownVehicleCategory
          .locator("option")
          .allInnerTexts()
      ).filter((category) => {
        return (
          category.trim() != vehicleCategoryCurrent ||
          category.trim() != "Select.."
        );
      });
      vehicleCategory =
        vehicleCategories[
          faker.number.int({ min: 0, max: vehicleCategories.length - 1 })
        ];
    }
    await this.fiFleetDataManagementPage.dropdownVehicleCategory.selectOption({
      label: vehicleCategory,
    });

    await this.page.waitForTimeout(1000);
    let vehiclePurposeCurrent = "";
    if (
      (await this.fiFleetDataManagementPage.dropdownVehiclePurpose
        .locator('[selected="selected"]')
        .count()) == 0
    ) {
      vehiclePurposeCurrent = "Select..";
    } else {
      vehiclePurposeCurrent =
        await this.fiFleetDataManagementPage.dropdownVehiclePurpose
          .locator('[selected="selected"]')
          .innerText();
    }
    await this.fiFleetDataManagementPage.dropdownVehiclePurpose.click();
    if (!vehiclePurpose) {
      const vehiclePurposes = (
        await this.fiFleetDataManagementPage.dropdownVehiclePurpose
          .locator("option")
          .allInnerTexts()
      ).filter((purpose) => {
        return (
          purpose.trim() != vehiclePurposeCurrent ||
          purpose.trim() != "Select.."
        );
      });
      if (vehiclePurposes.length == 0) {
        vehiclePurpose = vehiclePurposeCurrent;
      } else {
        vehiclePurpose =
          vehiclePurposes[
            faker.number.int({ min: 0, max: vehiclePurposes.length - 1 })
          ];
      }
    }
    await this.fiFleetDataManagementPage.dropdownVehiclePurpose.selectOption({
      label: vehiclePurpose,
    });

    await this.page.waitForTimeout(1000);
    let vehicleRoleCurrent = "";
    if (
      (await this.fiFleetDataManagementPage.dropdownVehicleRole
        .locator('[selected="selected"]')
        .count()) == 0
    ) {
      vehicleRoleCurrent = "Select..";
    } else {
      vehicleRoleCurrent =
        await this.fiFleetDataManagementPage.dropdownVehicleRole
          .locator('[selected="selected"]')
          .innerText();
    }
    await this.fiFleetDataManagementPage.dropdownVehicleRole.click();
    if (!vehicleRole) {
      const vehicleRoles = (
        await this.fiFleetDataManagementPage.dropdownVehicleRole
          .locator("option")
          .allInnerTexts()
      ).filter((role) => {
        return role.trim() != vehicleRoleCurrent || role.trim() != "Select..";
      });

      if (vehicleRoles.length == 0) {
        vehicleRole = vehicleRoleCurrent;
      } else {
        vehicleRole =
          vehicleRoles[
            faker.number.int({ min: 0, max: vehicleRoles.length - 1 })
          ];
      }
    }
    await this.fiFleetDataManagementPage.dropdownVehicleRole.selectOption({
      label: vehicleRole,
    });

    await this.fiFleetDataManagementPage.btnSubmitChanges.click();
    await this.fiFleetDataManagementPage.btnOK.click();
    await this.fiFleetDataManagementPage.btnGoBack.click();
    return [vehicleCategory.trim(), vehiclePurpose.trim(), vehicleRole.trim()];
  }

  async verifyVehicleDetails(
    vehicleCategory: string,
    vehiclePurpose: string,
    vehicleRole: string,
  ) {
    await this.fiFleetDataManagementPage.btnUpdateVehicleDetails.click();
    expect(
      (
        await this.fiFleetDataManagementPage.dropdownVehicleCategory
          .locator('[selected="selected"]')
          .innerText()
      ).trim(),
    ).toBe(vehicleCategory);
    expect(
      (
        await this.fiFleetDataManagementPage.dropdownVehiclePurpose
          .locator('[selected="selected"]')
          .innerText()
      ).trim(),
    ).toBe(vehiclePurpose);
    expect(
      (
        await this.fiFleetDataManagementPage.dropdownVehicleRole
          .locator('[selected="selected"]')
          .innerText()
      ).trim(),
    ).toBe(vehicleRole);
  }
}
