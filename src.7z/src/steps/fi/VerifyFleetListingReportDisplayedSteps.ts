import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIFleetListingPage } from "../../pages/fi/FIFleetListingPage";
import { FIVehicleDetailsPage } from "../../pages/fi/FIVehicleDetailsPage";
import { faker } from "@faker-js/faker";
import { readDataFromExcel } from "utils/excelReader";
import { readDataFromPDF } from "utils/pdfReader";
import { readCSV } from "utils/csvReader";

export class FleetListing {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiFleetListingPage: FIFleetListingPage;
  fiVehicleDetailsPage: FIVehicleDetailsPage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiFleetListingPage = new FIFleetListingPage(page);
    this.fiVehicleDetailsPage = new FIVehicleDetailsPage(page);
  }

  async goToFleetListingPage() {
    await this.fiHomePage.selectReportByName("Fleet Listing Report");
  }

  async getRandomRegoFromFleetListingPage() {
    await (
      await this.fiFleetListingPage.getTableCellLocator({})
    ).waitFor({ timeout: 360000 });
    const range = await this.fiFleetListingPage.getNumberOfTableRows({});
    const randomNumber = faker.number.int({ max: range - 1 });
    const rego = await (
      await this.fiFleetListingPage.getTableCellLocator({
        tableIndex: 0,
        rowIndex: randomNumber,
      })
    ).innerText();
    return rego;
  }

  async clickRego(rego: string) {
    await (
      await this.fiFleetListingPage.getTableCellLocatorByText(rego)
    ).click();
  }

  async searchRego(rego: string) {
    await this.fiFleetListingPage.searchRego.type(rego);
    await this.fiFleetListingPage.btnSearchRego.click();
    return (await this.fiFleetListingPage.firstSearchResult.innerText()).trim();
  }

  async verifyVehicleDetails(rego: string) {
    await this.fiFleetListingPage.clickRego(rego);
    await this.fiFleetListingPage.clickTab("Summary");
    expect(await this.fiFleetListingPage.summaryRegoValue.innerText()).toBe(
      rego,
    );
    await this.fiFleetListingPage.clickTab("Accessories");
    await this.fiFleetListingPage.acccessoriesHeading.waitFor();
    await this.fiFleetListingPage.clickTab("Attachments");
    await this.fiFleetListingPage.inputFileAttachment.waitFor();
    await this.fiFleetListingPage.clickTab("Transactions");
    await this.fiFleetListingPage.reportResults.waitFor();
  }

  async exportAndVerifyExcel(rego: string) {
    const downloadPromise = this.page.waitForEvent("download");
    await this.fiFleetListingPage.btnExcel.click();
    const download = await downloadPromise;
    const filePath = await download.path();
    const data = await readDataFromExcel(filePath ? filePath : "");
    expect(data[0].Registration).toBe(rego);
  }

  async exportAndVerifyPDF(rego: string) {
    const downloadPromise = this.page.waitForEvent("download");
    await this.fiFleetListingPage.btnPDF.click();
    const download = await downloadPromise;
    const filePath = await download.path();
    const data = await readDataFromPDF(filePath ? filePath : "");
    expect(data).toContain(rego);
  }

  async exportAndVerifyCSV(rego: string) {
    const downloadPromise = this.page.waitForEvent("download");
    await this.fiFleetListingPage.btnCSV.click();
    const download = await downloadPromise;
    const filePath = await download.path();
    const csvData: any = await readCSV(filePath ? filePath : "");
    expect(csvData.data[1][0]).toBe(rego);
  }
}
