import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIFleetDataManagementPage } from "../../pages/fi/FIFleetDataManagementPage";
import { FIDriverTransferPage } from "../../pages/fi/FIDriverTransferPage";
import { FILogbookPage } from "../../pages/fi/FILogbookPage";
import { faker } from "@faker-js/faker";

export class LogbookManager {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiFleetDataManagementPage: FIFleetDataManagementPage;
  fiDriverTransfer: FIDriverTransferPage;
  fiLogbook: FILogbookPage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiFleetDataManagementPage = new FIFleetDataManagementPage(page);
    this.fiDriverTransfer = new FIDriverTransferPage(page);
    this.fiLogbook = new FILogbookPage(page);
  }

  async goToLogbookManager() {
    await this.fiHomePage.selectActivityByName("Logbook Manager");
  }

  // Will pick the earliest year in the dropdown, unless a year value has been provided
  async searchForRegoAndSetYear({
    partialRego = "sg",
    year,
  }: {
    partialRego?: string;
    year?: string;
  }) {
    await this.fiLogbook.fieldSearchRegistration.type(partialRego);
    await this.fiLogbook.selectFirstResultInAutoComplete();
    if (year) {
      await this.fiLogbook.dropdownSelectFBTYear.selectOption(year);
    } else {
      await this.fiLogbook.dropdownSelectFBTYear.selectOption({ index: 1 });
    }
  }

  async clickEdit() {
    await this.fiLogbook.btnEdit.waitFor();
    await this.fiLogbook.btnEdit.click();
    if (!(await this.fiLogbook.btnStopEditing.isVisible())) {
      await this.fiLogbook.btnEdit.click({ force: true });
    }
    await this.fiLogbook.btnStopEditing.waitFor();
  }

  async enterStartAndEndOdo() {
    const start = faker.number.int({ max: 500 });
    const end = faker.number.int({ min: start + 1, max: 1000 });
    await this.fiLogbook.enterValueInTripSummaryTable(start.toString(), 1, 1);
    await this.fiLogbook.enterValueInTripSummaryTable(end.toString(), 1, 2);
    return {
      start: start.toString(),
      end: end.toString(),
    };
  }

  async saveTripSummaryTable() {
    await this.fiLogbook.btnSave.click();
    await this.fiLogbook.btnEdit.waitFor();
  }

  async verifyTripSummaryTableUpdated(
    expectedStart: string,
    expectedEnd: string,
  ) {
    await expect(this.fiLogbook.successMessage).toBeVisible();
    await this.page.waitForLoadState("networkidle");
    const actualStart = await this.fiLogbook.getValueInTripSummaryTable(1, 1);
    const actualEnd = await this.fiLogbook.getValueInTripSummaryTable(1, 2);
    expect(actualStart).toEqual(expectedStart);
    expect(actualEnd).toEqual(expectedEnd);
  }

  async getActualRegoFromDriverTransfer() {
    await this.fiDriverTransfer.registrationValue.waitFor({ timeout: 90000 });
    return await this.fiDriverTransfer.registrationValue.innerText();
  }
}
