import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIManageProfilePage } from "pages/fi/FIManageProfilePage";

export class ManageProfile {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiManageProfile: FIManageProfilePage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiManageProfile = new FIManageProfilePage(page);
  }

  async gotoManageProfile() {
    await this.fiHomePage.selectOptionFromDropdown("Manage Profile");
  }

  async editBankAccount(bankAccountNo: string, bsbNumber: string) {
    await this.fiManageProfile.checkBoxEditBankAccount.click();
    await this.fiManageProfile.fieldAccountNumber.clear();
    await this.fiManageProfile.fieldAccountNumber.type(bankAccountNo);
    await this.fiManageProfile.fieldBsbFirstTriplet.clear();
    await this.fiManageProfile.fieldBsbFirstTriplet.type(
      bsbNumber.substring(0, 3),
    );
    await this.fiManageProfile.fieldBsbSecondTriplet.clear();
    await this.fiManageProfile.fieldBsbSecondTriplet.type(
      bsbNumber.substring(3, 6),
    );
  }

  async editAddress(
    street: string,
    suburb: string,
    state: string,
    postcode: string,
    mobileNumber: string,
  ) {
    if (await this.fiManageProfile.checkboxEditAddress.isVisible()) {
      await this.fiManageProfile.checkboxEditAddress.click();
    }
    await this.fiManageProfile.fieldResidentialStreet.clear();
    await this.fiManageProfile.fieldResidentialStreet.type(street);
    await this.fiManageProfile.fieldResidentialSuburb.clear();
    await this.fiManageProfile.fieldResidentialSuburb.type(suburb);
    await this.fiManageProfile.fieldResidentialState.selectOption({
      label: state,
    });
    await this.fiManageProfile.fieldResidentialPostCode.clear();
    await this.fiManageProfile.fieldResidentialPostCode.type(postcode);
    await this.fiManageProfile.fieldResidentialMobileNum.clear();
    await this.fiManageProfile.fieldResidentialMobileNum.type(mobileNumber);
  }

  async saveUpdates() {
    if (await this.fiManageProfile.checkboxAuthorizeDebit.isVisible()) {
      await this.fiManageProfile.checkboxAuthorizeDebit.click();
      await this.fiManageProfile.checkboxAcknowledgePersonalInfo.click();
    }
    await this.fiManageProfile.btnSave.click();
    await this.fiManageProfile.alertFinishedProcessing.waitFor();
    expect(
      await this.fiManageProfile.alertFinishedProcessing.innerText(),
    ).toContain(
      "The changes you have requested have been successfully updated on your account.",
    );
  }

  async verifyBankAccountDetailsNovatedDriver(
    bankAccountNo: string,
    bsbNumber: string,
  ) {
    expect(
      await this.fiManageProfile.fieldAccountNumber.getAttribute("value"),
    ).toBe("**" + bankAccountNo.substring(2, 6));
    await this.verifyBSB(bsbNumber);
  }

  async verifyBankAccountDetailsAutopakDriver(
    bankAccountNo: string,
    bsbNumber: string,
  ) {
    expect(
      await this.fiManageProfile.fieldAccountNumber.getAttribute("value"),
    ).toBe(bankAccountNo);
    await this.verifyBSB(bsbNumber);
  }

  async verifyBSB(bsbNumber: string) {
    expect(
      await this.fiManageProfile.fieldBsbFirstTriplet.getAttribute("value"),
    ).toBe(bsbNumber.substring(0, 3));
    expect(
      await this.fiManageProfile.fieldBsbSecondTriplet.getAttribute("value"),
    ).toBe(bsbNumber.substring(3, 6));
  }

  async verifyAddressDetails(
    street: string,
    suburb: string,
    state: string,
    postcode: string,
    mobileNumber: string,
  ) {
    expect(
      await this.fiManageProfile.fieldResidentialStreet.getAttribute("value"),
    ).toBe(street);
    expect(
      await this.fiManageProfile.fieldResidentialSuburb.getAttribute("value"),
    ).toBe(suburb);
    expect(
      await this.fiManageProfile.fieldResidentialState
        .locator('[selected="selected"]')
        .innerText(),
    ).toBe(state);
    expect(
      await this.fiManageProfile.fieldResidentialPostCode.getAttribute("value"),
    ).toBe(postcode);
    expect(
      (
        await this.fiManageProfile.fieldResidentialMobileNum.getAttribute(
          "value",
        )
      )?.trim(),
    ).toBe(mobileNumber);
  }
}
