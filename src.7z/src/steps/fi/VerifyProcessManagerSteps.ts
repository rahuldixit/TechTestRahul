import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIProcessManager } from "pages/fi/FIPRocessManagerPage";
import moment from "moment";

export class VerifyProcessManagerSteps {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiFleetProcessManagerPage: FIProcessManager;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiFleetProcessManagerPage = new FIProcessManager(page);
  }

  async gotoProcessManager() {
    await this.fiHomePage.selectActivityByName("Process Manager");
    await this.fiFleetProcessManagerPage.resultsTable.waitFor();
  }

  async selectActiveProcesses() {
    await this.fiFleetProcessManagerPage.fromDate.clear();
    await this.fiFleetProcessManagerPage.fromDate.type(
      moment().subtract(1, "year").format("DD/MM/YYYY"),
    );
    await this.fiFleetProcessManagerPage.toDate.clear();
    await this.fiFleetProcessManagerPage.toDate.type(
      moment().format("DD/MM/YYYY"),
    );
    await this.fiFleetProcessManagerPage.selectStatus.click();
    await this.fiFleetProcessManagerPage.selectStatus.selectOption({
      label: "Active",
    });
    await this.fiFleetProcessManagerPage.btnSearch.click();
  }

  async selectResolvedProcesses() {
    await this.fiFleetProcessManagerPage.fromDate.clear();
    await this.fiFleetProcessManagerPage.fromDate.type(
      moment().subtract(1, "year").format("DD/MM/YYYY"),
    );
    await this.fiFleetProcessManagerPage.toDate.clear();
    await this.fiFleetProcessManagerPage.toDate.type(
      moment().format("DD/MM/YYYY"),
    );
    await this.fiFleetProcessManagerPage.selectStatus.click();
    await this.fiFleetProcessManagerPage.selectStatus.selectOption({
      label: "Resolved / Closed",
    });
    await this.fiFleetProcessManagerPage.btnSearch.click();
  }

  async verifyActiveProcesses() {
    await this.fiFleetProcessManagerPage.resultsTable.waitFor();
    const results = await this.fiFleetProcessManagerPage.resultsTable
      .locator("tbody tr")
      .all();
    for (let i = 0; i < results.length; i++) {
      if ((await results[i].locator("td").all()).length != 1) {
        const status = (
          await results[i].locator("td").nth(5).innerText()
        ).trim();
        expect(status).not.toBe("Resolved");
      }
    }
  }

  async verifyResolvedProcesses() {
    await this.fiFleetProcessManagerPage.resultsTable.waitFor();
    const results = await this.fiFleetProcessManagerPage.resultsTable
      .locator("tbody tr")
      .all();
    for (let i = 0; i < results.length; i++) {
      if ((await results[i].locator("td").all()).length != 1) {
        const status = (
          await results[i].locator("td").nth(5).innerText()
        ).trim();
        expect(status).toBe("Resolved");
      }
    }
  }
}
