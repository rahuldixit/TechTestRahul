import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIFleetListingPage } from "pages/fi/FIFleetListingPage";
import { FIVehicleDetailsPage } from "../../pages/fi/FIVehicleDetailsPage";
import { FleetListing } from "./VerifyFleetListingReportDisplayedSteps";

export class SearchRego {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiFIFleetListingPage: FIFleetListingPage;
  fiVehicleDetailsPage: FIVehicleDetailsPage;
  fiFleetListing: FleetListing;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiFIFleetListingPage = new FIFleetListingPage(page);
    this.fiVehicleDetailsPage = new FIVehicleDetailsPage(page);
    this.fiFleetListing = new FleetListing(page);
  }

  async getAndSearchRego() {
    const rego = await this.getRandomRegoFromHomePage();
    await this.fiHomePage.searchBox.type(rego);
    await this.fiHomePage.searchIcon.click();
    await this.fiHomePage.clickRegoSearchResultLink(rego);
    return rego;
  }

  async getRandomRegoFromHomePage() {
    // IF regos appear on Home page
    if (await this.fiHomePage.regoNumbers.first().isVisible()) {
      return await this.fiHomePage.getRandomRegoFromDriverBehaviourWidget();
    }
    // ELSE got to Fleet Listing to get one, then return Home
    else {
      await this.fiFleetListing.goToFleetListingPage();
      const rego =
        await this.fiFleetListing.getRandomRegoFromFleetListingPage();
      await this.fiFIFleetListingPage.goToHome();
      return rego;
    }
  }

  async getActualRegoFromVehicleDetailsPage() {
    await this.fiVehicleDetailsPage.vehicleDetailsHeading.waitFor({
      timeout: 90000,
    });
    await expect(this.fiVehicleDetailsPage.vehicleDetailsHeading).toBeVisible();
    const actualRego = await this.fiVehicleDetailsPage.getRegoValue();
    return actualRego;
  }
}
