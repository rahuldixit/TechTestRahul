import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";

export class SubmitOdoReading {
  readonly page: Page;
  fiHomePage: FIHomePage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
  }

  async goToSubmitOdoReadingDialog() {
    await this.fiHomePage.selectActivityByName("Submit Odo Reading");
  }

  async getRegoFromSubmitOdoReading() {
    await this.fiHomePage.headingSubmitOdoReading.waitFor();
    const actualRego =
      await this.fiHomePage.registrationValueInSubmitOdo.getAttribute("value");
    return actualRego;
  }

  async submitNewOdoReading(kmToAdd: number) {
    let odoReading = Number(
      (await this.fiHomePage.valueLastReadingRecorded.innerText())
        .split(",")
        .join(""),
    );
    odoReading += kmToAdd;
    await this.fiHomePage.fieldNewReading.type(odoReading.toString());
    await this.fiHomePage.btnSubmitOdo.click();
    await this.fiHomePage.odoSpinner.isVisible();
    await this.waitForOdoSpinner();
    expect(this.fiHomePage.submitOdoError).not.toBeVisible();
    const actualLastReading = Number(
      (await this.fiHomePage.valueLastReadingKm.innerText())
        .split(",")
        .join(""),
    );
    expect(actualLastReading).toEqual(odoReading);
  }

  async waitForOdoSpinner(timeoutInSeconds = 3) {
    const isLoading = await this.fiHomePage.odoSpinner.isVisible();
    if (isLoading && timeoutInSeconds) {
      await this.page.waitForTimeout(1000);
      await this.waitForOdoSpinner(--timeoutInSeconds);
    }
  }
}
