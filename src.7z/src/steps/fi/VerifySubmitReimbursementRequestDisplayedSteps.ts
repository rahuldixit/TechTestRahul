import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FISubmitReimbursementRequestPage } from "../../pages/fi/FISubmitReimbursementRequestPage";
import { faker } from "@faker-js/faker";
import moment from "moment";

export class SubmitReimbursementSteps {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiSubmitReimbursementRequestPage: FISubmitReimbursementRequestPage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiSubmitReimbursementRequestPage =
      new FISubmitReimbursementRequestPage(page);
  }

  //For Novated Driver and NVB Employee
  async goToSubmitReimbursement() {
    await this.fiHomePage.selectActivityByName("Submit Reimbursement Request");
    await this.fiSubmitReimbursementRequestPage.headingSubmitReimbursement.waitFor(
      { timeout: 60000 },
    );
  }

  async verifyHeadingsForNovatedDriver() {
    expect(
      this.fiSubmitReimbursementRequestPage.headingAccountBalance,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.headingReimbursementDetails,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.headingDeclaration,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.textYourAvailableBalance,
    ).toBeVisible();
  }

  //For Drivers
  async getRegoFromSubmitReimbursement() {
    const header =
      await this.fiSubmitReimbursementRequestPage.headingSubmitReimbursement.innerText();
    const actualRego = header.split("-")[1].substring(1, 8);
    return actualRego;
  }

  //For NVB Employee
  async getRequestFromSubmitReimbursement() {
    let actualRequestType =
      await this.fiSubmitReimbursementRequestPage.headingSubmitReimbursement.innerText();
    actualRequestType = actualRequestType.split("for ")[1];
    return actualRequestType.toUpperCase();
  }

  async verifyHeadingsForNVBEmployee() {
    expect(
      this.fiSubmitReimbursementRequestPage.headingPleasefillInTheTotals,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.headingDeclaration,
    ).toBeVisible();
  }

  //For Autopak Drivers
  async goToRequestReimbursementOrDirectPayment() {
    await this.fiHomePage.selectActivityByName(
      "Request Reimbursement or Direct Payment",
    );
    await this.fiSubmitReimbursementRequestPage.headingSubmitReimbursement.waitFor(
      { timeout: 60000 },
    );
  }

  async verifyHeadingsForAutopakDriver() {
    expect(
      this.fiSubmitReimbursementRequestPage
        .headingExpeseReimbursementOrDirectpayment,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.headingOtherRunningCostExpenses,
    ).toBeVisible();
    expect(
      this.fiSubmitReimbursementRequestPage.headingDeclaration,
    ).toBeVisible();
  }

  async completeReimbursementForAutopakDriver(pdfFilePath: string) {
    const registration = faker.number.int({ max: 1000 }).toFixed(2).toString();
    const ctp = faker.number.int({ max: 1000 }).toFixed(2).toString();
    const autoClubMembership = faker.number
      .int({ max: 1000 })
      .toFixed(2)
      .toString();
    const comprehensiveInsurance = faker.number
      .int({ max: 1000 })
      .toFixed(2)
      .toString();
    const fuelPurchase = faker.number.int({ max: 1000 }).toFixed(2).toString();
    const maintenance = faker.number.int({ max: 1000 }).toFixed(2).toString();
    const otherExpenses = faker.number.int({ max: 1000 }).toFixed(2).toString();
    const total =
      Number(registration) +
      Number(ctp) +
      Number(autoClubMembership) +
      Number(comprehensiveInsurance) +
      Number(fuelPurchase) +
      Number(maintenance) +
      Number(otherExpenses);
    await this.fiSubmitReimbursementRequestPage.inputRegistration.clear();
    await this.fiSubmitReimbursementRequestPage.inputRegistration.type(
      registration,
    );
    await this.fiSubmitReimbursementRequestPage.inputCtp.clear();
    await this.fiSubmitReimbursementRequestPage.inputCtp.type(ctp);
    await this.fiSubmitReimbursementRequestPage.inputAutoClubMembership.clear();
    await this.fiSubmitReimbursementRequestPage.inputAutoClubMembership.type(
      autoClubMembership,
    );
    await this.fiSubmitReimbursementRequestPage.inputComprehensiveInsurance.clear();
    await this.fiSubmitReimbursementRequestPage.inputComprehensiveInsurance.type(
      comprehensiveInsurance,
    );
    await this.fiSubmitReimbursementRequestPage.inputFuelPurchase.clear();
    await this.fiSubmitReimbursementRequestPage.inputFuelPurchase.type(
      fuelPurchase,
    );
    await this.fiSubmitReimbursementRequestPage.inputMaintenance.clear();
    await this.fiSubmitReimbursementRequestPage.inputMaintenance.type(
      maintenance,
    );
    await this.fiSubmitReimbursementRequestPage.inputOtherExpenses.clear();
    await this.fiSubmitReimbursementRequestPage.inputOtherExpenses.type(
      otherExpenses,
    );
    await this.fiSubmitReimbursementRequestPage.inputComments.type(
      "Automation Test",
    );
    await this.fiSubmitReimbursementRequestPage.checkboxReimbursementDeclaration.click();
    await this.fiSubmitReimbursementRequestPage.uploadReimbursementPDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.btnSubmit.click();
    return [
      total.toFixed(2).toString(),
      registration,
      ctp,
      autoClubMembership,
      comprehensiveInsurance,
      fuelPurchase,
      maintenance,
      otherExpenses,
    ];
  }

  async verifyReimbursementComplete() {
    await this.fiSubmitReimbursementRequestPage.textClaimCompletion.waitFor();
    expect(
      await this.fiSubmitReimbursementRequestPage.textClaimCompletion.innerText(),
    ).toContain("Thank you for submitting your claim.");
  }

  async verifyReimbursement(
    total: string,
    registration: string,
    ctp: string,
    autoClubMembership: string,
    comprehensiveInsurance: string,
    fuelPurchase: string,
    maintenance: string,
    otherExpenses: string,
  ) {
    await this.fiHomePage.selectActivityByName("Reimbursement Request History");
    await this.fiSubmitReimbursementRequestPage.tableReimbursement.waitFor();
    const today = moment().format("DD/MMM/YYYY");
    const lastEntry =
      await this.fiSubmitReimbursementRequestPage.getLastItem(today);
    await lastEntry.click();

    const lastTotal =
      await this.fiSubmitReimbursementRequestPage.cellReimbursementTotal.innerText();
    expect(lastTotal.replace("$", "").replace(",", "").trim()).toBe(total);

    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(0, 0),
    ).toBe("Registration");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(1, 0),
    ).toBe("CTP Insurance");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(2, 0),
    ).toBe("Auto Club Membership");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(3, 0),
    ).toBe("Comprehensive Insurance");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(4, 0),
    ).toBe("Fuel");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(5, 0),
    ).toBe("Maintenance");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(6, 0),
    ).toBe("Other Expense");

    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(0, 1),
    ).toBe(registration);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(1, 1),
    ).toBe(ctp);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(2, 1),
    ).toBe(autoClubMembership);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(3, 1),
    ).toBe(comprehensiveInsurance);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(4, 1),
    ).toBe(fuelPurchase);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(5, 1),
    ).toBe(maintenance);
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(6, 1),
    ).toBe(otherExpenses);

    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(0, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(1, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(2, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(3, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(4, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(5, 2),
    ).toBe("Pay driver");
    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(6, 2),
    ).toBe("Pay driver");

    expect(
      await this.fiSubmitReimbursementRequestPage.getLastEntryCellData(-2, 3),
    ).toBe("Automation Test");
  }

  //For Novated Drivers
  async goToSubmitReimbursementRequest() {
    await this.fiHomePage.selectActivityByName("Submit Reimbursement Request");
    await this.fiSubmitReimbursementRequestPage.headingSubmitReimbursement.waitFor(
      { timeout: 60000 },
    );
  }

  async completeReimbursementForNovatedDriver(pdfFilePath: string) {
    const registrationNovated = faker.number
      .int({ max: 10 })
      .toFixed(2)
      .toString();
    const fuel = faker.number.int({ max: 10 }).toFixed(2).toString();
    const maintenanceNovated = faker.number
      .int({ max: 10 })
      .toFixed(2)
      .toString();
    const Insurance = faker.number.int({ max: 10 }).toFixed(2).toString();
    const InsuranceExcess = faker.number.int({ max: 10 }).toFixed(2).toString();
    const NSWctp = faker.number.int({ max: 10 }).toFixed(2).toString();
    await this.fiSubmitReimbursementRequestPage.inputRegistrationNovated.clear();
    await this.fiSubmitReimbursementRequestPage.inputRegistrationNovated.type(
      registrationNovated,
    );
    expect(
      this.fiSubmitReimbursementRequestPage.textRegistrationFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadRegistrationPDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.inputFuel.clear();
    await this.fiSubmitReimbursementRequestPage.inputFuel.type(fuel);
    expect(
      this.fiSubmitReimbursementRequestPage.textFuelFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadFuelPDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.inputMaintenanceNovated.clear();
    await this.fiSubmitReimbursementRequestPage.inputMaintenanceNovated.type(
      maintenanceNovated,
    );
    expect(
      this.fiSubmitReimbursementRequestPage.textMaintenanceFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadMaintenancePDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.inputInsurance.clear();
    await this.fiSubmitReimbursementRequestPage.inputInsurance.type(Insurance);
    expect(
      this.fiSubmitReimbursementRequestPage.textInsuranceFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadInsurancePDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.inputInsuranceExcess.clear();
    await this.fiSubmitReimbursementRequestPage.inputInsuranceExcess.type(
      InsuranceExcess,
    );
    expect(
      this.fiSubmitReimbursementRequestPage.textInsuranceExcessFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadInsuranceExcessPDF.setInputFiles(
      pdfFilePath,
    );
    await this.fiSubmitReimbursementRequestPage.inputNSWCtp.clear();
    await this.fiSubmitReimbursementRequestPage.inputNSWCtp.type(NSWctp);
    expect(
      this.fiSubmitReimbursementRequestPage.textNSWCtpFileError,
    ).toBeVisible();
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.uploadNSWCtpPDF.setInputFiles(
      pdfFilePath,
    );
    expect(this.fiSubmitReimbursementRequestPage.btnSubmit).toBeDisabled();
    await this.fiSubmitReimbursementRequestPage.checkboxReimbursementDeclaration.click();
    await this.fiSubmitReimbursementRequestPage.btnSubmit.click();
  }

  async verifyReimbursementCompleteNovated() {
    this.verifyReimbursementComplete();
    expect(
      this.fiSubmitReimbursementRequestPage.textReimbursementCompleteMessage,
    ).toBeVisible;
  }
}
