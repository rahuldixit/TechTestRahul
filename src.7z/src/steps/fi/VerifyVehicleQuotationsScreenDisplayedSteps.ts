import { Page, expect } from "@playwright/test";
import { FIHomePage } from "../../pages/fi/FIHomePage";
import { FIQuotationPage } from "../../pages/fi/FIQuotationPage";

export class VehicleQuotations {
  readonly page: Page;
  fiHomePage: FIHomePage;
  fiQuotationPage: FIQuotationPage;

  constructor(page: Page) {
    this.page = page;
    this.fiHomePage = new FIHomePage(page);
    this.fiQuotationPage = new FIQuotationPage(page);
  }

  async goToVehicleQuotations() {
    await this.fiHomePage.selectActivityByName("Vehicle Quotations");
  }

  async goToCreateNewQuotation() {
    await this.fiQuotationPage.btnCreateNew.waitFor({ timeout: 90000 });
    await this.fiQuotationPage.btnCreateNew.click();
    await this.fiHomePage.newQuotationHeader.waitFor({ timeout: 90000 });
  }

  /* 
  If "" is provided for: quoteTemplate, make, model or derivative, 
  then a random drop-down option will be selected
  */
  async createNewQuotation({
    costCentreNumber,
    quoteTemplate,
    make,
    model,
    derivative,
  }: {
    costCentreNumber: string;
    quoteTemplate?: string;
    make?: string;
    model?: string;
    derivative?: string;
  }) {
    await this.fiHomePage.selectCostCentreForNewQuotation(costCentreNumber);
    await this.fiHomePage.selectQuoteTemplateByValue(quoteTemplate);
    await this.fiHomePage.selectMakeByName(make);
    await this.fiHomePage.selectModelByName(model);
    await this.fiHomePage.selectDerivativeByValue(derivative);
    await this.fiQuotationPage.labelContractTerm.waitFor({ timeout: 90000 });
  }

  async verifyQuotationDataLoaded() {
    this.fiQuotationPage.labelContractTerm.scrollIntoViewIfNeeded();
    await expect(
      this.fiQuotationPage.labelServicesEstablishmentFee,
    ).toBeVisible({ timeout: 90000 });
  }
}
