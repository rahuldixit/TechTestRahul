import { Page, expect } from "@playwright/test";
import { faker } from "@faker-js/faker";
import { IMSDashboardPage } from "../../pages/ims/IMSDashboardPage";
import { IMSViewIssuePage } from "../../pages/ims/IMSViewIssuePage";
import { FileUpload } from "../../../utils/FileUpload";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";

export class CreateOppurtunity {
  imsDashboardPage: IMSDashboardPage;
  imsViewIssuePage: IMSViewIssuePage;
  fileUpload: FileUpload;
  msOnlineLogin: MsOnlineLoginPage;
  page: Page;

  constructor(page: Page) {
    this.imsDashboardPage = new IMSDashboardPage(page);
    this.imsViewIssuePage = new IMSViewIssuePage(page);
    this.msOnlineLogin = new MsOnlineLoginPage(page);
    this.fileUpload = new FileUpload(page);
    this.page = page;
  }

  async createNewOppurtunityAndRetrieveQuoteDetails({
    customerName,
    title = "Mr",
    firstname = faker.person.firstName(),
    surname = faker.person.lastName(),
    mobnum = "0400000001",
    emailaddr,
    post = faker.number.int({ min: 2000, max: 6000 }) + "",
    leadsrc = "Email",
    description = faker.lorem.sentence(10),
    fileUpload = false,
    filePath = "./src/tests/quomo/testdata/employer_approval.pdf",
  }: {
    customerName: string;
    title?: string;
    firstname?: string;
    surname?: string;
    mobnum?: string;
    emailaddr: string;
    post?: string;
    leadsrc?: string;
    description?: string;
    fileUpload?: boolean;
    filePath?: string;
  }) {
    await this.createIssueNewOppurtunity({
      customerName,
      title,
      firstname,
      surname,
      mobnum,
      emailaddr,
      post,
      leadsrc,
      description,
      fileUpload,
      filePath,
    });
    return await this.retrieveIssueNumFromLead();
  }

  async createEndOfTermOppurtunityAndRetrieveQuoteDetails({
    customerName,
    title = "Mrs",
    firstName: firstName = faker.person.firstName(),
    surName: surName = faker.person.lastName(),
    mobNum: mobNum = "0400000001",
    emailAddr: emailAddr,
    post = faker.number.int({ min: 2000, max: 6000 }) + "",
    leadSrc: leadSrc = "Email",
    conRef: conRef,
    description = faker.lorem.sentence(10),
  }: {
    customerName: string;
    title?: string;
    firstName?: string;
    surName?: string;
    mobNum?: string;
    emailAddr: string;
    post?: string;
    leadSrc?: string;
    conRef: string;
    description?: string;
  }) {
    await this.createIssueEndOfTermOppurtunity({
      customerName,
      title,
      firstName,
      surName,
      mobNum,
      emailAddr,
      post,
      leadSrc,
      conRef,
      description,
    });
    return await this.retrieveIssueNumFromLead();
  }

  async createIssueNewOppurtunity({
    customerName,
    title = "Mr",
    firstname = faker.person.firstName(),
    surname = faker.person.lastName(),
    mobnum = "0400000001",
    emailaddr,
    post = faker.number.int({ min: 2000, max: 6000 }) + "",
    leadsrc = "Email",
    description = faker.lorem.sentence(10),
    fileUpload = false,
    filePath = "./src/tests/quomo/testdata/employer_approval.pdf",
  }: {
    customerName: string;
    title?: string;
    firstname?: string;
    surname?: string;
    mobnum?: string;
    emailaddr: string;
    post?: string;
    leadsrc?: string;
    description?: string;
    fileUpload?: boolean;
    filePath?: string;
  }) {
    await this.fillOutNewOpportunity({
      customerName,
      title,
      firstname,
      surname,
      mobnum,
      emailaddr,
      post,
      leadsrc,
      description,
    });
    if (fileUpload) {
      /*
      Sometimes the fileupload has an error about trying again.
      This code will close the Issue form, click Create button and fill it out again
      up to maxAttempts
      */
      const maxAttempts = 3;
      let fileError: string;
      fileError = await this.uploadIMSFile(filePath);
      for (let attempt = 2; attempt <= maxAttempts && fileError; attempt++) {
        console.log("File upload error. Trying again. Attempt: " + attempt);
        await this.page.reload({ waitUntil: "domcontentloaded" });
        await this.fillOutNewOpportunity({
          customerName,
          title,
          firstname,
          surname,
          mobnum,
          emailaddr,
          post,
          leadsrc,
          description,
        });
        fileError = await this.uploadIMSFile(filePath);
      }
      console.log("File upload success");
    }
    await this.imsDashboardPage.btnSubmitIssue.click();
  }

  async fillOutNewOpportunity({
    customerName,
    title = "Mr",
    firstname = faker.person.firstName(),
    surname = faker.person.lastName(),
    mobnum = "0400000001",
    emailaddr,
    post = faker.number.int({ min: 2000, max: 6000 }) + "",
    leadsrc = "Email",
    description = faker.lorem.sentence(10),
  }: {
    customerName: string;
    title?: string;
    firstname?: string;
    surname?: string;
    mobnum?: string;
    emailaddr: string;
    post?: string;
    leadsrc?: string;
    description?: string;
  }) {
    await this.imsDashboardPage.btnCreate.click();
    await this.imsDashboardPage.createIssueDialog.waitFor();
    await this.imsDashboardPage.selectLeadTypeNewOpp.click();
    await this.imsDashboardPage.selectCRMFromDropdown(customerName);
    await this.imsDashboardPage.selectTitle.selectOption(title);
    await this.imsDashboardPage.firstName.fill(firstname);
    await this.imsDashboardPage.surName.fill(surname);
    await this.imsDashboardPage.mobileNum.fill(mobnum);
    await this.imsDashboardPage.contactEmail.fill(emailaddr);
    await this.imsDashboardPage.postcode.fill(post);
    await this.imsDashboardPage.selectLeadSource.selectOption(leadsrc);
    await this.imsDashboardPage.assignToMe.click();
    await this.imsDashboardPage.descriptionBox.fill(description);
  }

  async createIssueEndOfTermOppurtunity({
    customerName,
    title = "Mrs",
    firstName: firstName = faker.person.firstName(),
    surName: surName = faker.person.lastName(),
    mobNum: mobNum = "0400000001",
    emailAddr: emailAddr,
    post = faker.number.int({ min: 2000, max: 6000 }) + "",
    leadSrc: leadSrc = "Email",
    conRef: conRef,
    description = faker.lorem.sentence(10),
  }: {
    customerName: string;
    title?: string;
    firstName?: string;
    surName?: string;
    mobNum?: string;
    emailAddr: string;
    post?: string;
    leadSrc?: string;
    conRef: string;
    description?: string;
  }) {
    await this.imsDashboardPage.issueTable.waitFor();
    await this.imsDashboardPage.btnCreate.click();
    await this.imsDashboardPage.createIssueDialog.isVisible();
    await this.imsDashboardPage.selectLeadTypeEndOfTermOpp.click();
    await this.imsDashboardPage.selectCRMFromDropdown(customerName);
    await this.imsDashboardPage.selectTitle.selectOption(title);
    await this.imsDashboardPage.firstName.fill(firstName);
    await this.imsDashboardPage.surName.fill(surName);
    await this.imsDashboardPage.mobileNum.fill(mobNum);
    await this.imsDashboardPage.contactEmail.fill(emailAddr);
    await this.imsDashboardPage.postcode.fill(post);
    await this.imsDashboardPage.selectLeadSource.selectOption(leadSrc);
    await this.imsDashboardPage.assignToMe.click();
    await this.imsDashboardPage.contractRef.fill(conRef);
    await this.imsDashboardPage.descriptionBox.fill(description);
    await this.waitForSpinnerNextToCreateBtn();
    await this.imsDashboardPage.btnSubmitIssue.click();
  }

  async waitForSpinnerNextToCreateBtn() {
    let timeout = 0;
    while (
      (await this.imsDashboardPage.spinner.count()) > 0 &&
      timeout != 60000
    ) {
      timeout += timeout + 5000;
      await this.page.waitForTimeout(5000);
    }
  }

  async uploadIMSFile(filePath: string) {
    await this.fileUpload.uploadFile(filePath, ".issue-drop-zone__text");
    await this.fileUpload.waitForIMSFileUploadProgressBar();
    const error = await this.imsDashboardPage.fileUploadError.innerText({
      timeout: 500,
    });
    // Must refresh the page and fill out the form again if this error occurs
    if (
      error &&
      error.includes(
        "Jira could not attach the file as there was a missing token. Please try attaching the file again.",
      )
    ) {
      return error;
    }
    expect(error, { message: error }).toBeFalsy();
    await this.imsDashboardPage.fileAttachedMsg.waitFor({
      state: "visible",
      timeout: 5000,
    });
    await this.fileUpload.page.waitForTimeout(1000);
  }

  async openQuoteURLFromLead() {
    await this.imsViewIssuePage.clickOnQuoteLink();
  }

  async retrieveIssueNumFromLead() {
    await this.imsDashboardPage.selectCreatedIssue();
    await this.imsViewIssuePage.waitFor();
    return {
      issueNum: await this.imsViewIssuePage.issueLink.innerText(),
    };
  }
}
