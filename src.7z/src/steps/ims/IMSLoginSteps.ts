import { Page } from "@playwright/test";
import { IMSLoginPage } from "../../pages/ims/IMSLoginPage";
import { IMSDashboardPage } from "../../pages/ims/IMSDashboardPage";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";

export class LoginIntoIMS {
  imsLoginPage: IMSLoginPage;
  imsDashboardPage: IMSDashboardPage;
  msOnlinePage: MsOnlineLoginPage;
  page: Page;

  constructor(page: Page) {
    this.imsLoginPage = new IMSLoginPage(page);
    this.imsDashboardPage = new IMSDashboardPage(page);
    this.msOnlinePage = new MsOnlineLoginPage(page);
    this.page = page;
  }
  async loginIntoIMSUsingUsernameAndPassword(
    url: string,
    username: string,
    password: string,
  ) {
    await this.imsLoginPage.openIMS(url);
    await this.imsLoginPage.imsUsername.fill(username, { timeout: 5000 });
    await this.imsLoginPage.imsPassword.fill(password, { timeout: 5000 });
    await this.imsLoginPage.imsLogInButton.click();
    await this.imsDashboardPage.waitFor();
  }
}
