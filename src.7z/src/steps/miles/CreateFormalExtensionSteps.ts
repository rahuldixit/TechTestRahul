import { Page } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesNewSalesRequestPage } from "../../pages/miles/MilesNewSalesRequestPage";
import { MilesFleetVehiclePage } from "../../pages/miles/MilesFleetVehiclePage";
import { ModifyContract } from "./ModifyContractSteps";
import { NEW_QUOTE_VEHICLE_LABELS } from "../../../enums/milesapp";
import moment from "moment";

export class CreateFormalExtension {
  readonly page: Page;
  currentOdo: number;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesSalesRequestPage: MilesNewSalesRequestPage;
  milesFleetVehiclePage: MilesFleetVehiclePage;
  modifyContract: ModifyContract;

  constructor(page: Page) {
    this.page = page;
    this.currentOdo = 0;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesSalesRequestPage = new MilesNewSalesRequestPage(page);
    this.milesFleetVehiclePage = new MilesFleetVehiclePage(page);
    this.modifyContract = new ModifyContract(page);
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
  }

  async addNewOdoReading(distanceToAdd = 10) {
    await this.milesContractPage.btnEyeIconNextToCurrentOdo.click();
    await this.milesContractPage.closeBtnMsgCollapser();
    const currerntDistance =
      await this.milesFleetVehiclePage.getValueInVehicleEventsTable(0, 1);
    this.currentOdo =
      (await this.getDistanceNumFromString(currerntDistance)) + distanceToAdd;
    const totalDistance = this.currentOdo + " Km";
    //IF previous Odo reading was less than 2 weeks ago, then skip adding a new reading
    const previousOdoDate =
      await this.milesFleetVehiclePage.getValueInVehicleEventsTable(0, 0);
    const previousDate = moment(previousOdoDate.split(" ")[0], "DD/MM/YYYY");
    const twoWeeksAgo = moment().add(-13, "days");
    if (previousDate < twoWeeksAgo) {
      await this.milesFleetVehiclePage.btnAddForVehicleEvents.click();
      await this.milesFleetVehiclePage.enterValueInVehicleEventsTable(
        totalDistance,
        1,
      );
      await this.milesFleetVehiclePage.enterValueInVehicleEventsTable(
        "Manual Odo Capture",
        3,
      );
      await this.page.keyboard.press("Enter");
      await this.milesFleetVehiclePage.clickCheckboxInVehicleEventsTable(0);
      await this.milesFleetVehiclePage.btnSave.click();
      await this.milesFleetVehiclePage.waitUntilLoadingFinishes();
    }
  }

  // Odo value needs to have been set previously
  async getCurrentOdo() {
    return this.currentOdo;
  }

  async goToLtcTab() {
    await this.milesFleetVehiclePage.clickBottomTab("LTC");
  }

  async modifyContractForFormalExtension() {
    await this.modifyContract.modifyContractAndSelectChangeReason(
      "Formal Extension",
    );
  }

  // Update the Duration and Distance based on current values
  async updateDurationAndDistance(durationToAdd = 12, distanceToAdd = 1000) {
    //Get current Duration and Distance, then increase them
    const durationText = await this.milesSalesRequestPage.retrieveValueByLabel(
      NEW_QUOTE_VEHICLE_LABELS.DURATION,
    );
    const duration = Number(durationText.split(" ")[0]) + durationToAdd;
    const existingTotalDistance =
      await this.milesSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.TOTAL_DISTANCE,
      );
    const totalDistance = await this.getDistanceNumFromString(
      existingTotalDistance,
    );
    let distance = await this.getCurrentOdo();
    if (distance < totalDistance) {
      distance = totalDistance;
    }
    distance += distanceToAdd;
    //Enter new Duration and Distance
    await this.milesSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DURATION,
      duration.toString(),
    );
    await this.milesSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DISTANCE,
      distance.toString(),
      200,
    );
  }

  //Provide the distance in format "20,000 Km". Returns distance as a number
  async getDistanceNumFromString(distanceAsString: string) {
    distanceAsString = distanceAsString
      .split(" ")[0] // remove " Km"
      .split(",") // remove ","
      .join("");
    return Number(distanceAsString);
  }
}
