import { Page } from "@playwright/test";
import { CONTACT_LABELS } from "../../../enums/milesapp";
import moment from "moment";
import { MilesContactPage } from "pages/miles/MilesContactPage ";
import { faker } from "@faker-js/faker";
import { MilesCustomerPage } from "pages/miles/MilesCustomerPage";

export class CreateNewContact {
  readonly page: Page;
  readonly contactPage: MilesContactPage;
  readonly customerPage: MilesCustomerPage;

  constructor(page: Page) {
    this.page = page;
    this.contactPage = new MilesContactPage(page);
    this.customerPage = new MilesCustomerPage(page);
  }

  async addNewDriver({
    title,
    firstName,
    lastName,
    gender,
    addressType,
    address,
    postCode,
    suburb,
    state,
    phoneType,
    phoneNumber,
    emailType,
    mailCategory,
  }: {
    title: string;
    firstName: string;
    lastName: string;
    gender: string;
    addressType: string;
    address: string;
    postCode: string;
    suburb: string;
    state: string;
    phoneType: string;
    phoneNumber: string;
    emailType: string;
    mailCategory: string;
  }) {
    const addressTableName = "Address";
    const addressTableIndex = -1;
    const addressRow = 0;

    await this.contactPage.clickField(CONTACT_LABELS.PERSON);
    await this.contactPage.enterValueByLabel2(CONTACT_LABELS.TITLE, title);
    await this.contactPage.enterValueByLabel2(
      CONTACT_LABELS.FIRST_NAME,
      firstName,
    );
    await this.contactPage.enterValueByLabel2(
      CONTACT_LABELS.LAST_NAME,
      lastName,
    );
    await this.contactPage.enterValueByLabel(CONTACT_LABELS.GENDER, gender, 4);
    await this.contactPage.addAddress.click({ force: true });
    const addressTypeCell = await this.contactPage.getTableCellLocator(
      addressTableName,
      addressTableIndex,
      addressRow,
      0,
    );
    await addressTypeCell.type(addressType);
    const addressCell = await this.contactPage.getTableCellLocator(
      addressTableName,
      addressTableIndex,
      addressRow,
      2,
    );
    await addressCell.click({ force: true });
    await addressCell.type(address);
    const postCodeCell = await this.contactPage.getTableCellLocator(
      addressTableName,
      addressTableIndex,
      addressRow,
      4,
    );
    await postCodeCell.click({ force: true });
    await this.page.waitForTimeout(1000);
    await postCodeCell.type(postCode);

    const suburbCodeCell = await this.contactPage.getTableCellLocator(
      addressTableName,
      addressTableIndex,
      addressRow,
      5,
    );
    await suburbCodeCell.click({ force: true });
    await suburbCodeCell.type(suburb);
    await suburbCodeCell.press("Enter");
    await this.page.waitForTimeout(1000);
    const stateCodeCell = await this.contactPage.getTableCellLocator(
      addressTableName,
      addressTableIndex,
      addressRow,
      5,
    );
    await stateCodeCell.click({ force: true });
    await stateCodeCell.type(state);
    await suburbCodeCell.press("Enter");

    const phoneTableName = "Phone Numbers";
    const phoneTableIndex = -1;
    const phonesRow = 0;
    await this.contactPage.addPhone.click({ force: true });
    const phoneTypeCell = await this.contactPage.getTableCellLocator(
      phoneTableName,
      phoneTableIndex,
      phonesRow,
      0,
    );
    await phoneTypeCell.type(phoneType);
    await phoneTypeCell.press("Enter");
    const phoneNumberCell = await this.contactPage.getTableCellLocator(
      phoneTableName,
      phoneTableIndex,
      phonesRow,
      2,
    );
    await phoneNumberCell.click({ force: true });
    await phoneNumberCell.type(phoneNumber);

    const internetTableName = "Internet Details";
    const internetTableIndex = -1;
    const internetRow = 0;
    await this.contactPage.addEmail.click({ force: true });
    const emailTypeCell = await this.contactPage.getTableCellLocator(
      internetTableName,
      internetTableIndex,
      internetRow,
      0,
    );
    await emailTypeCell.type(emailType);
    await emailTypeCell.press("Enter");
    const emailAddressCell = await this.contactPage.getTableCellLocator(
      internetTableName,
      internetTableIndex,
      internetRow,
      1,
    );
    await emailAddressCell.click({ force: true });
    await emailAddressCell.type(firstName + "." + lastName + "@gmail.com");
    await emailAddressCell.press("Enter");
    const mailCategoryCell = await this.contactPage.getTableCellLocator(
      internetTableName,
      internetTableIndex,
      internetRow,
      2,
    );
    await mailCategoryCell.click({ force: true });
    await mailCategoryCell.type(mailCategory);
    await mailCategoryCell.press("Enter");

    await this.contactPage.clickField(CONTACT_LABELS.OK);
    await this.contactPage.waitUntilLoadingFinishes();
    await this.contactPage.enterValueByLabel2(
      CONTACT_LABELS.DATE_OF_BIRTH,
      moment().subtract(25, "years").format("DD/MM/YYYY"),
    );
    await this.contactPage.btnSave.click();
    await this.contactPage.waitUntilLoadingFinishes();
  }

  async addPerson() {
    await this.contactPage.clickMenuItem("Person");
    await this.contactPage.enterValueByLabel2(
      CONTACT_LABELS.JOIN_DATE,
      moment().subtract(5, "years").format("DD/MM/YYYY"),
    );
    await this.contactPage.enterValueByLabel2(
      CONTACT_LABELS.EMPLOYEE_NUMBER,
      faker.number.bigInt().toString(),
    );
    await this.contactPage.btnSave.click();
    await this.contactPage.waitUntilLoadingFinishes();
  }

  async createNewDriver() {
    await this.customerPage.createDriver.click();
    await this.customerPage.waitUntilLoadingFinishes();
    await this.customerPage.editDriver.click({ force: true });
  }
}
