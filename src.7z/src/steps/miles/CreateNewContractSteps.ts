import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesNewSalesRequestPage } from "../../pages/miles/MilesNewSalesRequestPage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import {
  FUNDING_VERSION_LABELS,
  LEASE_SERVICE_LABELS,
  CONTRACT_LABELS,
  NEW_QUOTE_REQ_LABELS,
} from "../../../enums/milesapp";
import moment from "moment";

export class CreateNewContract {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesNewSalesRequestPage: MilesNewSalesRequestPage;
  milesContractPage: MilesContractPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesNewSalesRequestPage = new MilesNewSalesRequestPage(page);
    this.milesContractPage = new MilesContractPage(page);
  }

  async createNewMilesContract({
    quoteNum,
    fundOption,
    fcreditAuth,
  }: {
    quoteNum: string;
    fundOption: string;
    fcreditAuth: string;
  }) {
    await this.searchValue(quoteNum);
    await this.selectFundingArrangement(fundOption);
    await this.goToTPSComponent(fundOption);
    await this.enterAndSaveFunderCreditAuth(fcreditAuth);
    await this.milesContractPage.clickBottomTab("Quote " + quoteNum);
    await this.createContract();
    return await this.retrieveContractReferenceNumber();
  }

  async createNewMilesGreenfleetContract({
    quoteNum,
    fundOption,
    fcreditAuth,
    greenfleetService,
    expectedLeasePrice,
    expectedGST,
  }: {
    quoteNum: string;
    fundOption: string;
    fcreditAuth: string;
    greenfleetService: string;
    expectedLeasePrice: string;
    expectedGST: string;
  }) {
    await this.searchValue(quoteNum);
    await this.selectFundingArrangement(fundOption);
    await this.verifyGreenfleetService({
      greenfleet: greenfleetService,
      leasePrice: expectedLeasePrice,
      gst: expectedGST,
    });
    await this.goToTPSComponent(fundOption);
    await this.enterAndSaveFunderCreditAuth(fcreditAuth);
    await this.milesContractPage.clickBottomTab("Quote");
    await this.createContract();
    return await this.retrieveContractReferenceNumber();
  }

  async createNewNonGreenfleetContract({
    quoteNum,
    fundOption,
    fcreditAuth,
    greenfleet,
    carbonOffset,
  }: {
    quoteNum: string;
    fundOption: string;
    fcreditAuth: string;
    greenfleet: string;
    carbonOffset: string;
  }) {
    await this.searchValue(quoteNum);
    await this.selectFundingArrangement(fundOption);
    await this.verifyNonGreenfleet({
      greenfleetNotVisible: greenfleet,
      otherLeaseServiceVisible: carbonOffset,
    });
    await this.goToTPSComponent(fundOption);
    await this.enterAndSaveFunderCreditAuth(fcreditAuth);
    await this.milesContractPage.clickBottomTab("Quote");
    await this.createContract();
    return await this.retrieveContractReferenceNumber();
  }

  async searchValue(quoteNum: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(quoteNum);
  }

  /**
   * If Index > 0, Pass index value in testcase.
   * Foe example: For AQ Quote the index is 2 as the grid height element is visible
   * in 3 different tabs at the same time.
   * @param fundOption
   * @param index
   */
  async selectFundingArrangement(fundOption: string, index = 0) {
    await this.milesNewSalesRequestPage.clickMenuItem(
      CONTRACT_LABELS.LEASE_SERVICE,
    );
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.selectGridHeightForFundingArrangementInQuote(
      index,
    );
    await this.milesNewSalesRequestPage.selectFundingArrangementOption(
      fundOption,
    );
  }

  async goToTPSComponent(fundOption: string) {
    await this.milesNewSalesRequestPage.thirdPartyService.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.clickTPSComponent(fundOption);
  }

  async enterAndSaveFunderCreditAuth(fcreditAuth: string) {
    await this.milesNewSalesRequestPage.enterValueByLabel(
      FUNDING_VERSION_LABELS.FUNDING_CREDIT_AUTH,
      fcreditAuth,
      1,
    );
    await this.milesNewSalesRequestPage.clickOut(
      FUNDING_VERSION_LABELS.VAT_CODE,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
  }

  async createContract() {
    await this.milesNewSalesRequestPage.btnRefresh.click();
    await this.milesNewSalesRequestPage.btnContract.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes(60);
    await this.milesNewSalesRequestPage.contractLink.click();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(3000);
    expect(
      await this.milesNewSalesRequestPage.retrieveValueByLabel(
        CONTRACT_LABELS.STATUS,
      ),
    ).toContain("Initialized");
  }

  async retrieveContractReferenceNumber() {
    return await this.milesNewSalesRequestPage.contractReferenceNumber.inputValue();
  }

  // Verify values in Lease Service for Lease Price and GST/VATI
  async verifyGreenfleetService({
    ltc,
    greenfleet,
    leasePrice,
    gst,
  }: {
    ltc?: string;
    greenfleet: string;
    leasePrice: string;
    gst: string;
  }) {
    if (ltc) {
      await this.milesNewSalesRequestPage.enterAndSelectValueInQuickNavigation(
        ltc,
      );
      await this.goToLeaseServiceInLTC();
    }
    expect(
      await this.milesNewSalesRequestPage.getLeaseServiceLocator(greenfleet),
    ).toBeVisible();
    const actualLeasePrice =
      await this.milesNewSalesRequestPage.getLeasePriceLocator(greenfleet);
    const actualGST =
      await this.milesNewSalesRequestPage.getGSTLocator(greenfleet);
    expect(await actualLeasePrice.innerText()).toEqual(leasePrice);
    expect(await actualGST.innerText()).toEqual(gst);
  }

  // In Lease Service verify greenfleet doesn't exist and other does exist with leaseprice/gst
  async verifyNonGreenfleet({
    ltc,
    greenfleetNotVisible: greenfleet,
    otherLeaseServiceVisible: otherLeaseService,
  }: {
    ltc?: string;
    greenfleetNotVisible: string;
    otherLeaseServiceVisible: string;
  }) {
    if (ltc) {
      await this.milesNewSalesRequestPage.enterAndSelectValueInQuickNavigation(
        ltc,
      );
      await this.goToLeaseServiceInLTC();
    }
    expect(
      await this.milesNewSalesRequestPage.getLeaseServiceLocator(greenfleet),
    ).not.toBeVisible();
    expect(
      await this.milesNewSalesRequestPage.getLeaseServiceLocator(
        otherLeaseService,
      ),
    ).toBeVisible();
    const leasePrice =
      await this.milesNewSalesRequestPage.getLeasePriceLocator(
        otherLeaseService,
      );
    const gst =
      await this.milesNewSalesRequestPage.getGSTLocator(otherLeaseService);
    expect(leasePrice).toBeVisible();
    expect(gst).toBeVisible();
  }

  // Verify - None Carbon Product exists without lease price nor gst
  async verifyNoneCarbonProduct({
    ltc,
    otherLeaseServiceVisible: otherLeaseService,
  }: {
    ltc?: string;
    otherLeaseServiceVisible: string;
  }) {
    if (ltc) {
      await this.milesContractPage.enterAndSelectValueInQuickNavigation(ltc);
    }
    await this.milesContractPage.btnRefresh.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.VERSIONS, "LTC");
    await this.milesContractPage.closeBtnMsgCollapser(200);
    await this.milesContractPage.changeReasonInNewVersion.click();
    await this.goToLeaseServiceInLTC();
    await (
      await this.milesNewSalesRequestPage.getLeaseServiceLocator(
        otherLeaseService,
      )
    ).click();
    expect(
      await this.milesNewSalesRequestPage.getLeaseServiceLocator(
        otherLeaseService,
      ),
    ).toBeVisible();
    const leasePrice =
      await this.milesNewSalesRequestPage.getLeasePriceLocator(
        otherLeaseService,
      );
    expect(await leasePrice.innerText()).not.toContain("$");
  }

  // Verify the TPSC Cost Price. Can be called when already in Lease Service with no LTC given
  // IF LTC given, then it will navigate to Lease Service
  async verifyGreenfleetTPSCCostPrice(
    greenfleetService: string,
    expectedCostPrice: string,
    ltc?: string,
  ) {
    if (ltc) {
      await this.milesNewSalesRequestPage.enterAndSelectValueInQuickNavigation(
        ltc,
      );
      await this.goToLeaseServiceInLTC();
    }
    await this.milesNewSalesRequestPage.selectFundingArrangementOption(
      greenfleetService,
    );
    await this.milesContractPage.clickHorizontalTab(
      CONTRACT_LABELS.ADDITIONAL_DETAILS,
    );
    const actualCostPrice = await this.milesContractPage.retrieveValueByLabel(
      LEASE_SERVICE_LABELS.TPSC_COST_PRICE,
    );
    expect(actualCostPrice).toEqual(expectedCostPrice);
  }

  async goToLeaseServiceInLTC() {
    await this.milesNewSalesRequestPage.clickMenuItem(
      CONTRACT_LABELS.LEASE_SERVICE,
      "LTC",
    );
  }

  async verifyCalculationDateOlderThanOrEqualTo(dateInThePast: string) {
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.VERSIONS);
    const calcValue = await this.milesContractPage.getValueInTableCell(
      "Versions",
      0,
      0,
      8,
    );
    console.log(`calc Date: ${calcValue} pastDate ${dateInThePast}`);
    expect(
      moment(calcValue, "DD/MM/YYYY").isSameOrBefore(
        moment(dateInThePast, "DD/MM/YYYY"),
      ),
    ).toEqual(true);
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.GENERAL);
  }

  async copyContract() {
    await this.milesContractPage.clickMenuItem("Versions");
    const link = await this.milesContractPage.getTableCellLocator(
      "Versions",
      -1,
      -1,
      7,
    );
    await link.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    await this.milesNewSalesRequestPage.btnCopy.waitFor();
    await this.milesNewSalesRequestPage.btnCopy.click();
    await this.milesNewSalesRequestPage.newRequest.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes(30);
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(5000);
    return await this.milesNewSalesRequestPage.retrieveValueByLabel(
      NEW_QUOTE_REQ_LABELS.QUOTE_NUMBER,
    );
  }

  async verifyContractCategory(category: string, quoteNum: string) {
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.LEASE_SERVICE,
      quoteNum,
    );
    await this.milesNewSalesRequestPage.otherFields.click();
    expect(
      await this.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_REQ_LABELS.NOVATED_CONTRACT_CATEGORY,
      ),
    ).toBe(category);
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.SUMMARY,
      quoteNum,
    );
  }
}
