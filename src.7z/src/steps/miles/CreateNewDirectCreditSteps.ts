import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesPurchaseInvoicePage } from "../../pages/miles/MilesPurchaseInvoicePage";
import { DIRECT_CREDIT_LABELS } from "../../../enums/milesapp";
import { MilesDirectCreditPage } from "pages/miles/MilesDirectCreditPage";

export class CreateNewDirectCredit {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesPurchaseInvoicePage: MilesPurchaseInvoicePage;
  milesDirectCreditPage: MilesDirectCreditPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesPurchaseInvoicePage = new MilesPurchaseInvoicePage(page);
    this.milesDirectCreditPage = new MilesDirectCreditPage(page);
  }

  async goToDirectCredit() {
    await this.milesHomePage.clickBottomTab("Home");
    await this.milesHomePage.clickHorizontalPortalNav("Accounts Payable");
    await this.milesHomePage.clickHorizontalPortalNav("Direct Credit");
    await this.milesHomePage.clickHorizontalPortalNav("Direct Credit");
  }

  async searchAndAssignOutstandingInvoice({
    purchaseInvoiceNumber: purchaseInvoiceNumber,
    businessPartner,
    amount,
  }: {
    purchaseInvoiceNumber: string;
    businessPartner: string;
    amount: string;
  }) {
    await this.milesPurchaseInvoicePage.btnNew.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(60);
    await this.milesDirectCreditPage.btnAdd.waitFor();
    await this.milesDirectCreditPage.btnAdd.click({ force: true });
    if (
      !(await this.milesDirectCreditPage.btnAssignPurchaseInvoice.isVisible())
    ) {
      await this.milesDirectCreditPage.btnAdd.click({ force: true });
    }
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesDirectCreditPage.btnAssignPurchaseInvoice.click();
    await this.milesDirectCreditPage.selectionBox.click();
    await this.milesDirectCreditPage.selectionDropdownIcon.click();
    await this.milesDirectCreditPage.selectValueFromDropdown("New selection");
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesDirectCreditPage.enterValueByLabel(
      DIRECT_CREDIT_LABELS.DOCUMENT_NUMBER,
      purchaseInvoiceNumber,
      1,
    );
    await this.milesDirectCreditPage.btnSearch.click();
    await this.milesDirectCreditPage.waitForTableDataToLoad("Allocations");
    await this.milesDirectCreditPage.btnAssign.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    expect(
      await this.milesDirectCreditPage.getValueInTableCell(
        "Payments",
        -1,
        0,
        1,
      ),
    ).toBe(businessPartner.trim());
    const cell = (
      await this.milesDirectCreditPage.getTableCellLocator("Payments", -1, 0, 2)
    ).locator("input");
    expect(await cell.inputValue()).toBe("-" + amount);
  }

  async enterBankAccountDetails(
    businessPartnerAccount: string,
    SGFleetAccount: string,
  ) {
    const supplierCell = await this.milesDirectCreditPage.getTableCellLocator(
      "Payments",
      -1,
      0,
      7,
    );
    await supplierCell.click();
    await supplierCell.type(businessPartnerAccount);
    await this.milesDirectCreditPage.enterValueByLabel(
      DIRECT_CREDIT_LABELS.BANK_ACCOUNT,
      SGFleetAccount,
      1,
    );
    await this.milesDirectCreditPage.clickField(DIRECT_CREDIT_LABELS.COMMENTS);
    await this.milesDirectCreditPage.btnSave.click();
    await this.milesDirectCreditPage.waitUntilLoadingFinishes();
  }
  async postDirectCredit() {
    await this.milesDirectCreditPage.btnAllocate.click();
    await this.milesDirectCreditPage.waitUntilLoadingFinishes();
    await this.milesDirectCreditPage.btnPost.click();
    await this.milesDirectCreditPage.waitUntilLoadingFinishes(50);
    await this.milesDirectCreditPage.clickMenuItem("General");
    await this.milesDirectCreditPage.waitUntilLoadingFinishes();
    if (
      (await this.milesDirectCreditPage.retrieveValueByLabel(
        DIRECT_CREDIT_LABELS.STATUS,
      )) != "Posted"
    ) {
      await this.milesDirectCreditPage.btnPost.click();
      await this.milesDirectCreditPage.waitUntilLoadingFinishes(50);
    }
    expect(["Posted", "Allocated"]).toContain(
      await this.milesDirectCreditPage.retrieveValueByLabel(
        DIRECT_CREDIT_LABELS.STATUS,
      ),
    );
  }
}
