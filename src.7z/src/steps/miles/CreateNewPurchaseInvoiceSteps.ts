import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesVehicleOrderPage } from "../../pages/miles/MilesVehicleOrderPage";
import { MilesPurchaseInvoicePage } from "../../pages/miles/MilesPurchaseInvoicePage";
import {
  CONTRACT_LABELS,
  PURCHASE_INVOICE_LABELS,
} from "../../../enums/milesapp";
import { faker } from "@faker-js/faker";
import { MilesSearchPage } from "pages/miles/MilesSearchPage";
import moment from "moment";

export class CreateNewPurchaseInvoice {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesVehicleOrderPage: MilesVehicleOrderPage;
  milesPurchaseInvoicePage: MilesPurchaseInvoicePage;
  milesSearchPage: MilesSearchPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesVehicleOrderPage = new MilesVehicleOrderPage(page);
    this.milesPurchaseInvoicePage = new MilesPurchaseInvoicePage(page);
    this.milesSearchPage = new MilesSearchPage(page);
  }

  async createNewPurchaseInvoice({ ltc }: { ltc: string }) {
    await this.searchValue(ltc);
    await this.goToVehicleOrdersFromContract();
    await this.goToNewPurchaseInvoiceFromVehicleOrder();
    await this.postPurchaseInvoice();
  }

  async createNewPurchaseInvoiceAutonomy({ ltc }: { ltc: string }) {
    await this.searchValue(ltc);
    await this.goToVehicleOrdersFromContract();
    await this.goToNewPurchaseInvoiceFromVehicleOrder();
    await this.postPurchaseInvoiceForExistingVO();
  }

  async createNewPurchaseInvoiceFromExistingVO() {
    await this.goToNewPurchaseInvoiceFromVehicleOrder();
    await this.milesPurchaseInvoicePage.btnValidate.waitFor();
    await this.enterInvoiceNumber();
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
    await this.milesHomePage.waitUntilLoadingFinishes();
  }

  async goToVehicleOrdersFromContract() {
    await this.milesContractPage.btnVehicle.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  async goToNewPurchaseInvoiceFromVehicleOrder() {
    await this.milesVehicleOrderPage.btnNewInvoice.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
    await this.milesVehicleOrderPage.closeBtnMsgCollapser();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
  }

  async postPurchaseInvoice() {
    await this.enterInvoiceNumber();
    await this.enterPaymentMethodIfRequired();
    await this.milesPurchaseInvoicePage.btnValidate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.dismissSystemDialog();
    await this.milesPurchaseInvoicePage.btnAllocate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.btnApprove.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(180);
    await this.milesPurchaseInvoicePage.btnPost.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(50);
    await this.milesPurchaseInvoicePage.clickMenuItem("General");
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    expect(["Posted", "Finalized"]).toContain(
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.STATUS,
      ),
    );
    return await this.milesPurchaseInvoicePage.retrieveValueByLabel(
      PURCHASE_INVOICE_LABELS.DOCUMENT_NUMBER,
    );
  }

  async postPurchaseInvoiceForFuelRecharge({
    fuelType,
    quantity,
    unitPrice,
    costPrice,
    rechargeAmount,
  }: {
    fuelType: string;
    quantity: string;
    unitPrice: string;
    costPrice: string;
    rechargeAmount: string;
  }) {
    await this.enterInvoiceNumber();
    await this.enterPaymentMethodIfRequired();
    await this.milesPurchaseInvoicePage.btnValidate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.dismissSystemDialog();
    await this.milesPurchaseInvoicePage.btnAllocate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(120);
    const errormsg = await this.milesPurchaseInvoicePage.getSystemErrorMsg();
    if (
      errormsg &&
      errormsg.includes(
        "The sum of the invoiced item amounts does not equal the amount specified on the invoice",
      )
    ) {
      await this.handleMissingInvoiceItemAmountsError({
        fuelType,
        quantity,
        unitPrice,
        costPrice,
        rechargeAmount,
      });
    }
    await this.milesPurchaseInvoicePage.btnApprove.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(180);
    await this.milesPurchaseInvoicePage.btnPost.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(50);
    await this.milesPurchaseInvoicePage.clickMenuItem(
      PURCHASE_INVOICE_LABELS.GENERAL,
    );
    expect(["Posted", "Finalized"]).toContain(
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.STATUS,
      ),
    );
    return await this.milesPurchaseInvoicePage.retrieveValueByLabel(
      PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
    );
  }

  async handleMissingInvoiceItemAmountsError({
    fuelType,
    quantity,
    unitPrice,
    costPrice,
    rechargeAmount,
  }: {
    fuelType: string;
    quantity: string;
    unitPrice: string;
    costPrice: string;
    rechargeAmount: string;
  }) {
    await this.milesPurchaseInvoicePage.btnClose.click();
    await this.addFuelInvoiceLine({
      fuelType,
      quantity,
      unitPrice,
      costPrice,
      rechargeAmount,
    });
    await this.milesPurchaseInvoicePage.clickMenuItem("General");
    await this.milesPurchaseInvoicePage.btnAllocate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(120);
  }

  async enterInvoiceNumber() {
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.page.waitForTimeout(5000);
    await this.milesPurchaseInvoicePage.btnValidate.waitFor();
    await this.milesPurchaseInvoicePage.clickField(
      PURCHASE_INVOICE_LABELS.DOCUMENT_NUMBER,
    );
    let invoiceNum = await this.milesPurchaseInvoicePage.retrieveValueByLabel(
      PURCHASE_INVOICE_LABELS.DOCUMENT_NUMBER,
    );
    if (invoiceNum == "") {
      invoiceNum = faker.number.bigInt().toString();
    }
    if (
      (await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
      )) == ""
    ) {
      await this.milesPurchaseInvoicePage.enterValueByLabel2(
        PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
        invoiceNum,
      );
    }
  }

  async enterPaymentMethodIfRequired(paymentMethod = "Direct Credit") {
    const actualPaymentMethod =
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.PAYMENT_METHOD,
      );
    if (!actualPaymentMethod) {
      await this.milesPurchaseInvoicePage.enterValueByLabel(
        PURCHASE_INVOICE_LABELS.PAYMENT_METHOD,
        paymentMethod,
      );
    }
  }

  async enterSupplierIfNeeded() {
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.page.waitForTimeout(5000);
    if (
      (await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.SUPPLIER,
      )) == ""
    ) {
      const supplier = await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.REMIT_TO,
      );

      await this.milesPurchaseInvoicePage.enterValueByLabel(
        PURCHASE_INVOICE_LABELS.SUPPLIER,
        supplier,
      );
    }
  }

  async enterSuplierUsingSearchBtn(tradingName: string) {
    await this.milesPurchaseInvoicePage.clickBtnInFocusedTextBox(
      PURCHASE_INVOICE_LABELS.SUPPLIER,
    );
    await this.milesPurchaseInvoicePage.enterDetailsByLabel(
      PURCHASE_INVOICE_LABELS.TRADING_NAME,
      tradingName,
    );
    await this.milesPurchaseInvoicePage.btnSearch.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.selectFirstRowFromTable(1);
  }

  async postPurchaseInvoiceForExistingVO(priceAdjustment?: number) {
    await this.enterInvoiceNumber();
    await this.enterSupplierIfNeeded();
    await this.enterPaymentMethodIfRequired();
    await this.milesPurchaseInvoicePage.btnValidate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.dismissSystemDialog();
    await this.milesPurchaseInvoicePage.btnAllocate.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(50);
    await this.milesPurchaseInvoicePage.btnApprove.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(180);
    await this.milesPurchaseInvoicePage.btnPost.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes(50);
    // IF price adjustment exceeds adjustment threshold, AQ will be created
    // The Adjustment Threshold varies depending on Environment
    const adjustmentThreshold = 299;
    if (priceAdjustment && priceAdjustment >= adjustmentThreshold) {
      await expect(
        this.milesPurchaseInvoicePage.warningDialogText,
      ).toBeVisible();
      const actualWarning =
        await this.milesPurchaseInvoicePage.warningDialogText.getAttribute(
          "aria-label",
        );
      const expectedWarning =
        "The allowed vehicle invoice diff or rental adjustment threshold has been exceeded";
      expect(actualWarning).toContain(expectedWarning);
      await this.milesPurchaseInvoicePage.btnYes.click();
      await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    }
    await this.milesPurchaseInvoicePage.clickMenuItem(
      PURCHASE_INVOICE_LABELS.GENERAL,
      "PI",
    );
    expect(["Posted", "Finalized"]).toContain(
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.STATUS,
      ),
    );
  }

  async createPIWithVehicleAdjustment({
    ltc,
    priceAdjustment,
  }: {
    ltc: string;
    priceAdjustment: number;
  }) {
    await this.searchValue(ltc);
    const vehicleDesc = await this.milesContractPage.retrieveValueByLabel(
      CONTRACT_LABELS.DESCRIPTION,
    );
    await this.goToVehicleOrdersFromContract();
    await this.goToNewPurchaseInvoiceFromVehicleOrder();
    await this.adjustDeliveryCostPrice(vehicleDesc, priceAdjustment);
    await this.updateGeneralVATValues(priceAdjustment);
    await this.postPurchaseInvoiceForExistingVO(priceAdjustment);
  }

  async adjustDeliveryCostPrice(vehicleDesc: string, priceAdjustment: number) {
    await this.milesPurchaseInvoicePage.clickMenuItem(
      PURCHASE_INVOICE_LABELS.CONTENTS,
      "PI",
    );
    await this.milesPurchaseInvoicePage.doubleClickVehicleInInvoiceLines(
      vehicleDesc,
    );
    await this.milesPurchaseInvoicePage.tabDeliveryCost.click();
    if (await this.milesPurchaseInvoicePage.linkRUCInitialCost.isVisible()) {
      await this.milesPurchaseInvoicePage.updateDeliveryCostPrice(
        PURCHASE_INVOICE_LABELS.RUC_INITIAL_COST,
        priceAdjustment,
      );
    } else {
      await this.milesPurchaseInvoicePage.updateDeliveryCostPrice(
        PURCHASE_INVOICE_LABELS.INITIAL_REGISTRATION,
        priceAdjustment,
      );
    }
    await this.milesPurchaseInvoicePage.clickOut(
      PURCHASE_INVOICE_LABELS.VAT_AMOUNT,
    );
  }

  async updateGeneralVATValues(priceAdjustment: number) {
    await this.milesPurchaseInvoicePage.clickMenuItem(
      PURCHASE_INVOICE_LABELS.GENERAL,
    );
    const amountVATExclText =
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.AMOUNT_VAT_EXCL,
      );
    const amountVATInclText =
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.AMOUNT_VAT_INCL,
      );
    let amountVATExcl = Number(
      amountVATExclText.replace("$", "").replace(",", ""),
    );
    let amountVATIncl = Number(
      amountVATInclText.replace("$", "").replace(",", ""),
    );
    amountVATExcl = amountVATExcl + priceAdjustment;
    amountVATIncl = amountVATIncl + priceAdjustment;
    const vatAmount = (amountVATIncl - amountVATExcl).toFixed(2);
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.AMOUNT_VAT_EXCL,
      amountVATExcl.toString(),
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.AMOUNT_VAT_INCL,
      amountVATIncl.toString(),
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.VAT_AMOUNT,
      vatAmount,
    );
    await this.milesPurchaseInvoicePage.clickOut(
      PURCHASE_INVOICE_LABELS.VAT_NUMBER,
    );
  }

  /**
   * Verify the Invoice Type field in PI > General > Invoice Type
   * @param type the expected value you want to see in Invoice Type field
   */
  async verifyInvoiceType(type: string) {
    const tableName = "Related Objects";
    const tableIndex = -1;
    const rowIndex = 0;
    const columnIndex = 1;
    const invoiceType =
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.INVOICE_TYPE,
      );
    const actual = await this.milesPurchaseInvoicePage.getValueInTableCell(
      tableName,
      tableIndex,
      rowIndex,
      columnIndex,
    );
    expect([invoiceType, actual]).toContain(type);
  }

  async createPIForFuelRecharge({
    tradingName,
    fuelType,
    quantity,
    unitPrice,
    costPrice,
    rechargeAmount,
  }: {
    tradingName: string;
    fuelType: string;
    quantity: string;
    unitPrice: string;
    costPrice: string;
    rechargeAmount: string;
  }) {
    await this.enterSuplierUsingSearchBtn(tradingName);
    await this.milesPurchaseInvoicePage.enterValueByLabel(
      PURCHASE_INVOICE_LABELS.REMIT_TO,
      tradingName,
    );
    // Need to wait for Remit To to update correctly
    await this.milesPurchaseInvoicePage.clickOut(
      PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
    );
    await this.page.waitForTimeout(3000);
    let errorMsg1 = await this.milesPurchaseInvoicePage.getSystemErrorMsg();
    if (
      errorMsg1 &&
      errorMsg1.includes("The emitter (business partner with ID")
    ) {
      await this.milesPurchaseInvoicePage.btnClose.click();
    }
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
      faker.number.bigInt().toString(),
    );
    await this.enterPaymentMethodIfRequired();
    await this.milesPurchaseInvoicePage.enterValueByLabel(
      PURCHASE_INVOICE_LABELS.DUE_DATE,
      moment().add(15, "d").format("DD/MM/YYYY"),
    );
    errorMsg1 = await this.milesPurchaseInvoicePage.getSystemErrorMsg();
    if (
      errorMsg1 &&
      errorMsg1.includes("The emitter (business partner with ID")
    ) {
      await this.milesPurchaseInvoicePage.btnClose.click();
    }
    await this.milesPurchaseInvoicePage.clickOut(
      PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
    );
    await this.milesPurchaseInvoicePage.btnSave.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    const errorMsg2 =
      await this.milesPurchaseInvoicePage.getNthCollapserError();
    if (
      errorMsg2 &&
      errorMsg2.includes("Invoice Number: Required value is missing")
    ) {
      await this.milesPurchaseInvoicePage.closeBtnMsgCollapser();
      await this.milesPurchaseInvoicePage.enterValueByLabel2(
        PURCHASE_INVOICE_LABELS.INVOICE_NUMBER,
        faker.number.bigInt().toString(),
      );
      await this.milesPurchaseInvoicePage.btnSave.click();
      await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    }
    await this.addFuelInvoiceLine({
      fuelType,
      quantity,
      unitPrice,
      costPrice,
      rechargeAmount,
    });
  }

  async addFuelInvoiceLine({
    fuelType,
    quantity,
    unitPrice,
    costPrice,
    rechargeAmount,
  }: {
    fuelType: string;
    quantity: string;
    unitPrice: string;
    costPrice: string;
    rechargeAmount: string;
  }) {
    /*
    Sometimes the Supplier or Remit To, "disappears" during Save. 
    Then it re-appears but didn't Save
    */

    const contentsMenu =
      await this.milesPurchaseInvoicePage.getMenuItemLocator("Contents");
    const menuState = await contentsMenu.getAttribute("class");
    if (menuState && menuState.includes("Disabled")) {
      await this.milesPurchaseInvoicePage.btnSave.click();
      await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    }
    await this.milesPurchaseInvoicePage.clickMenuItem("Contents");
    await this.milesPurchaseInvoicePage.btnAdd.waitFor();
    await this.milesPurchaseInvoicePage.btnAdd.click({ force: true });
    await this.page.waitForTimeout(2000);
    await this.milesPurchaseInvoicePage.clickField(
      PURCHASE_INVOICE_LABELS.FUEL,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel(
      PURCHASE_INVOICE_LABELS.DESCRIPTION,
      faker.string.alpha({
        length: 10,
      }),
      1,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.FUEL_TYPE,
      fuelType,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.QUANTITY,
      quantity,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.UNIT_PRICE,
      unitPrice,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.COST_PRICE,
      costPrice,
    );
    await this.milesPurchaseInvoicePage.btnOK.click();
    const contractField =
      await this.milesPurchaseInvoicePage.getTableCellLocator(
        "Invoice Lines",
        1,
        0,
        10,
      );
    await contractField.click();
    await this.page.waitForTimeout(1000);
    await this.page.keyboard.press("ArrowDown");
    await this.page.waitForTimeout(1000);
    await this.page.keyboard.press("Enter");
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.milesPurchaseInvoicePage.clickHorizontalTab("Recharge");
    await this.milesPurchaseInvoicePage.customerApproved.click();
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.RECHARGE_AMOUNT,
      rechargeAmount,
    );
    await this.milesPurchaseInvoicePage.clickOut(
      PURCHASE_INVOICE_LABELS.RECHARGE_AMOUNT,
    );
    await this.milesPurchaseInvoicePage.btnSave.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
  }

  async enterVATAmounts({
    amountVATExcl,
    vatAmount,
    amountVATIncl,
  }: {
    amountVATExcl: string;
    vatAmount: string;
    amountVATIncl: string;
  }) {
    await this.milesPurchaseInvoicePage.clickMenuItem("General");
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.AMOUNT_VAT_EXCL,
      amountVATExcl,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.VAT_AMOUNT,
      vatAmount,
    );
    await this.milesPurchaseInvoicePage.enterValueByLabel2(
      PURCHASE_INVOICE_LABELS.AMOUNT_VAT_INCL,
      amountVATIncl,
    );

    await this.milesPurchaseInvoicePage.btnSave.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
  }

  async goToPurchaseInvoices() {
    await this.milesHomePage.clickHorizontalPortalNav("Accounting");
    await this.milesHomePage.clickHorizontalPortalNav("Accounts Payable");
    await this.milesHomePage.clickHorizontalPortalNav("Purchase Invoices");
    await this.milesHomePage.waitUntilLoadingFinishes();
  }

  async createNewPurchaseInvoiceFromSearch(option: string) {
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesPurchaseInvoicePage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesPurchaseInvoicePage.btnNew.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
  }

  async verifyLabelInAllocationDetails() {
    const tableName = "Allocation Details";
    const tableIndex = -1;
    const labelColumn = 9;
    await this.milesPurchaseInvoicePage.clickMenuItem("Allocation Details");
    await this.milesPurchaseInvoicePage.waitForTableDataToLoad(tableName);
    const rows =
      await this.milesPurchaseInvoicePage.getNumberOfTableRows(tableName);
    let valueFound = false;
    for (let row = 0; row < rows && !valueFound; row++) {
      const labelValue =
        await this.milesPurchaseInvoicePage.getValueInTableCell(
          tableName,
          tableIndex,
          row,
          labelColumn,
        );
      if (labelValue) {
        valueFound = true;
      }
    }
    expect(valueFound, "Label column should have a value").toBe(true);
  }
}
