import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesNewSalesRequestPage } from "../../pages/miles/MilesNewSalesRequestPage";
import { MilesSalesPage } from "../../pages/miles/MilesSalesPage";
import { MilesSearchSalesRequestsPage } from "../../pages/miles/MilesSearchSalesRequestsPage";
import {
  CUSTOMER_OR_COST_CENTRE_LABELS,
  NEW_QUOTE_REQ_LABELS,
  NEW_QUOTE_VEHICLE_LABELS,
  VEHICLE_DELIVERY_LABELS,
  VEHICLE_TYPE_LABELS,
  EQUIPMENT_LABELS,
  LEASE_SERVICE_LABELS,
} from "../../../enums/milesapp";
import { faker } from "@faker-js/faker";
import { MilesContactPage } from "pages/miles/MilesContactPage ";
import { CreateNewContact } from "./CreateNewContactSteps";

export class CreateNewQuote {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesSalesPage: MilesSalesPage;
  milesSearchSalesRequestPage: MilesSearchSalesRequestsPage;
  milesNewSalesRequestPage: MilesNewSalesRequestPage;
  newContact: MilesContactPage;
  newContactSteps: CreateNewContact;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesSalesPage = new MilesSalesPage(page);
    this.milesSearchSalesRequestPage = new MilesSearchSalesRequestsPage(page);
    this.milesNewSalesRequestPage = new MilesNewSalesRequestPage(page);
    this.newContact = new MilesContactPage(page);
    this.newContactSteps = new CreateNewContact(page);
  }

  async createNewMilesQuote({
    tradingname,
    template,
    vehicleDescp,
    model = "",
    duration,
    distance = faker.number.int({ min: 100000, max: 150000 }) + "",
    postCode,
    state,
    grossAnnualSalary = faker.number.int({ min: 100000, max: 200000 }) + "",
    leaseG,
    faultClaims,
    convictedDUI,
    negligentDriving,
    location,
    contactName = faker.person.fullName(),
    emailAddr,
    contactNum,
  }: {
    tradingname: string;
    template: string;
    vehicleDescp: string;
    model?: string;
    duration: string;
    distance?: string;
    postCode: string;
    state: string;
    grossAnnualSalary?: string;
    leaseG: string;
    faultClaims: string;
    convictedDUI: string;
    negligentDriving: string;
    location: string;
    contactName?: string;
    emailAddr: string;
    contactNum: string;
  }) {
    await this.createNewSalesRequest();
    await this.selectCustomerOrCostcentreForNewQuote(tradingname);
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    await this.milesNewSalesRequestPage.addIcon.click();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(6000);
    await this.selectQuotationTemplateForNewQuote(template);
    await this.selectDriverForNewQuote();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(3000);
    await this.selectVehicleTypeForNewQuote(vehicleDescp, model);
    await this.enterAndSaveVehicleDetails({
      duration,
      distance,
      postCode,
      state,
      grossAnnualSalary,
      leaseG,
      faultClaims,
      convictedDUI,
      negligentDriving,
    });
    await this.calculateQuote();
    await this.validateQuote();
    await this.vehicleDelivery({
      location,
      contactName,
      emailAddr,
      contactNum,
    });
    await this.approveQuote();
    await this.verifyQuoteStatus();
    return await this.retrieveQuoteNumber();
  }

  async createNewMilesQuoteFromContact({
    template,
    vehicleDescp,
    model = "",
    duration,
    distance = faker.number.int({ min: 100000, max: 150000 }) + "",
    postCode,
    state,
    grossAnnualSalary = faker.number.int({ min: 100000, max: 200000 }) + "",
    leaseG,
    faultClaims,
    convictedDUI,
    negligentDriving,
    location,
    contactName = faker.person.fullName(),
    emailAddr,
    contactNum,
  }: {
    template: string;
    vehicleDescp: string;
    model?: string;
    duration: string;
    distance?: string;
    postCode: string;
    state: string;
    grossAnnualSalary?: string;
    leaseG: string;
    faultClaims: string;
    convictedDUI: string;
    negligentDriving: string;
    location: string;
    contactName?: string;
    emailAddr: string;
    contactNum: string;
  }) {
    await this.selectQuotationTemplateForNewQuote(template);
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(3000);
    await this.selectVehicleTypeForNewQuote(vehicleDescp, model);
    await this.enterAndSaveVehicleDetails({
      duration,
      distance,
      postCode,
      state,
      grossAnnualSalary,
      leaseG,
      faultClaims,
      convictedDUI,
      negligentDriving,
    });
    await this.calculateQuote();
    await this.validateQuote();
    await this.vehicleDelivery({
      location,
      contactName,
      emailAddr,
      contactNum,
    });
    await this.approveQuote();
    await this.verifyQuoteStatus();
    return await this.retrieveQuoteNumber();
  }

  // No Gross Annual Salary
  async createFirstPartOfQuote({
    tradingname,
    bpID,
    template,
    vehicleDescp,
    model = "",
    purchaseType = "",
    duration,
    distance = faker.number.int({ min: 100000, max: 150000 }) + "",
    postCode,
    state,
    hasGrossAnnualSalary,
    hasDriver,
    leaseG,
    faultClaims,
    convictedDUI,
    negligentDriving,
  }: {
    tradingname: string;
    bpID?: string;
    template: string;
    vehicleDescp: string;
    model?: string;
    purchaseType?: string;
    duration: string;
    distance?: string;
    postCode: string;
    state: string;
    hasGrossAnnualSalary?: boolean;
    hasDriver?: boolean;
    leaseG?: string;
    faultClaims?: string;
    convictedDUI?: string;
    negligentDriving?: string;
  }) {
    await this.createNewSalesRequest();
    await this.selectCustomerOrCostcentreForNewQuote(tradingname, bpID);
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    await this.milesNewSalesRequestPage.addIcon.click();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(6000);
    await this.page.waitForTimeout(1000);
    await this.selectQuotationTemplateForNewQuote(template);
    if (hasDriver) {
      await this.selectDriverForNewQuote();
    }
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser(3000);
    await this.selectVehicleTypeForNewQuote(vehicleDescp, model);
    let grossAnnualSalary;
    if (hasGrossAnnualSalary) {
      grossAnnualSalary = faker.number.int({ min: 100000, max: 200000 }) + "";
    }
    await this.enterAndSaveVehicleDetails({
      duration,
      distance,
      postCode,
      state,
      grossAnnualSalary,
      leaseG,
      faultClaims,
      convictedDUI,
      negligentDriving,
      purchaseType,
    });
    return await this.retrieveQuoteNumber();
  }

  async calculateValidateApproveQuote({
    quoteNum,
    location,
    contactName = faker.person.fullName(),
    emailAddr,
    contactNum,
  }: {
    quoteNum?: string;
    location: string;
    contactName?: string;
    emailAddr: string;
    contactNum: string;
  }) {
    if (quoteNum) {
      await this.milesHomePage.enterAndSelectValueInQuickNavigation(quoteNum);
    }
    await this.calculateQuote();
    await this.validateQuote();
    await this.vehicleDelivery({
      location,
      contactName,
      emailAddr,
      contactNum,
    });
    await this.approveQuote();
    await this.verifyQuoteStatus();
  }

  async createNewSalesRequest() {
    await this.milesHomePage.salesTab.click();
    await this.milesSalesPage.salesRequests.click();
    await this.milesSearchSalesRequestPage.newIcon.click();
  }

  async selectCustomerOrCostcentreForNewQuote(
    tradingname: string,
    bpID?: string,
  ) {
    await Promise.all([
      this.milesNewSalesRequestPage.searchCustomerOrCostCentre.click(),
    ]);
    await this.milesNewSalesRequestPage.enterDetailsByLabel(
      CUSTOMER_OR_COST_CENTRE_LABELS.TRADING_NAME,
      tradingname,
    );
    if (bpID) {
      await this.milesNewSalesRequestPage.enterDetailsByLabel(
        CUSTOMER_OR_COST_CENTRE_LABELS.BUSINESS_PARTNER_ID,
        bpID,
      );
    }
    await Promise.all([
      this.milesNewSalesRequestPage.btnSearch.click(),
      this.milesNewSalesRequestPage.waitUntilLoadingFinishes(),
    ]);
    await this.milesNewSalesRequestPage.selectCustomerOrCostCentre.dblclick();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    const selectedValue =
      await this.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_REQ_LABELS.CUSTOMER_OR_COST_CENTRE,
      );
    expect(selectedValue).toContain(tradingname);
  }

  async selectQuotationTemplateForNewQuote(template: string) {
    await this.milesNewSalesRequestPage.enterValueByLabel(
      NEW_QUOTE_REQ_LABELS.QUOTATION_TEMPLATE,
      template,
    );
    await this.milesNewSalesRequestPage.selectQuotationTemplateFromDropdown(
      template,
    );
    // Need to click out when Quotation Template only has 1 option
    await this.milesNewSalesRequestPage.clickOut(
      NEW_QUOTE_REQ_LABELS.QUOTE_REASON,
    );
  }

  async selectDriverForNewQuote() {
    await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
      NEW_QUOTE_REQ_LABELS.REQUEST_DRIVER,
    );
    await this.milesNewSalesRequestPage.btnSearch.waitFor();
    await this.milesNewSalesRequestPage.dismissSystemDialog(
      "A database error has appeared due to an incorrect SQL statement",
    );
    await this.milesNewSalesRequestPage.btnSearch.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.selectFirstRowFromTable();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    await this.milesNewSalesRequestPage.retrieveValueByLabel(
      NEW_QUOTE_REQ_LABELS.REQUEST_DRIVER,
    );
  }

  async selectExistingDriverForNewQuote(driver: string) {
    await this.milesNewSalesRequestPage.enterDetailsByLabel(
      NEW_QUOTE_REQ_LABELS.REQUEST_DRIVER,
      driver,
    );
  }

  async selectVehicleTypeForNewQuote(vehicleDescp: string, model?: string) {
    await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
      NEW_QUOTE_VEHICLE_LABELS.TYPE,
      2,
    );
    await this.milesNewSalesRequestPage.enterDetailsByLabel(
      VEHICLE_TYPE_LABELS.VEHICLE_DESCRIPTION,
      vehicleDescp,
    );

    if (model) {
      await this.milesNewSalesRequestPage.enterDetailsByLabel(
        VEHICLE_TYPE_LABELS.MODEL_NAME,
        model,
      );
    }

    await this.milesNewSalesRequestPage.btnSearch.click();
    await this.milesNewSalesRequestPage.selectFirstRowFromTable();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
  }

  async enterAndSaveVehicleDetails({
    duration,
    distance,
    postCode,
    state,
    grossAnnualSalary,
    leaseG,
    faultClaims,
    convictedDUI,
    negligentDriving,
    purchaseType = "",
  }: {
    duration: string;
    distance: string;
    postCode: string;
    state: string;
    grossAnnualSalary?: string;
    leaseG?: string;
    faultClaims?: string;
    convictedDUI?: string;
    negligentDriving?: string;
    purchaseType?: string;
  }) {
    (
      await this.milesNewSalesRequestPage.getInputLocatorByLabel(
        NEW_QUOTE_VEHICLE_LABELS.DURATION,
      )
    ).waitFor();
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DURATION,
      duration,
      500,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DISTANCE,
      distance,
      200,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      NEW_QUOTE_VEHICLE_LABELS.REG_POST_CODE,
      postCode,
      2,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      NEW_QUOTE_VEHICLE_LABELS.STATE,
      state,
    );
    if (grossAnnualSalary) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        NEW_QUOTE_VEHICLE_LABELS.GROSS_ANNUAL_SALARY,
        grossAnnualSalary,
      );
    }
    if (leaseG) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.LEASEGUARD_OPT_OUT,
        leaseG,
        1,
      );
    }
    if (faultClaims) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.AT_FAULT_CLAIMS,
        faultClaims,
      );
    }
    if (convictedDUI) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.CONVICTED_DUI,
        convictedDUI,
        1,
      );
    }
    if (negligentDriving) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.NEGLIGENT_DRIVING,
        negligentDriving,
      );
    }

    if (purchaseType) {
      await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
        NEW_QUOTE_VEHICLE_LABELS.PURCHASE_TYPE,
      );
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.PURCHASE_TYPE,
        purchaseType,
        2,
      );
    }

    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async enterAndSaveVehicleDetailsForThirdPartyReno({
    duration,
    distance,
    postCode,
    state,
    grossAnnualSalary,
    leaseG,
    faultClaims,
    convictedDUI,
    negligentDriving,
    purchaseType = "",
  }: {
    duration: string;
    distance: string;
    postCode: string;
    state: string;
    grossAnnualSalary?: string;
    leaseG?: string;
    faultClaims?: string;
    convictedDUI?: string;
    negligentDriving?: string;
    purchaseType?: string;
  }) {
    await this.milesNewSalesRequestPage.clickMenuItem("Summary");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DURATION,
      duration,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DISTANCE,
      distance,
      200,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      NEW_QUOTE_VEHICLE_LABELS.REG_POST_CODE,
      postCode,
      1,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      NEW_QUOTE_VEHICLE_LABELS.STATE,
      state,
      2,
    );
    if (grossAnnualSalary) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.GROSS_ANNUAL_SALARY,
        grossAnnualSalary,
        2,
      );
    }
    if (leaseG) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.LEASEGUARD_OPT_OUT_,
        leaseG,
        2,
      );
    }
    if (faultClaims) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.AT_FAULT_CLAIMS,
        faultClaims,
        1,
      );
    }
    if (convictedDUI) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.CONVICTED_DUI,
        convictedDUI,
      );
    }
    if (negligentDriving) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.NEGLIGENT_DRIVING,
        negligentDriving,
        1,
      );
    }

    if (purchaseType) {
      await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
        NEW_QUOTE_VEHICLE_LABELS.PURCHASE_TYPE,
      );
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.PURCHASE_TYPE,
        purchaseType,
        2,
      );
    }

    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async calculateQuote() {
    await this.milesNewSalesRequestPage.btnCalculate.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async validateQuote() {
    await this.milesNewSalesRequestPage.btnValidate.click({
      timeout: 120000,
    });
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes(30);
    await this.handleITCCapExemptionError();
    expect(
      await this.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_REQ_LABELS.STATUS,
      ),
    ).toContain("Validated");
  }

  /**
   * Handles the ITC Cap Exemption error after the Validate button has been clicked on the Quote from the Summary menu.
   */
  async handleITCCapExemptionError() {
    const errorMsg = await this.milesNewSalesRequestPage.getSystemErrorMsg();
    if (
      errorMsg &&
      errorMsg.includes(
        "Message with 'Vehicle - ITC Cap Exemption' message type is required for Quote with 'ITC Cap Exemption'",
      )
    ) {
      await this.milesNewSalesRequestPage.btnClose.click();
      await this.milesNewSalesRequestPage.clickMenuItem(
        NEW_QUOTE_REQ_LABELS.VEHICLE,
      );
      await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
      await this.milesNewSalesRequestPage.clickHorizontalTab(
        NEW_QUOTE_REQ_LABELS.MORE,
      );
      await this.milesNewSalesRequestPage.untickCheckBox("ITC Cap Exemption");
      await this.milesNewSalesRequestPage.btnSave.click();
      await this.milesNewSalesRequestPage.clickMenuItem(
        NEW_QUOTE_REQ_LABELS.SUMMARY,
      );
      await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
      await this.milesNewSalesRequestPage.btnValidate.click({
        timeout: 120000,
      });
      await this.milesNewSalesRequestPage.waitUntilLoadingFinishes(30);
    }
  }

  async vehicleDelivery({
    location,
    contactName = faker.person.fullName(),
    emailAddr,
    contactNum,
    registrationExpiry,
    registrationSuburb,
    firstRegistrationDate,
    currentODO,
    licensePlate,
    buildDate,
    chasisNumber,
    region,
    state,
  }: {
    location: string;
    contactName?: string;
    emailAddr: string;
    contactNum: string;
    registrationExpiry?: string;
    registrationSuburb?: string;
    firstRegistrationDate?: string;
    currentODO?: string;
    licensePlate?: string;
    buildDate?: string;
    chasisNumber?: string;
    region?: string;
    state?: string;
  }) {
    await this.milesNewSalesRequestPage.clickMenuItem("Vehicle");
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes(30);
    await this.milesNewSalesRequestPage.vehicleDeliveryTab.click();
    await this.milesNewSalesRequestPage.vehicleDeliveryLocation.fill(location);
    await this.milesNewSalesRequestPage.enterValueByLabel(
      VEHICLE_DELIVERY_LABELS.DELIVERY_CONTACT,
      contactName,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      VEHICLE_DELIVERY_LABELS.DELIVERY_EMAIL,
      emailAddr,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel(
      VEHICLE_DELIVERY_LABELS.DELIVERY_PHONE,
      contactNum,
      1,
    );
    if (registrationExpiry) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.REGISTRATION_EXPIRY,
        registrationExpiry,
      );
    }
    if (registrationSuburb) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.REGISTRATION_SUBURB,
        registrationSuburb,
      );
    }
    if (firstRegistrationDate) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.FIRST_REGISTRATION_DATE,
        firstRegistrationDate,
      );
    }
    if (currentODO) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.CURRENT_ODO,
        currentODO,
      );
    }
    if (licensePlate) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.LICENSE_PLATE,
        licensePlate,
      );
    }
    if (buildDate) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.BUILDDATE,
        buildDate,
      );
    }
    if (chasisNumber) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.CHASSIS_NUMBER,
        chasisNumber,
      );
    }
    if (region) {
      await this.milesNewSalesRequestPage.enterValueByLabel2(
        VEHICLE_DELIVERY_LABELS.DELIVERY_REGION,
        region,
      );
    }
    if (state) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        VEHICLE_DELIVERY_LABELS.STATE,
        state,
        4,
      );
    }
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async approveQuote() {
    await this.milesNewSalesRequestPage.btnApprove.click();
  }

  async verifyQuoteStatus() {
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.SUMMARY,
    );
    expect(
      await this.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_REQ_LABELS.STATUS,
      ),
    ).toContain("Conditionally Approved");
  }

  async retrieveQuoteNumber() {
    return await this.milesNewSalesRequestPage.quoteNumber.inputValue();
  }

  //In Edit Equipment
  async addFreeformEquipment(type: string) {
    await this.addFreeformItem("Test1", type);
    await this.addFreeformItem("Test2", type);
    await this.addFreeformItem("Test3", type);
    await this.milesNewSalesRequestPage.btnOK.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  //In Edit Equipment
  async addFreeformItem(description: string, type: string) {
    await this.milesNewSalesRequestPage.btnFreeform.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.fieldDescription.fill(description);
    await this.milesNewSalesRequestPage.clickField(EQUIPMENT_LABELS.TYPE, 2);
    await this.milesNewSalesRequestPage.selectValueFromDropdown(type);
    await this.milesNewSalesRequestPage.enterValueByLabel(
      EQUIPMENT_LABELS.CATALOG_PRICE,
      faker.number.int({ min: 50, max: 500 }).toString(),
    );
    await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
      EQUIPMENT_LABELS.DEALER,
      2,
    );
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.btnSearch.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.selectFirstRowFromTable();
    await this.milesNewSalesRequestPage.btnOKFreeform.click();
  }

  async addManualOverride(rvOverrideStatus: string) {
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.LEASE_SERVICE,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      LEASE_SERVICE_LABELS.MANUAL_RV_OVERRIDE,
      faker.number.int({ min: 150, max: 500 }).toString(),
    );
    await this.milesNewSalesRequestPage.clickField(
      LEASE_SERVICE_LABELS.RV_OVERRIDE_STATUS,
    );
    await this.milesNewSalesRequestPage.selectValueFromDropdown(
      rvOverrideStatus,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.SUMMARY,
    );
  }

  async addManualStandardInterestMargin(manualInterestStatus: string) {
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.LEASE_SERVICE,
    );
    await this.milesNewSalesRequestPage.clickHorizontalTab(
      LEASE_SERVICE_LABELS.MORE,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      LEASE_SERVICE_LABELS.MANUAL_STANDARD_INTEREST_MARGIN,
      faker.number.int({ min: 1, max: 10 }).toString(),
    );
    await this.milesNewSalesRequestPage.clickField(
      LEASE_SERVICE_LABELS.MANUAL_INTEREST_STATUS,
    );
    await this.milesNewSalesRequestPage.selectValueFromDropdown(
      manualInterestStatus,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.SUMMARY,
    );
  }

  /**
   * Business Logic: The services that you add and remove are dependent on the Quotation Template chosen.
   * For some templates you need to remove an option and add another,
   * for a different template nothing needs to change, however this function ensures the removeService is or becomes unticked.
   *
   * Business Logic example: When Quotation Template is T2P, then the Comprehensive Insurance with Vero should already be ticked.
   * So just verify that.
   * If there is nothing with vero. Then select - Do And Charge with Provision - Annual Comprehensive Insurance (Vero-NLCi)
   * But when the Quotation Template is something else, try to select - Budgeted - Annual Comprehensive Insurance (Vero-NLCi).
   *
   * @param expandService1 When editing the Lease Service Options provide each option in the heirarchy which needs to be expanded
   * @param expandService2 Provide each option in the heirarchy which needs to be expanded
   * @param expandService3 Provide each option in the heirarchy which needs to be expanded
   * @param removeService This option will either remain unticked, or become unticked
   * @param addService    This option will either remain ticked, or become ticked
   */

  async editLeaseServiceOptions({
    expandService1,
    expandService2,
    expandService3,
    removeService,
    addService,
  }: {
    expandService1?: string;
    expandService2?: string;
    expandService3?: string;
    removeService?: string;
    addService?: string;
  }) {
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.LEASE_SERVICE,
    );
    await this.milesNewSalesRequestPage.btnEditLeaseService.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    if (expandService1) {
      await this.milesNewSalesRequestPage.dblClickAvailableService(
        expandService1,
      );
    }
    if (expandService2) {
      await this.milesNewSalesRequestPage.dblClickAvailableService(
        expandService2,
      );
    }
    if (expandService3) {
      await this.milesNewSalesRequestPage.dblClickAvailableService(
        expandService3,
      );
    }
    if (removeService) {
      await this.milesNewSalesRequestPage.untickCheckboxForAvailableService(
        removeService,
      );
    }
    if (addService) {
      await this.milesNewSalesRequestPage.tickCheckboxForAvailableService(
        addService,
      );
    }
    await this.milesNewSalesRequestPage.btnOK.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.clickMenuItem(
      NEW_QUOTE_REQ_LABELS.SUMMARY,
    );
  }

  async enterZLEVDeliveryDetails(
    firstRegistrationDate: string,
    registrationExpiry: string,
    zlevFirstHeldDate: string,
    zlevFirstPurchasePrice: string,
  ) {
    await this.milesNewSalesRequestPage.clickMenuItem("Vehicle");
    await this.milesNewSalesRequestPage.clickHorizontalTab("Delivery");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      VEHICLE_DELIVERY_LABELS.FIRST_REGISTRATION_DATE,
      firstRegistrationDate,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      VEHICLE_DELIVERY_LABELS.REGISTRATION_EXPIRY,
      registrationExpiry,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();

    await this.milesNewSalesRequestPage.clickHorizontalTab("More");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.ZLEV_FIRST_HELD_DATE,
      zlevFirstHeldDate,
    );
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.ZLEV_FIRST_PURCHASE_PRICE,
      zlevFirstPurchasePrice,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async enterDistanceOfDate() {
    await this.milesNewSalesRequestPage.clickMenuItem("Summary");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.DISTANCE_OF_DATE,
      faker.number.int({ min: 100, max: 150 }) + "",
    );
    await this.milesNewSalesRequestPage.clickOut(
      NEW_QUOTE_VEHICLE_LABELS.AMOUNT_FINANCE,
    );
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async editManualFBTFields({
    manualFBTValue,
    manualFBTStatus,
    tab,
  }: {
    manualFBTValue: string;
    manualFBTStatus?: string;
    tab?: string;
  }) {
    await this.milesNewSalesRequestPage.clickMenuItem("Vehicle", tab);
    await this.milesNewSalesRequestPage.clickHorizontalTab("More");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_VALUE,
      manualFBTValue,
    );
    await this.milesNewSalesRequestPage.clickBtnInFocusedTextBox(
      NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_STATUS,
    );
    if (manualFBTStatus != undefined) {
      await this.milesNewSalesRequestPage.enterValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_STATUS,
        manualFBTStatus,
      );
      await this.milesNewSalesRequestPage.clickField(
        NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_VALUE,
      );
    }

    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
  }

  async addThirdPartyLessor(thirdPartyLessor: string) {
    await this.milesNewSalesRequestPage.clickMenuItem("Lease Service");
    await this.milesNewSalesRequestPage.enterValueByLabel2(
      NEW_QUOTE_VEHICLE_LABELS.THIRD_PARTY_LESSOR,
      thirdPartyLessor,
    );
    await this.milesNewSalesRequestPage.clickField(
      NEW_QUOTE_VEHICLE_LABELS.RV_OVERRIDE_STATUS,
    );
    await this.page.waitForTimeout(1000);
    await this.milesNewSalesRequestPage.btnSave.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.clickMenuItem("Summary");
  }

  async createQuoteFromNewContact(template: string, vehicleDescp: string) {
    await this.createQuoteFromContact();
    await this.selectQuotationTemplateForNewQuote(template);
    await this.selectVehicleTypeForNewQuote(vehicleDescp);
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
  }

  async createQuoteFromContact() {
    await this.newContact.createQuote.click();
    await this.milesNewSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
  }
}
