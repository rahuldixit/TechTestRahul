import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesVehicleOrderPage } from "../../pages/miles/MilesVehicleOrderPage";
import { VEHICLE_ORDER_LABELS, CONTRACT_LABELS } from "../../../enums/milesapp";

export class CreateNewVehicleOrder {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesVehicleOrderPage: MilesVehicleOrderPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesVehicleOrderPage = new MilesVehicleOrderPage(page);
  }

  async createNewMilesVehicleOrder({
    ltc,
    supplier,
    insuranceType,
    tradingOrderStatus,
  }: {
    ltc: string;
    supplier: string;
    insuranceType?: string;
    tradingOrderStatus?: string;
  }) {
    await this.searchValue(ltc);
    if (insuranceType) {
      await this.milesContractPage.clickField(CONTRACT_LABELS.INSURANCE_TYPE);
      await this.milesContractPage.selectValueFromDropdown(insuranceType);
      await this.milesContractPage.btnSave.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
    }
    await this.goToVehicleOrdersFromContract();
    await this.createVO(supplier, tradingOrderStatus);
    await this.approveVehicleOrder();
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
  }

  async goToVehicleOrdersFromContract() {
    await this.milesContractPage.btnVehicle.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.closeBtnMsgCollapser(3000);
  }

  async createVO(supplier: string, tradingOrderStatus?: string) {
    await this.milesVehicleOrderPage.clickBtnInFocusedTextBox(
      VEHICLE_ORDER_LABELS.SUPPLIER,
      0,
      true,
    );
    await this.milesVehicleOrderPage.enterDetailsByLabel(
      VEHICLE_ORDER_LABELS.TRADING_NAME,
      supplier,
    );
    await this.milesVehicleOrderPage.btnSearch.click();
    await this.milesVehicleOrderPage.selectFirstRowFromTable(5);
    const supplierReference =
      await this.milesVehicleOrderPage.retrieveValueByLabel(
        VEHICLE_ORDER_LABELS.VEHICLE_ORDER_NUMBER,
      );
    await this.milesVehicleOrderPage.enterValueByLabel(
      VEHICLE_ORDER_LABELS.SUPPLIER_REFERENCE,
      supplierReference,
    );
    await this.milesVehicleOrderPage.clickBtnInFocusedTextBox(
      VEHICLE_ORDER_LABELS.EST_DELIVERY_DATE,
    );
    await this.milesVehicleOrderPage.btnTodayDateChooser.click();
    if (tradingOrderStatus) {
      await this.milesVehicleOrderPage.clickField(
        VEHICLE_ORDER_LABELS.TRADING_ORDER_STATUS,
      );
      await this.milesVehicleOrderPage.selectValueFromDropdown(
        tradingOrderStatus,
      );
    }
    await this.milesVehicleOrderPage.btnSave.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
  }

  async approveVehicleOrder() {
    await this.milesVehicleOrderPage.btnValidate.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
    await this.milesVehicleOrderPage.btnApprove.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
    await this.milesVehicleOrderPage.closeBtnMsgCollapser();
    await this.updateApprovedVOToSent();
  }

  async updateApprovedVOToSent() {
    await this.milesVehicleOrderPage.clickBtnInFocusedTextBox(
      VEHICLE_ORDER_LABELS.STATUS,
    );
    await this.milesVehicleOrderPage.selectValueFromDropdown("Sent");
    await this.milesVehicleOrderPage.btnSave.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
    const status = await this.milesVehicleOrderPage.contextStatus.inputValue();
    expect(status).toBe("Sent");
  }
}
