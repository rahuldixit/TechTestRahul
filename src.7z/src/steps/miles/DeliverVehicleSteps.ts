import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesFleetVehiclePage } from "../../pages/miles/MilesFleetVehiclePage";
import { MilesContactPage } from "../../pages/miles/MilesContactPage ";
import { MilesCustomerPage } from "../../pages/miles/MilesCustomerPage";
import { FLEET_VEHICLE_LABELS, CONTACT_LABELS } from "../../../enums/milesapp";
import { faker } from "@faker-js/faker";
import moment from "moment";

export class DeliverTheVehicle {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesFleetVehiclePage: MilesFleetVehiclePage;
  milesContactPage: MilesContactPage;
  milesCustomerPage: MilesCustomerPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesFleetVehiclePage = new MilesFleetVehiclePage(page);
    this.milesContactPage = new MilesContactPage(page);
    this.milesCustomerPage = new MilesCustomerPage(page);
  }

  async deliverVehicle({
    ltc,
    // licenseNumber must be in a valid license number format
    licenseNumber = faker.number.int({ min: 10000, max: 99999 }) +
      faker.string.alpha({ length: 1, casing: "upper" }),
    // Chassis Number must be exactly 17 characters (0-9 & A-Z) with the exclusion of "I", "O", "Q"
    chassisNumber = faker.string.alpha({
      length: 17,
      casing: "upper",
      exclude: ["I", "O", "Q"],
    }),
    motorNumber = "12aaaaaaaa",
    region = ["ACT", "NSW", "NT", "QLD", "SA", "TAS", "VIC", "WA"][
      faker.number.int({ max: 7 })
    ],
    deliveryDistance = faker.number.int({ min: 1, max: 500 }).toString(),
    registrationDate,
    deliveryDate,
  }: {
    ltc: string;
    licenseNumber?: string;
    chassisNumber?: string;
    motorNumber?: string;
    region?: string;
    deliveryDistance?: string;
    registrationDate?: string;
    deliveryDate?: string;
  }) {
    await this.searchValue(ltc);
    await this.goToRegistrationAndDocuments();
    await this.enterFleetVehicleDetails(
      licenseNumber,
      chassisNumber,
      motorNumber,
      region,
      registrationDate,
    );
    await this.completeExpressDeliveryAndDeliver(
      deliveryDistance,
      deliveryDate,
    );
    await this.verifyContextStatus();
  }

  // Checks if there's a vehicle, if not then it does a new one and delivers it
  async deliverNewOrExistingVehicle({
    ltc,
    state,
  }: {
    ltc: string;
    state?: string;
  }) {
    await this.searchValue(ltc);
    await this.goToRegistrationAndDocuments();
    const chassisNumber = await this.milesFleetVehiclePage.retrieveValueByLabel(
      FLEET_VEHICLE_LABELS.CHASSIS_NUMBER,
    );
    // IF vehicle already exists
    if (chassisNumber != "_________________") {
      await this.completeExpressDeliveryAndDeliver(
        faker.number.int({ min: 1, max: 500 }).toString(),
        undefined,
        state ? state : undefined,
      );
      await this.verifyContextStatus();
    }
    // ELSE deliver vehicle (some quick navigation repeated)
    else {
      await this.deliverVehicle({ ltc });
    }
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
  }

  async goToRegistrationAndDocuments() {
    await this.milesContractPage.btnOpenVehicle.click();
    await this.milesFleetVehiclePage.waitUntilLoadingFinishes();
    await this.milesFleetVehiclePage.closeBtnMsgCollapser();
    await this.milesFleetVehiclePage.clickMenuItem(
      FLEET_VEHICLE_LABELS.VEHICLE_USAGES,
    );
    await this.milesFleetVehiclePage.clickMenuItem(
      FLEET_VEHICLE_LABELS.REGISTRATION_AND_DOCUMENTS,
    );
  }

  async enterFleetVehicleDetails(
    licenseNumber: string,
    chassisNumber: string,
    motorNumber: string,
    region: string,
    registrationDate?: string,
  ) {
    await this.milesFleetVehiclePage.enterValueByLabel2(
      FLEET_VEHICLE_LABELS.CHASSIS_NUMBER,
      chassisNumber,
    );
    await this.milesFleetVehiclePage.enterValueByLabel2(
      FLEET_VEHICLE_LABELS.MOTOR_NUMBER,
      motorNumber,
    );
    await this.milesFleetVehiclePage.btnAddRegisteredLicensePlates.click();
    await this.milesFleetVehiclePage.enterTableCellValue(2, licenseNumber);
    await this.milesFleetVehiclePage.clickTableCellValue(3);
    if (registrationDate) {
      await this.milesFleetVehiclePage.enterTableCellValue(3, registrationDate);
      await this.milesFleetVehiclePage.clickTableCellValue(7); // click out
    } else {
      await this.milesFleetVehiclePage.selectBtnInTableCell(3);
      await this.milesFleetVehiclePage.btnTodayDateChooser.click();
    }
    await this.milesFleetVehiclePage.clickTableCellValue(7);
    await this.milesFleetVehiclePage.selectValueFromDropdown(region);
    await this.milesFleetVehiclePage.btnSave.click();
  }

  async completeExpressDeliveryAndDeliver(
    deliveryDistance: string,
    deliveryDate?: string,
    state?: string,
  ) {
    if (state) {
      const region = await this.milesFleetVehiclePage.getTableCellLocator(
        "Registered License Plates",
        -1,
        0,
        7,
      );
      await region.click();
      await region.type(state ? state : "");
      await this.milesFleetVehiclePage.btnDeliver.click(); //need to click twice on the deliver button when there is state
    }
    if (!(await this.milesFleetVehiclePage.btnDeliver.isVisible())) {
      await this.milesFleetVehiclePage.menuRibbon.hover();
      await this.milesFleetVehiclePage.menuRibbonScrollRight.click();
    }
    await this.milesFleetVehiclePage.btnDeliver.click();
    await this.milesFleetVehiclePage.btnOK.click();
    await this.milesFleetVehiclePage.dismissSystemDialog(
      "An unexpected error has occurred. Please try again or contact support if this problem persists",
    );
    if (deliveryDate) {
      await this.milesFleetVehiclePage.enterValueByLabel2(
        FLEET_VEHICLE_LABELS.DATE_AND_TIME,
        deliveryDate,
      );
      const twoWeeksAgo = moment().subtract(14, "days");
      const deliveryMoment = moment(deliveryDate, "DD/MM/YYYY");
      if (deliveryMoment < twoWeeksAgo) {
        await this.milesFleetVehiclePage.checkboxAcknowledge14days.click();
      }
    } else {
      await this.milesFleetVehiclePage.clickBtnInFocusedTextBox(
        FLEET_VEHICLE_LABELS.DATE_AND_TIME,
      );
      await this.milesFleetVehiclePage.btnTodayDateChooser.click();
    }
    await this.milesFleetVehiclePage.enterValueByLabel2(
      FLEET_VEHICLE_LABELS.DISTANCE,
      deliveryDistance,
    );
    await this.milesFleetVehiclePage.btnDeliverDialog.click();
    await this.milesFleetVehiclePage.waitUntilLoadingFinishes(120);
    await this.handleDeliverVehicleErrors(deliveryDistance);
  }

  // Handle all known errors
  async handleDeliverVehicleErrors(deliveryDistance: string) {
    const errormsg = await this.milesFleetVehiclePage.getSystemErrorMsg();
    if (errormsg) {
      if (
        errormsg.includes(
          "It is mandatory for a Novated Driver to have a birthdate populated",
        )
      ) {
        await this.handleBirthdateError();
      } else if (
        errormsg.includes(
          "It is mandatory for a Novated Customer to have a bank account",
        )
      ) {
        await this.handleBankAccountError();
      } else if (errormsg.includes('The "EV label affixed" cannot be empty')) {
        await this.handleEVLabelAffixedError(deliveryDistance);
      } else {
        console.log("New Error to handle. FAILED");
        expect(true, "ERROR: " + errormsg).toEqual(false);
      }
      // check for more errors
      await this.handleDeliverVehicleErrors(deliveryDistance);
    }
  }

  // Handle Birthdate Error - see handleDeliverVehicleErrors for erorr
  async handleBirthdateError() {
    await this.milesFleetVehiclePage.btnClose.click();
    await this.milesFleetVehiclePage.clickField(FLEET_VEHICLE_LABELS.DRIVER);
    const dob = moment().subtract(20, "years").format("DD/MM/YYYY");
    await this.milesContactPage.enterValueByLabel2(
      CONTACT_LABELS.DATE_OF_BIRTH,
      dob,
    );
    await this.milesContactPage.clickOut(CONTACT_LABELS.GENDER);
    await this.milesContactPage.btnSave.click();
    await this.milesContactPage.clickBottomTab("FV");
    await this.milesFleetVehiclePage.btnDeliverDialog.click();
    await this.milesFleetVehiclePage.waitUntilLoadingFinishes(120);
  }

  // Handle Bank Account error - see handleDeliverVehicleErrors for erorr
  async handleBankAccountError() {
    await this.milesFleetVehiclePage.btnClose.click();
    await this.milesFleetVehiclePage.clickField(FLEET_VEHICLE_LABELS.DRIVER);
    await this.milesContactPage.menuNovatedCustomer.click();
    await this.milesContactPage.searchResultsCustomerId.click();
    await this.milesCustomerPage.menuFinancial.click();
    await this.milesCustomerPage.btnAddBankAccounts.click();
    await this.milesCustomerPage.dropdownCheckType.waitFor();
    await this.milesCustomerPage.dropdownCheckType.click();
    await this.milesCustomerPage.selectValueFromDropdown("Australian");
    await this.milesCustomerPage.fieldAccountNumber.click();
    await this.milesCustomerPage.fieldAccountNumber.type("012000000000000");
    const statusField = await this.milesCustomerPage.getTableCellLocator(
      "Bank Accounts",
      -1,
      0,
      5,
    );
    await statusField.click();
    await this.milesCustomerPage.selectValueFromDropdown("Open");
    await this.milesCustomerPage.btnSave.click();
    await this.milesCustomerPage.clickBottomTab("FV");
    await this.milesCustomerPage.clickBtnInFocusedTextBox;
    await this.milesFleetVehiclePage.btnDeliverDialog.click();
    await this.milesFleetVehiclePage.waitUntilLoadingFinishes(120);
  }

  // Handle EV Label Affexed error - see handleDeliverVehicleErrors for erorr
  async handleEVLabelAffixedError(deliveryDistance: string) {
    const tableName = FLEET_VEHICLE_LABELS.REGISTERED_LICENSE_PLATES;
    const tableIndex = -1;
    const row = 0;
    const evLabelAffixedColumn = 8;
    await this.milesFleetVehiclePage.btnClose.click();
    await this.milesFleetVehiclePage.clickField(
      FLEET_VEHICLE_LABELS.FLEET_VEHICLE,
    );
    await this.milesFleetVehiclePage.btnCancel.click();
    const evLabelField = await this.milesFleetVehiclePage.getTableCellLocator(
      tableName,
      tableIndex,
      row,
      evLabelAffixedColumn,
    );
    await evLabelField.click();
    await this.milesFleetVehiclePage.selectValueFromDropdown(
      ["Yes", "No"][faker.number.int({ max: 1 })],
    );
    await this.milesFleetVehiclePage.btnSave.click();
    await this.completeExpressDeliveryAndDeliver(deliveryDistance);
  }

  async verifyContextStatus() {
    const status = await this.milesFleetVehiclePage.contextStatus.inputValue();
    expect(status).toBe("In Use");
  }
}
