import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesVehicleOrderPage } from "../../pages/miles/MilesVehicleOrderPage";

export class ExistingVehicleOrder {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesVehicleOrderPage: MilesVehicleOrderPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesVehicleOrderPage = new MilesVehicleOrderPage(page);
  }

  async approveExistingVehicleOrder({ ltc }: { ltc: string }) {
    await this.searchValue(ltc);
    const orderStatus =
      await this.milesContractPage.orderStatusFirstRowInVO.innerText();
    expect(orderStatus).toEqual("Waiting For Approval");
    await this.milesContractPage.referenceStatusFirstRowInVO.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.validateApproveVO();
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
  }

  async validateApproveVO() {
    await this.milesVehicleOrderPage.btnValidate.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
    await this.milesVehicleOrderPage.btnApprove.click();
    await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
  }
}
