import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesSearchBulkOperations } from "../../pages/miles/MilesBulkOperationsPage";
import {
  BULK_OPERATIONS,
  FINANCIAL_LABELS,
  GENERAL_LEDGER_LABELS,
  PAYMENTS_LABELS,
  PURCHASE_INVOICE_LABELS,
  SEARCH_CONTRACT_LABELS,
} from "../../../enums/milesapp";
import { MilesPurchaseInvoicePage } from "../../pages/miles/MilesPurchaseInvoicePage";
import fs from "fs";
import exec from "child_process";
import { MilesSearchPage } from "../../pages/miles/MilesSearchPage";

// @ts-expect-error :line needed to import browser-env that is only available in javascript not typescript
import browserEnv from "browser-env";

import moment from "moment";
import path from "path";
import { MilesContractPage } from "pages/miles/MilesContractPage";
import { MilesPaymentsPage } from "pages/miles/MilesPaymentsPage";

export class MilesBulkOperationsSteps {
  readonly page: Page;
  readonly milesHomePage: MilesHomePage;
  readonly milesBulkOperationPage: MilesSearchBulkOperations;
  readonly milesSearchPage: MilesSearchPage;
  readonly milesPurchaseInvoicePage: MilesPurchaseInvoicePage;
  readonly milesContractPage: MilesContractPage;
  readonly milesPaymentsPage: MilesPaymentsPage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesBulkOperationPage = new MilesSearchBulkOperations(page);
    this.milesSearchPage = new MilesSearchPage(page);
    this.milesPurchaseInvoicePage = new MilesPurchaseInvoicePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesPaymentsPage = new MilesPaymentsPage(page);
  }

  async doctorCityLinkConnectorFile(data: string, cons: string) {
    const fields = data.toString().split("|");
    const threeMonthsAgo = moment().subtract(3, "months");
    const twoMonthsAgo = moment().subtract(2, "months");
    const timestamp1 = threeMonthsAgo.format("YYYYMMDDhhmmss");
    const timestamp2 = twoMonthsAgo.format("YYYYMMDDhhmmss");
    fields[13] = timestamp1;
    fields[14] = timestamp2;
    const startDate = threeMonthsAgo.format("DD/MM/YYYY hh:mm");
    const endDate = twoMonthsAgo.format("DD/MM/YYYY hh:mm");
    let line = "";
    fields.forEach((field: string) => {
      line = line + "|" + field;
    });
    line = line.slice(1);

    const filename = cons + " - " + timestamp1 + ".txt";
    return [line, filename, startDate, endDate];
  }

  async doctorSOFGenericCostImportFile(data: string) {
    const dataFields = data.split(";");
    const amount = dataFields[3];
    const invoiceNumber = dataFields[2] + moment().format("DDMMYYYYhhmmss");
    let fieldData = "";

    for (let i = 0; i < dataFields.length; i++) {
      if (i == 2) {
        fieldData = fieldData + invoiceNumber + ";"; //set a unique invoice id based on timestamp
      } else if (i == dataFields.length - 1) {
        fieldData = fieldData + dataFields[i]; //ensure last fields does not have an ending delimiter ';'
      } else {
        fieldData = fieldData + dataFields[i] + ";";
      }
    }

    return [amount, fieldData];
  }

  async searchBulkOperation(bulkOperation: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(
      "Jobs - Bulk Operations",
    );
    await this.page.locator("text=Search").last().dblclick();
    await this.milesHomePage.waitUntilLoadingFinishes();
    await this.milesBulkOperationPage.enterDetailsByLabel(
      BULK_OPERATIONS.SEARCH_NAME,
      bulkOperation,
    );
    await this.milesBulkOperationPage.enterDetailsByLabel(
      BULK_OPERATIONS.COMMAND_NAME,
      "",
    );
    await this.milesBulkOperationPage.btnSearch.click();
    await this.milesHomePage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
  }

  async processFile(
    line: string,
    filename: string,
    targetServer: string,
    targetShare: string,
    allocate?: boolean,
  ) {
    const srcPath = path.join(__dirname, "..", "..", "..", "assets", filename);
    fs.writeFile(srcPath, line, () => {});
    targetShare = targetShare + filename;
    browserEnv(["navigator"]);
    if (global.navigator.userAgent.indexOf("linux") != -1) {
      exec.exec(
        `smbclient '${targetServer}' -c 'put "${srcPath}" "${targetShare}"' -U "${process.env.TEST_USERNAME}%${process.env.TEST_PASSWORD}"`,
        (stdout, error) => {
          console.log(stdout);
          console.log(error);
        },
      );
    } else {
      exec.exec(
        `copy "${srcPath}" "${targetServer}\\${targetShare}"`,
        (err: any) => {
          if (err) {
            console.log(err);
          }
        },
      );
    }

    await this.milesBulkOperationPage.btnRefresh.click();
    await this.milesBulkOperationPage.waitUntilLoadingFinishes();
    await this.milesBulkOperationPage.inputFile.click();
    await this.milesBulkOperationPage.inputFile.type(filename);
    await this.milesBulkOperationPage.waitForFileSelectionItem(filename);
    await this.milesBulkOperationPage.clickOut("Selection");
    if (allocate) {
      await this.milesBulkOperationPage.inputAllocate.click();
      await this.milesBulkOperationPage.inputAllocate.type("True");
      await this.milesBulkOperationPage.inputPost.click();
      await this.milesBulkOperationPage.inputPost.type("False");
    }
    await this.milesBulkOperationPage.btnExecuteNow.click();
    await this.milesBulkOperationPage.waitUntilLoadingFinishes();
  }

  async openAndVerifyProcessedFile() {
    let timestamp =
      await this.milesBulkOperationPage.uploadedFileTimestamp.innerText();
    let date = timestamp.split(" ")[0];
    const time = timestamp.split(" ")[1] + ":00";
    date =
      date.split("/")[2] + "-" + date.split("/")[1] + "-" + date.split("/")[0];
    timestamp = date + "T" + time;

    //if file is processed in last 5 mins, it is expected to be correct file
    expect(moment().subtract(5, "minutes").valueOf()).toBeLessThan(
      moment(timestamp).valueOf(),
    );
    await this.milesBulkOperationPage.uploadedFileTimestamp.dblclick();
    await this.milesBulkOperationPage.waitUntilLoadingFinishes();
    const downloadPromise = this.page.waitForEvent("download");
    await this.milesBulkOperationPage.linkHTMLFile.waitFor();
    await this.page.evaluate(() => {
      document
        .querySelectorAll("a.silkClickableLink")[4]
        .setAttribute("style", "position: absolute");
    });
    await this.milesBulkOperationPage.htmlFile.click();
    const download = await downloadPromise;
    const downloadPath = await download.path();
    await this.milesBulkOperationPage.waitUntilLoadingFinishes();
    return downloadPath;
  }

  async verifySuccessfullyProcessedFileCityLink() {
    const downloadPath = await this.openAndVerifyProcessedFile();
    const incomingInvoiceId = await this.getInvoiceIDCityLink(downloadPath);
    await this.verifyIncomingInvoiceIDExistsAsAPurchaseInvoice(
      incomingInvoiceId,
    );
  }

  async verifySuccessfullyProcessedFileGenericCostImport() {
    const downloadPath = await this.openAndVerifyProcessedFile();
    const incomingInvoiceId =
      await this.getInvoiceIDGenericCostImport(downloadPath);
    await this.verifyIncomingInvoiceIDExistsAsAPurchaseInvoice(
      incomingInvoiceId,
    );
  }

  async verifySuccessfullyProcessedFileBillingItems() {
    const downloadPath = await this.openAndVerifyProcessedFile();
    fs.readFile(downloadPath, "utf8", (err, data: string) => {
      if (err) {
        throw err;
      }
      data = data + "";
      expect(data).toContain(
        `No. of Unsuccesful Records</td><td class=top style='color:red; font-weight:bold'>&nbsp;:&nbsp;</td><td class=top style='color:red; font-weight:bold'>0`,
      );
    });
  }

  async verifySuccessfullyProcessedFileSundryPayments() {
    const downloadPath = await this.openAndVerifyProcessedFile();
    return await this.getPaymentIDSundryPayment(downloadPath);
  }

  async verifyPIDates(startDate: string, endDate: string) {
    await this.milesBulkOperationPage.clickMenuItem("Contents");
    await this.milesBulkOperationPage.btnGeneric.click();
    expect(
      await this.milesBulkOperationPage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.START_DATE,
      ),
    ).toBe(startDate);
    expect(
      await this.milesBulkOperationPage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.END_DATE,
      ),
    ).toBe(endDate);
  }

  async verifyPIAmount(amount: string) {
    await this.milesBulkOperationPage.clickMenuItem("Contents");
    expect(
      (
        await this.milesBulkOperationPage.getValueInTableCell(
          "Invoice Lines",
          -1,
          0,
          4,
        )
      )
        .replace("$", "")
        .trim(),
    ).toBe(amount);
  }

  async verifyErrorProcessedFile(errorMsg: string) {
    const downloadPath = await this.openAndVerifyProcessedFile();
    fs.readFile(downloadPath, "utf8", (err, data: string) => {
      if (err) {
        throw err;
      }
      data = data + "";
      expect(data).toContain(errorMsg);
    });
  }

  async getInvoiceIDCityLink(downloadPath: any) {
    let incomingInvoiceId = "";
    const readFilePromise = new Promise<string>((resolve) => {
      fs.readFile(downloadPath, "utf8", (err, data: string) => {
        if (err) {
          throw err;
        }
        data = data + "";
        const fields = data.split("<td style='color: green'>");
        incomingInvoiceId = fields[1].replace("</td>\r\n", "");
        expect(data).not.toContain("Error");
        resolve(incomingInvoiceId);
      });
    });
    return await readFilePromise;
  }

  async getInvoiceIDGenericCostImport(downloadPath: any) {
    let incomingInvoiceId = "";
    const readFilePromise = new Promise<string>((resolve) => {
      fs.readFile(downloadPath, "utf8", (err, data: string) => {
        if (err) {
          throw err;
        }
        data = data + "";
        const fields = data.split("<td>");
        incomingInvoiceId = fields[3].replace("</td>", "").trim();
        resolve(incomingInvoiceId);
      });
    });
    return await readFilePromise;
  }

  async getPaymentIDSundryPayment(downloadPath: any) {
    const readFilePromise = new Promise<string>((resolve) => {
      fs.readFile(downloadPath, "utf8", (err, data: string) => {
        if (err) {
          throw err;
        }
        data = data + "";
        const fields = data.split("<td style='color: green'>");
        const firstPaymentID = fields[6].replace("</td>", "").trim();
        expect(data).toContain(
          `No. of Unsuccesful Records</td><td class=top style='color:red; font-weight:bold'>&nbsp;:&nbsp;</td><td class=top style='color:red; font-weight:bold'>0`,
        );
        resolve(firstPaymentID);
      });
    });
    return await readFilePromise;
  }

  async verifyIncomingInvoiceIDExistsAsAPurchaseInvoice(
    incomingInvoiceId: string,
  ) {
    await this.milesHomePage.goToHome();
    await this.milesHomePage.clickHorizontalPortalNav("Accounting");
    await this.milesHomePage.clickHorizontalPortalNav("Accounts Payable");
    await this.milesHomePage.clickHorizontalPortalNav("Purchase Invoices");
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown("New selection");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.enterDetailsByLabel(
      PURCHASE_INVOICE_LABELS.DOCUMENT_NUMBER_,
      "",
    );
    await this.milesSearchPage.enterDetailsByLabel(
      PURCHASE_INVOICE_LABELS.ID,
      incomingInvoiceId,
    );
    await this.page.keyboard.press("Enter");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    expect(
      await this.milesPurchaseInvoicePage.retrieveValueByLabel(
        PURCHASE_INVOICE_LABELS.DOCUMENT_ID,
      ),
    ).toBe(incomingInvoiceId);
  }

  async verifyBillingItems(contractID: string, date: string) {
    await this.milesHomePage.goToHome();
    await this.milesHomePage.clickHorizontalPortalNav("Contracts");
    await this.milesHomePage.clickHorizontalPortalNav("Long Term Contracts");
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown("New selection");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.ID,
      contractID,
    );
    await this.page.keyboard.press("Enter");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickMenuItem("Financial");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickMenuItem("Billing Overview");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.enterValueByLabel2(
      FINANCIAL_LABELS.END_DATE,
      "=",
    );
    await this.milesContractPage.enterDetailsByLabel(
      FINANCIAL_LABELS.END_DATE,
      date,
    );
    await this.page.keyboard.press("Enter");
    await this.milesContractPage.waitUntilLoadingFinishes();
    const rows = await this.milesContractPage.getNumberOfTableRows(
      "Search Results",
      -1,
    );
    expect(
      moment(
        await this.milesContractPage.getValueInTableCell(
          "Search Results",
          -1,
          rows - 1,
          11,
        ),
        "DD/MM/YYYY 00:00",
      ).format("DD/MM/YYYY"),
    ).toBe(moment().format("DD/MM/YYYY"));
    expect(
      moment(
        await this.milesContractPage.getValueInTableCell(
          "Search Results",
          -1,
          rows - 2,
          11,
        ),
        "DD/MM/YYYY 00:00",
      ).format("DD/MM/YYYY"),
    ).toBe(moment().format("DD/MM/YYYY"));
    expect(
      moment(
        await this.milesContractPage.getValueInTableCell(
          "Search Results",
          -1,
          rows - 3,
          11,
        ),
        "DD/MM/YYYY 00:00",
      ).format("DD/MM/YYYY"),
    ).toBe(moment().format("DD/MM/YYYY"));
  }

  async verifySundryPayment(paymentID: string) {
    await this.milesHomePage.goToHome();
    await this.milesHomePage.clickHorizontalPortalNav("Accounting");
    await this.milesHomePage.clickHorizontalPortalNav("Sundry");
    await this.milesHomePage.clickHorizontalPortalNav("Sundry Posting");

    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown("New selection");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.ID,
      paymentID,
    );
    await this.page.keyboard.press("Enter");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
    expect(
      await this.milesPaymentsPage.retrieveValueByLabel(PAYMENTS_LABELS.STATUS),
    ).toBe("Allocated");
    await this.milesPaymentsPage.btnPost.click();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    expect(
      await this.milesPaymentsPage.retrieveValueByLabel(PAYMENTS_LABELS.STATUS),
    ).toBe("Posted");
    await this.milesHomePage.goToHome();
    await this.milesHomePage.clickHorizontalPortalNav("Accounting");
    await this.milesHomePage.clickHorizontalPortalNav("General Ledger");
    await this.milesHomePage.clickHorizontalPortalNav("Browse General Ledger");
    await this.milesSearchPage.enterDetailsByLabel(
      GENERAL_LEDGER_LABELS.PAYMENT_ID,
      paymentID,
    );
    await this.page.keyboard.press("Enter");
    await this.milesSearchPage.waitUntilLoadingFinishes();
    expect(
      await this.milesSearchPage.getNumberOfTableRows("Search Results", -1),
    ).toBe(2);
  }
}
