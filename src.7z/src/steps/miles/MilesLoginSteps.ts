import { Page } from "@playwright/test";
import { MilesLoginPage } from "../../pages/miles/MilesLoginPage";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesSideBarPage } from "../../pages/miles/MilesSideBarPage";

export class MilesLogin {
  milesLoginPage: MilesLoginPage;
  milesHomePage: MilesHomePage;
  milesSidebarLoginPage: MilesSideBarPage;
  page: Page;

  constructor(page: Page) {
    this.milesLoginPage = new MilesLoginPage(page);
    this.milesHomePage = new MilesHomePage(page);
    this.milesSidebarLoginPage = new MilesSideBarPage(page);
    this.page = page;
  }

  async loginIntoMilesApplication(
    url: string,
    username: string,
    password: string,
  ) {
    console.log("Username: " + username);
    console.log("URL: " + url);
    await this.milesLoginPage.openMilesURL(url);
    await this.milesLoginPage.milesUsername.waitFor();
    await this.milesLoginPage.milesUsername.fill(username);
    await this.milesLoginPage.milesPassword.fill(password);
    await this.milesLoginPage.btnMilesLogin.click();
    await this.milesHomePage.home.waitFor();
    await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });
  }

  async loginIntoMilesSidebar({
    url: url,
    sroid: sroid,
    contractID: contractID,
  }: {
    url: string;
    sroid: string;
    contractID: string;
  }) {
    await this.milesSidebarLoginPage.openMilesSidebar(url, sroid, contractID);
  }
}
