import { Page, expect } from "@playwright/test";
import { CreateNewQuote } from "./CreateNewQuoteSteps";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesNewSalesRequestPage } from "../../pages/miles/MilesNewSalesRequestPage";
import { MilesSearchPage } from "../../pages/miles/MilesSearchPage";
import {
  QUOTE_AMENDMENT_LABELS,
  NEW_QUOTE_REQ_LABELS,
  CONTRACT_LABELS,
  DRIVER_SEARCH_LABELS,
  CUSTOMER_OR_COST_CENTRE_LABELS,
  SEARCH_QUOTE_LABELS,
} from "../../../enums/milesapp";
import moment from "moment";

export class ModifyContract {
  readonly page: Page;
  createNewQuote: CreateNewQuote;
  milesContractPage: MilesContractPage;
  milesSalesRequestPage: MilesNewSalesRequestPage;
  milesSearchContractPage: MilesSearchPage;
  milesNewSalesRequestPage: MilesNewSalesRequestPage;

  constructor(page: Page) {
    this.page = page;
    this.createNewQuote = new CreateNewQuote(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesSalesRequestPage = new MilesNewSalesRequestPage(page);
    this.milesSearchContractPage = new MilesSearchPage(page);
    this.milesNewSalesRequestPage = new MilesNewSalesRequestPage(page);
  }

  async modifyContract({
    ltc,
    changeReason,
    date,
  }: {
    ltc: string;
    changeReason: string;
    date?: string;
  }) {
    await this.milesContractPage.enterAndSelectValueInQuickNavigation(ltc);
    await this.modifyContractAndSelectChangeReason(changeReason, date);
  }

  async validateAndVerifyChangeReasonInNewVersion(changeReason: string) {
    await this.milesContractPage.clickBottomTab("AQ");
    await this.validateApproveContractFromQuoteOrAQ();
    await this.verifyChangeReasonForNewVersion(changeReason);
  }

  async modifyContractAndSelectChangeReason(
    changeReason: string,
    date?: string,
  ) {
    await this.milesContractPage.btnModifyContract.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.closeBtnMsgCollapserContractModificationPopup();
    await this.milesContractPage.enterValueByLabel(
      QUOTE_AMENDMENT_LABELS.CHANGE_REASON,
      changeReason,
    );
    await this.page.keyboard.press("Enter");
    if (date) {
      await this.milesContractPage.enterValueByLabel2(
        QUOTE_AMENDMENT_LABELS.CHANGE_DATE,
        date,
      );
    }
    if (await this.milesContractPage.btnModify.isVisible()) {
      await this.milesContractPage.btnModify.click();
    } else {
      await this.milesContractPage.btnNext.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
      if (await this.milesContractPage.btnNext.isVisible())
        await this.milesContractPage.btnNext.click();
    }
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  async editAccessoriesInAmendmentQuote() {
    await this.milesSalesRequestPage.btnEditEquipment.scrollIntoViewIfNeeded();
    await this.milesSalesRequestPage.btnEditEquipment.click({ force: true });
    await this.milesSalesRequestPage.filterAccessory.click();
    await this.milesSalesRequestPage.selectRandomAccessory();
    await this.milesSalesRequestPage.btnOK.click();
    await this.milesSalesRequestPage.waitUntilLoadingFinishes();
  }

  // in Quote or Ammendment Quote
  async validateApproveContractFromQuoteOrAQ() {
    await this.milesSalesRequestPage.btnValidate.click();
    await this.milesSalesRequestPage.waitUntilLoadingFinishes();
    await this.handlePausePeriodError();
    await this.milesSalesRequestPage.btnApprove.click();
    await this.milesSalesRequestPage.waitUntilLoadingFinishes();
    await this.createNewQuote.verifyQuoteStatus();
    await this.milesSalesRequestPage.btnContract.click();
    await this.milesSalesRequestPage.waitUntilLoadingFinishes(300);
  }

  async handlePausePeriodError() {
    const errormsg = await this.milesSalesRequestPage.getSystemErrorMsg();
    if (errormsg.includes("Cannot change contract during pause period!")) {
      await this.milesSalesRequestPage.btnClose.click();
      await this.milesSalesRequestPage.clickMenuItem(
        NEW_QUOTE_REQ_LABELS.SUMMARY,
      );
      await this.milesSalesRequestPage.enterValueByLabel2(
        QUOTE_AMENDMENT_LABELS.CHANGE_DATE,
        moment().add(2, "months").format("DD/MM/YYYY"),
      );
      await this.page.keyboard.press("Enter");
      await this.milesSalesRequestPage.clickOut(
        QUOTE_AMENDMENT_LABELS.LEASING_COMPANY,
      );
      await this.milesSalesRequestPage.btnSave.click();
      await this.milesSalesRequestPage.waitUntilLoadingFinishes();
      await this.milesSalesRequestPage.btnValidate.click();
      await this.milesSalesRequestPage.waitUntilLoadingFinishes();
    }
  }

  async verifyChangeReasonForNewVersion(changeReason: string) {
    await this.milesSalesRequestPage.newContractVersion.waitFor();
    await this.milesSalesRequestPage.newContractVersion.click();
    await this.milesSalesRequestPage.waitUntilLoadingFinishes();
    expect(
      await this.milesContractPage.changeReasonInNewVersion.innerText(),
    ).toBe(changeReason);
  }

  // General Restructure
  async selectFirstVersion() {
    // un-tick top version and tick bottom version (first version)
    await this.milesSalesRequestPage.topContractVersion.click();
    await this.milesSalesRequestPage.bottomContractVersion.click();
  }

  async typeAndSelectChangeReason(changeReason: string, changeDate: string) {
    await this.milesContractPage.btnModifyContract.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.closeBtnMsgCollapserContractModificationPopup();
    const isFocused = await this.milesSalesRequestPage.isFieldFocused(
      QUOTE_AMENDMENT_LABELS.CHANGE_REASON,
    );
    if (!isFocused) {
      await this.milesSalesRequestPage.clickField(
        QUOTE_AMENDMENT_LABELS.CHANGE_REASON,
      );
    }
    await this.milesSearchContractPage.enterValueByLabel(
      QUOTE_AMENDMENT_LABELS.CHANGE_REASON,
      changeReason,
    );
    await this.milesSearchContractPage.selectionDropdownIcon.click();
    await this.milesSearchContractPage.selectValueFromDropdown(changeReason);
    await this.milesSearchContractPage.enterValueByLabel(
      QUOTE_AMENDMENT_LABELS.CHANGE_DATE,
      changeDate,
    );
    await this.milesContractPage.btnModify.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  // Go to Lease Services and click Edit
  async editLeaseServices() {
    await this.milesSalesRequestPage.clickMenuItem(
      QUOTE_AMENDMENT_LABELS.LEASE_SERVICE,
      "AQ",
    );
    await this.milesSalesRequestPage.waitUntilLoadingFinishes();
    await this.milesContractPage.btnEditIncludedServices.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  // Edit Lease Services after clicking Edit button
  async deselectGreenfleetAndSelectNone(
    greenfleet: string,
    selectOption: string,
  ) {
    await this.milesContractPage.selectSelectedServices(greenfleet);
    await this.milesContractPage.tickCheckboxAvailableServices(greenfleet);
    await this.milesContractPage.tickCheckboxAvailableServices(selectOption);
    await this.milesContractPage.btnOK.click();
  }

  async selectTab(partialName: string) {
    await this.milesContractPage.clickBottomTab(partialName);
  }

  async costCentreTransfer(toCustomer: string) {
    await this.milesContractPage.enterValueByLabel(
      CONTRACT_LABELS.TO_CUSTOMER,
      toCustomer,
      1,
    );
    await this.milesContractPage.btnTransfer.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    if (await this.milesContractPage.btnTransfer.isVisible()) {
      await this.milesContractPage.btnTransfer.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
    }
    await this.milesContractPage.closeBtnMsgCollapser();
    expect(
      await this.milesContractPage.getValueInTableCell("Versions", -1, 0, 2),
    ).toBe(moment().add(1, "month").format("DD/MM/YYYY"));
    expect(
      await this.milesContractPage.getValueInTableCell("Versions", -1, 0, 6),
    ).toBe("Cost Centre Transfer");
  }

  async reAssignDriver(newBusinessUnitID: string) {
    await this.milesContractPage.closeBtnMsgCollapser();
    await this.milesContractPage.clickField(CONTRACT_LABELS.DRIVER);
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.btnTransferContact.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickBtnInFocusedTextBox("New Business Unit");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.enterValueByLabel(
      SEARCH_QUOTE_LABELS.BUSINESS_UNIT_ID,
      newBusinessUnitID,
      1,
    );
    await this.milesContractPage.btnSearch.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.btnOK.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    if (await this.milesContractPage.btnOK.isVisible()) {
      await this.milesContractPage.btnOK.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
    }
    /* 
    If the driverLink doesn't appear, it means the driver is linked to too many contacts.
    Unlink them. But ensure there is one link left.
    */
    await this.milesContractPage.driverLink.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickMenuItem("Novated Customer");
    await this.milesContractPage.waitUntilLoadingFinishes();
    const driverID = await this.milesContractPage.getValueInTableCell(
      "Search Results",
      -1,
      0,
      0,
    );
    return driverID;
  }

  async selectCustomer(newBusinessUnitID: string) {
    await this.milesContractPage.clickBtnInFocusedTextBox("Customer");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.enterValueByLabel(
      CUSTOMER_OR_COST_CENTRE_LABELS.BUSINESS_PARTNER_ID,
      newBusinessUnitID,
      1,
    );
    await this.milesContractPage.btnSearch.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.btnOK.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.closeBtnMsgCollapser();
  }

  async selectDriver(driverID: string) {
    await this.milesContractPage.clickBtnInFocusedTextBox("Quote Driver");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.enterValueByLabel(
      DRIVER_SEARCH_LABELS.ID,
      driverID,
      3,
    );
    await this.milesContractPage.enterValueByLabel(
      DRIVER_SEARCH_LABELS.CONTACT_ROLE,
      "",
      1,
    );
    await this.milesContractPage.enterValueByLabel(
      DRIVER_SEARCH_LABELS.AND_NOT_CONTACT_ROLE,
      "",
      1,
    );
    await this.milesContractPage.btnSearch.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.btnOK.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  async novatedAssetAssignment(newBusinessUnitID: string, driverID: string) {
    await this.selectCustomer(newBusinessUnitID);
    await this.selectDriver(driverID);
  }

  async reNovationAssignment(toCustomer: string) {
    await this.milesContractPage.enterValueByLabel(
      CONTRACT_LABELS.TO_CUSTOMER,
      toCustomer,
    );
    await this.milesContractPage.btnModify.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    if (await this.milesContractPage.btnModify.isVisible()) {
      await this.milesContractPage.btnModify.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
    }
  }

  async changeCustomerSalesRegion(salesRegion: string, driverName: string) {
    await this.milesContractPage.clickBottomTab("CU " + driverName);
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickMenuItem("General");
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.enterValueByLabel(
      CUSTOMER_OR_COST_CENTRE_LABELS.SALES_REGION,
      salesRegion,
      5,
    );
    await this.milesContractPage.clickField(
      CUSTOMER_OR_COST_CENTRE_LABELS.EXTERNAL_REFERENCE,
    );
    await this.milesContractPage.btnSave.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.clickBottomTab("AQ");
    await this.milesContractPage.waitUntilLoadingFinishes();
  }
}
