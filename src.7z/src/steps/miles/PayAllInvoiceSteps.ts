import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesVehicleOrderPage } from "../../pages/miles/MilesVehicleOrderPage";
import { MilesPurchaseInvoicePage } from "../../pages/miles/MilesPurchaseInvoicePage";
import { CONTRACT_LABELS } from "../../../enums/milesapp";
import { CreateNewVehicleOrder } from "./CreateNewVehicleOrderSteps";
import { CreateNewPurchaseInvoice } from "./CreateNewPurchaseInvoiceSteps";

export class PayAllInvoices {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesVehicleOrderPage: MilesVehicleOrderPage;
  milesPurchaseInvoicePage: MilesPurchaseInvoicePage;
  createVehicleOrder: CreateNewVehicleOrder;
  createNewPurchaseInvoice: CreateNewPurchaseInvoice;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesVehicleOrderPage = new MilesVehicleOrderPage(page);
    this.milesPurchaseInvoicePage = new MilesPurchaseInvoicePage(page);
    this.createVehicleOrder = new CreateNewVehicleOrder(page);
    this.createNewPurchaseInvoice = new CreateNewPurchaseInvoice(page);
  }

  async searchValue(ltc: string) {
    await this.milesHomePage.enterAndSelectValueInQuickNavigation(ltc);
    await this.milesHomePage.waitUntilLoadingFinishes();
  }

  /*
  This is similar to handlePendingQuotesInContract in VerifyContractRunningSteps
  */
  async payAllInvoicesFromContract({
    ltc,
    supplier,
  }: {
    ltc: string;
    supplier: string;
  }) {
    const tableName = CONTRACT_LABELS.VEHICLE_ORDERS;
    const tableIndex = -1;
    const referenceColIndex = 0;
    const vehicleOrderTypeColIndex = 1;
    const statusColIndex = 4;
    const listOfStatusesToIgnore = ["Completed", "Cancelled", "Disapproved"];

    await this.searchValue(ltc);
    await this.milesContractPage.btnRefresh.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
    await this.milesContractPage.closeBtnMsgCollapser();
    await this.milesContractPage.waitForTableDataToLoad(tableName);
    let rows = await this.milesContractPage.getNumberOfTableRows(tableName);
    let status, voType;
    let mainIsOK = false;
    for (let rowIndex = 0; rowIndex < rows; rowIndex++) {
      status = await this.milesContractPage.getValueInTableCell(
        tableName,
        tableIndex,
        rowIndex,
        statusColIndex,
      );
      voType = await this.milesContractPage.getValueInTableCell(
        tableName,
        tableIndex,
        rowIndex,
        vehicleOrderTypeColIndex,
      );
      console.log(`Row: ${rowIndex} VOType: ${voType} Status: ${status}`);

      // MAIN VO Case:
      if (voType === "Main") {
        if (!(status === "Cancelled" || status === "Disapproved")) {
          mainIsOK = true;
        }
        // Assumes that a valid Main VO will appear before a Cancelled Main VO
        else if (!mainIsOK) {
          await this.milesContractPage.clickBtnInFocusedTextBox(
            CONTRACT_LABELS.STATUS,
          );
          await this.milesContractPage.selectValueFromDropdown(
            "Pending review",
          );
          await this.milesContractPage.btnSave.click();
          console.log(
            "This contract cannot be used. The status has been updated." +
              status,
          );
          expect(true, "This Contract can't be used").toBeFalsy();
        }
      }
      // Regular VO or valid Main VO:
      if (!listOfStatusesToIgnore.includes(status)) {
        await this.milesContractPage.clickLinkInTableCell(
          tableName,
          tableIndex,
          rowIndex,
          referenceColIndex,
        );
        await this.milesVehicleOrderPage.waitUntilLoadingFinishes();
        await this.milesVehicleOrderPage.closeBtnMsgCollapser(1000);
        switch (status) {
          case "Assessment/Tender":
            await this.handleAssessmentTenderVehicleOrder(supplier);
            break;
          case "Waiting For Approval":
            await this.handleWaitingForApprovalVehicleOrder(supplier);
            break;
          case "Approved":
            await this.handleApprovedVehicleOrder();
            break;
          case "Sent":
            await this.handleSentVehicleOrder();
            break;
          default:
            console.log("New status to handle Test Case Failed: " + status);
            expect(
              true,
              "New VO status to handle Test Case Failed:",
            ).toBeFalsy();
        }
        await this.milesContractPage.clickBottomTab("LTC " + ltc);
        await this.milesContractPage.btnRefresh.waitFor();
        await this.milesContractPage.btnRefresh.click();
        await this.milesContractPage.closeBtnMsgCollapser();
        //reset rowIndex after a row status has updated, as it may create a new VO
        rowIndex = -1;
        await this.milesContractPage.waitForTableDataToLoad(tableName);
        rows = await this.milesContractPage.getNumberOfTableRows(tableName);
      }
    }
  }

  async handleWaitingForApprovalVehicleOrder(supplier: string) {
    await this.createVehicleOrder.createVO(supplier);
    await this.createVehicleOrder.approveVehicleOrder();
    await this.handleSentVehicleOrder();
  }

  async handleAssessmentTenderVehicleOrder(supplier: string) {
    // have not encountered Assessment Tender for non-Main VO yet
    await this.handleWaitingForApprovalVehicleOrder(supplier);
  }

  async handleApprovedVehicleOrder() {
    await this.createVehicleOrder.updateApprovedVOToSent();
    await this.handleSentVehicleOrder();
  }

  async handleSentVehicleOrder() {
    await this.createNewPurchaseInvoice.createNewPurchaseInvoiceFromExistingVO();
    await this.createNewPurchaseInvoice.postPurchaseInvoiceForExistingVO();
  }
}
