import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "../../pages/miles/MilesHomePage";
import { MilesSearchPage } from "../../pages/miles/MilesSearchPage";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesNewSalesRequestPage } from "../../pages/miles/MilesNewSalesRequestPage";
import {
  CUSTOMER_OR_COST_CENTRE_LABELS,
  SEARCH_CONTRACT_LABELS,
  SEARCH_PURCHASE_INVOICE_LABELS,
} from "../../../enums/milesapp";
import moment from "moment";

// These are steps for all search pages, such as Search Contract, Search Purchase Invoice, Search Direct Credit
export class SearchExistingObject {
  milesHomePage: MilesHomePage;
  milesContractPage: MilesContractPage;
  milesSearchPage: MilesSearchPage;
  milesNewSalesRequestPage: MilesNewSalesRequestPage;
  page: Page;

  constructor(page: Page) {
    this.milesHomePage = new MilesHomePage(page);
    this.milesContractPage = new MilesContractPage(page);
    this.milesSearchPage = new MilesSearchPage(page);
    this.milesNewSalesRequestPage = new MilesNewSalesRequestPage(page);
    this.page = page;
  }

  async openAnExistingContract({
    option,
    serviceName,
    product,
    contractStatus,
    billingStatus,
    endDateValue,
    category,
    tradingName,
    vehicle,
    driver,
  }: {
    option: string;
    serviceName?: string;
    product?: string;
    contractStatus: string;
    billingStatus?: string;
    endDateValue?: string;
    category?: string;
    tradingName?: string;
    vehicle?: string;
    driver?: string;
  }) {
    await this.searchExistingContract({
      option,
      serviceName,
      product,
      contractStatus,
      billingStatus,
      endDateValue,
      category,
      tradingName,
      vehicle,
      driver,
    });

    return await this.selectExistingContractFromList();
  }

  async openAnExistingContractFilteredByID({
    option,
    ID,
  }: {
    option: string;
    ID: string;
  }) {
    await this.milesHomePage.homeTab.click();
    await this.searchExistingContractByID({
      option,
      ID,
    });
    return await this.selectExistingContractFromList();
  }

  async searchExistingContract({
    option,
    serviceName,
    product,
    contractStatus,
    billingStatus,
    endDateValue,
    category,
    tradingName,
    vehicle,
    driver,
  }: {
    option: string;
    serviceName?: string;
    product?: string;
    contractStatus: string;
    billingStatus?: string;
    endDateValue?: string;
    category?: string;
    tradingName?: string;
    vehicle?: string;
    driver?: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    if (serviceName) {
      await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.SERVICE_NAME,
        serviceName,
      );
    }
    if (product) {
      await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.PRODUCT,
        product,
      );
    }
    await this.milesSearchPage.enterContractStatus(contractStatus);
    if (billingStatus) {
      await this.milesSearchPage.enterBillingStatus(billingStatus);
    }
    if (endDateValue) {
      await this.milesSearchPage.enterValueByLabel(
        SEARCH_CONTRACT_LABELS.END_DATE,
        `${endDateValue}`,
        1,
      );
    }
    if (category) {
      await this.milesSearchPage.enterValueByLabel(
        SEARCH_CONTRACT_LABELS.CATEGORY,
        category,
        1,
      );
    }
    if (tradingName) {
      await this.milesSearchPage.enterValueByLabel(
        SEARCH_CONTRACT_LABELS.CUSTOMER_NAME,
        tradingName,
        1,
      );
    }
    if (vehicle) {
      await this.milesSearchPage.enterValueByLabel(
        SEARCH_CONTRACT_LABELS.VEHICLE_DESCRIPTION,
        vehicle,
        1,
      );
    }
    if (driver) {
      await this.milesSearchPage.enterValueByLabel(
        SEARCH_CONTRACT_LABELS.DRIVER_NAME,
        driver,
        1,
      );
    }
    // last thing to do before Search. Clear ID field of automation junk
    await this.milesSearchPage.enterValueByLabel(
      SEARCH_CONTRACT_LABELS.ID,
      "",
      1,
    );
    await this.milesSearchPage.btnSearch.click();
  }

  async searchExistingContractByID({
    option,
    ID,
  }: {
    option: string;
    ID: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.ID,
      ID,
    );
    await this.milesSearchPage.btnSearch.click();
  }

  async selectExistingContractFromList() {
    await this.milesSearchPage.searchResultList.waitFor();
    await this.milesSearchPage.openFirstObjectFromList();
    await expect(
      this.milesNewSalesRequestPage.contractReferenceNumber,
    ).toBeVisible({ timeout: 10000 });
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    const refNum =
      await this.milesNewSalesRequestPage.contractReferenceNumber.inputValue();
    return refNum;
  }

  async getOldestContractFromList() {
    await this.milesSearchPage.searchResultList.waitFor();
    await this.milesSearchPage.btnLast.click();
    await this.milesSearchPage.searchResultList.waitFor();
    await this.milesSearchPage.sortAscending("ID");
    await this.milesSearchPage.selectFirstRowFromTable();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesNewSalesRequestPage.closeBtnMsgCollapser();
    await expect(
      this.milesNewSalesRequestPage.contractReferenceNumber,
    ).toBeVisible({ timeout: 10000 });
    const refNum =
      await this.milesNewSalesRequestPage.contractReferenceNumber.inputValue();
    return refNum;
  }

  //Please don't modify - Required in Quomo available balance testing
  async retrieveExistingRefinanceOrFormalExtContractID({
    option,
    reference,
    product,
    customer,
    contractOperator,
    contractValue,
    endDateOperator,
    fromEndDateValue,
    toEndDateValue,
    billingOperator,
    billingValue,
    vehicleSourceOperator,
    vehicleSourceValue,
    fundingArrangement,
    netRentalDescription,
    firstRegDate,
  }: {
    option: string;
    reference?: string;
    product: string;
    customer?: string;
    contractOperator: string;
    contractValue: string;
    endDateOperator: string;
    fromEndDateValue: string;
    toEndDateValue: string;
    billingOperator: string;
    billingValue: string;
    vehicleSourceOperator?: string;
    vehicleSourceValue?: string;
    fundingArrangement?: string;
    netRentalDescription?: string;
    firstRegDate?: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    !!reference &&
      (await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.REFERENCE,
        reference,
      ));
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.PRODUCT,
      product,
    );
    !!customer &&
      (await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.CUSTOMER_NAME,
        customer,
      ));
    await this.milesSearchPage.enterOperatorsByLabel({
      label: SEARCH_CONTRACT_LABELS.CONTRACT_STATUS,
      operator: contractOperator,
    });
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.CONTRACT_STATUS,
      contractValue,
    );
    await this.milesSearchPage.enterOperatorsByLabel({
      label: SEARCH_CONTRACT_LABELS.END_DATE,
      operator: endDateOperator,
    });
    await this.milesSearchPage.enterValueByLabel(
      SEARCH_CONTRACT_LABELS.END_DATE,
      `${fromEndDateValue}, ${toEndDateValue}`,
      1,
    );
    await this.milesSearchPage.enterOperatorsByLabel({
      label: SEARCH_CONTRACT_LABELS.BILLABLE_STATUS,
      operator: billingOperator,
    });
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.BILLABLE_STATUS,
      billingValue,
    );
    vehicleSourceOperator &&
      (await this.milesSearchPage.enterOperatorsByLabel({
        label: SEARCH_CONTRACT_LABELS.CONFIGVEHICLE_VEHICLESOURCE,
        operator: vehicleSourceOperator,
      }));
    vehicleSourceValue &&
      (await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.CONFIGVEHICLE_VEHICLESOURCE,
        vehicleSourceValue,
      ));
    if (fundingArrangement) {
      await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.FUNDING_ARRANGEMENT,
        fundingArrangement,
      );
    }
    if (netRentalDescription) {
      await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.LEASESERVICECOMPONENTS_NETRENTAL_DESCRIPTION,
        netRentalDescription,
      );
    }
    if (firstRegDate) {
      await this.milesSearchPage.enterDetailsByLabel(
        SEARCH_CONTRACT_LABELS.FIRST_REGISTRATION_DATE,
        firstRegDate,
      );
    }
    // Clear the ID field, because automation often puts stuff in there
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.ID,
      "",
    );
    await this.milesSearchPage.btnSearch.click();
    await this.milesSearchPage.searchResultList.waitFor();
    vehicleSourceValue == "Dealer" &&
      (await this.milesSearchPage.sortReferenceColumn());
    const contractID =
      await this.milesSearchPage.retrieveContractDetailsFromTable("ID");
    console.log(contractID);

    const contractReference =
      await this.milesSearchPage.retrieveContractDetailsFromTable("Reference");
    console.log(contractReference);
    const customerName =
      await this.milesSearchPage.retrieveContractDetailsFromTable(
        "Customer name",
      );
    console.log(customerName);
    return { contractID, contractReference, customerName };
  }

  async searchExistingContractForFormalExtension({
    option = "Find Novated Contract",
    customerName = "",
    endDateOperator = "Between",
    fromEndDateValue = moment().format("DD/MM/YYYY 00:00"),
    toEndDateValue = moment().add(1, "month").format("DD/MM/YYYY 00:00"),
    contractStatus = "Running",
  }: {
    option?: string;
    customerName?: string;
    endDateOperator?: string;
    fromEndDateValue?: string;
    toEndDateValue?: string;
    contractStatus?: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.CUSTOMER_NAME,
      customerName,
    );
    await this.milesSearchPage.enterContractStatus(contractStatus);
    await this.milesSearchPage.enterOperatorsByLabel({
      label: SEARCH_CONTRACT_LABELS.END_DATE,
      operator: endDateOperator,
    });
    await this.milesSearchPage.enterValueByLabel(
      SEARCH_CONTRACT_LABELS.END_DATE,
      `${fromEndDateValue}, ${toEndDateValue}`,
      1,
    );
    await this.milesSearchPage.btnSearch.click();
  }

  async getExistingContractWithLeaseGuardService({
    option,
    product,
    serviceName,
    contractStatus,
  }: {
    option: string;
    product: string;
    serviceName: string;
    contractStatus: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.PRODUCT,
      product,
    );
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.SERVICE_NAME,
      serviceName,
    );
    await this.milesSearchPage.enterContractStatus(contractStatus);
    await this.milesSearchPage.btnSearch.click();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.searchResultList.waitFor();
    return await this.getOldestContractFromList();
  }

  async searchCustomer(tradingName: string) {
    await this.milesSearchPage.enterDetailsByLabel(
      CUSTOMER_OR_COST_CENTRE_LABELS.TRADING_NAME,
      tradingName,
    );
    await this.milesSearchPage.btnSearch.click();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
  }

  async openFirstResultFromBlankSearch(option: string) {
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.btnSearch.click();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    await this.milesSearchPage.openFirstObjectFromList();
  }

  async getAndOpenExistingContractAfterJobRun({
    option,
    customerName,
    contractStatus,
    startDate,
    billableStatus,
  }: {
    option: string;
    customerName: string;
    contractStatus: string;
    startDate: string;
    billableStatus: string;
  }) {
    await this.milesHomePage.contractsTab.click();
    await this.milesContractPage.longTermContracts.click();
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_CONTRACT_LABELS.CUSTOMER_NAME,
      customerName,
    );
    await this.milesSearchPage.enterValueByLabel(
      SEARCH_CONTRACT_LABELS.BILLABLE_STATUS,
      billableStatus,
      1,
    );
    await this.milesSearchPage.enterContractStatus(contractStatus);
    await this.milesSearchPage.enterValueByLabel(
      SEARCH_CONTRACT_LABELS.START_DATE,
      startDate,
      1,
    );
    await this.milesSearchPage.btnSearch.click();
    return await this.selectExistingContractFromList();
  }

  async searchSupplierInvoices({
    option,
    invoiceStatuses,
  }: {
    option: string;
    invoiceStatuses: string;
  }) {
    await this.milesSearchPage.selectionBox.click();
    await this.milesSearchPage.selectionDropdownIcon.click();
    await this.milesSearchPage.selectValueFromDropdown(option);
    await this.page.waitForLoadState("domcontentloaded");
    await this.milesSearchPage.enterDetailsByLabel(
      SEARCH_PURCHASE_INVOICE_LABELS.INVOICE_STATUS,
      invoiceStatuses,
    );
    await this.milesSearchPage.btnSearch.click();
    await this.milesSearchPage.waitUntilLoadingFinishes();
    const rows = await this.milesSearchPage.getNumberOfTableRows(
      "Search Results",
      -1,
    );
    for (let i = 0; i < rows; i++) {
      const disputeReason = await this.milesSearchPage.getTableCellLocator(
        "Search Results",
        -1,
        i,
        12,
      );
      if ((await disputeReason.innerText()) == "") {
        const PILink = await this.milesSearchPage.getTableCellLocator(
          "Search Results",
          -1,
          i,
          2,
        );
        await PILink.click();
        await this.milesSearchPage.waitUntilLoadingFinishes();
        break;
      }
    }
  }
}
