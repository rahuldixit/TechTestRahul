import { Page, expect } from "@playwright/test";
import { MilesHomePage } from "pages/miles/MilesHomePage";
import { MilesPurchaseInvoicePage } from "pages/miles/MilesPurchaseInvoicePage";
import { PURCHASE_INVOICE_LABELS } from "../../../enums/milesapp";

export class AccountsPayable {
  readonly page: Page;
  milesHomePage: MilesHomePage;
  milesPurchaseInvoicePage: MilesPurchaseInvoicePage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
    this.milesPurchaseInvoicePage = new MilesPurchaseInvoicePage(page);
  }

  async goToAccountsPayable() {
    await this.milesHomePage.clickHorizontalPortalNav("Accounting");
    await this.milesHomePage.clickHorizontalPortalNav("Accounts Payable");
  }

  async goToAPDirectCredit() {
    await this.goToAccountsPayable();
    await this.milesHomePage.clickHorizontalPortalNav("Direct Credit");
    await this.milesHomePage.clickHorizontalPortalNav("Direct Credit");
  }

  async goToAPPurchaseInvoices() {
    await this.goToAccountsPayable();
    await this.milesHomePage.clickHorizontalPortalNav("Purchase Invoices");
  }

  async goToAPCreateDirectCreditPayment() {
    await this.goToAccountsPayable();
    await this.milesHomePage.clickHorizontalPortalNav("Direct Credit");
    await this.milesHomePage.clickHorizontalPortalNav(
      "Create Direct Credit Payment",
    );
  }

  async clickCreditNoteInDesputeSection(disputeReason: string) {
    await this.milesPurchaseInvoicePage.clickMenuItem(
      PURCHASE_INVOICE_LABELS.CONTENTS,
    );
    await this.milesPurchaseInvoicePage.btnDispute.waitFor();
    await this.selectInvoiceLineWithRechargeAmount();
    const classStatus =
      await this.milesPurchaseInvoicePage.btnDispute.getAttribute("class");
    // IF the Dispute menu/button is disabled
    if (classStatus && classStatus.includes("Disabled")) {
      expect(
        true,
        "Dispute button is Disabled. Test Case cannot proceed.",
      ).toEqual(false);
    }
    await this.milesPurchaseInvoicePage.btnDispute.click({ force: true });
    await this.milesPurchaseInvoicePage.selectValueFromDropdown(disputeReason);
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.handleNoActiveBankAccountError(disputeReason);
    await this.milesPurchaseInvoicePage.btnCreditNote.click();
    await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
    await this.handleInvoiceDoesNotHaveInvoicedItemsError();
  }

  async selectInvoiceLineWithRechargeAmount() {
    const tableName = "Invoice Lines";
    const tableIndex = 1;
    const tableIndexCheckbox = 0;
    const tickboxColIndex = 0;
    const rechargeAmountIndex = 4;
    let rechargeAmount;
    let hasFoundInvoiceLine = false;
    await this.milesPurchaseInvoicePage.waitForTableDataToLoad(
      tableName,
      tableIndex,
    );
    const rows = await this.milesPurchaseInvoicePage.getNumberOfTableRows(
      tableName,
      tableIndex,
    );
    // Check each row until you find a Recharge Amount or run out of rows
    console.log("rows: " + rows);
    if (rows > 1) {
      for (
        let rowIndex = 0;
        rowIndex < rows && !hasFoundInvoiceLine;
        rowIndex++
      ) {
        rechargeAmount =
          await this.milesPurchaseInvoicePage.getValueInTableCell(
            tableName,
            tableIndex,
            rowIndex,
            rechargeAmountIndex,
          );
        console.log("Recharge Amount: " + rechargeAmount);
        if (!rechargeAmount) {
          await this.milesPurchaseInvoicePage.untickTableCheckbox(
            tableName,
            tableIndexCheckbox,
            rowIndex,
            tickboxColIndex,
          );
        } else {
          await this.milesPurchaseInvoicePage.tickTableCheckbox(
            tableName,
            tableIndexCheckbox,
            rowIndex,
            tickboxColIndex,
          );
          hasFoundInvoiceLine = true;
        }
      }
    }
  }

  async handleNoActiveBankAccountError(disputeReason: string) {
    const errormsg = await this.milesPurchaseInvoicePage.getSystemErrorMsg();
    if (errormsg.includes("No active bank account was found for invoice")) {
      await this.milesPurchaseInvoicePage.dismissSystemDialog();
      await this.milesPurchaseInvoicePage.clickMenuItem(
        PURCHASE_INVOICE_LABELS.GENERAL,
      );
      await this.milesPurchaseInvoicePage.enterValueByLabel2(
        PURCHASE_INVOICE_LABELS.BANK_ACCOUNT,
        "",
      );
      await this.milesPurchaseInvoicePage.clickOut(
        PURCHASE_INVOICE_LABELS.INVOICE_TYPE,
      );
      await this.milesPurchaseInvoicePage.btnSave.click();
      await this.milesPurchaseInvoicePage.waitUntilLoadingFinishes();
      await this.clickCreditNoteInDesputeSection(disputeReason);
    }
  }

  async handleInvoiceDoesNotHaveInvoicedItemsError() {
    const errormsg = await this.milesPurchaseInvoicePage.getSystemErrorMsg();
    if (
      errormsg.includes(
        "The specified incoming invoice does not have any invoiced items that are 'credit note required'.",
      )
    ) {
      await this.milesPurchaseInvoicePage.dismissSystemDialog();
      await this.milesPurchaseInvoicePage.clickMenuItem(
        PURCHASE_INVOICE_LABELS.GENERAL,
      );
      await this.milesPurchaseInvoicePage.clickBtnInFocusedTextBox(
        PURCHASE_INVOICE_LABELS.STATUS,
      );
      // Attempt to update the status, so that this PI will not appear in search filter
      await this.milesPurchaseInvoicePage.selectValueFromDropdown("Finalized");
      await this.milesPurchaseInvoicePage.btnSave.click();
      expect(true, "Purchase Invoice not valid for this test case").toEqual(
        false,
      );
    }
  }
}
