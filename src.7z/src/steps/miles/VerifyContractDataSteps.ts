import { Page, expect } from "@playwright/test";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { MilesSalesInvoicePage } from "pages/miles/MilesSalesInvoicePage";
import { CONTRACT_LABELS, SALES_INVOICES } from "../../../enums/milesapp";

// These are steps for all search pages, such as Search Contract, Search Purchase Invoice, Search Direct Credit
export class ContractDataSteps {
  page: Page;
  milesContractPage: MilesContractPage;
  milesSalesInvoice: MilesSalesInvoicePage;

  constructor(page: Page) {
    this.page = page;
    this.milesContractPage = new MilesContractPage(page);
    this.milesSalesInvoice = new MilesSalesInvoicePage(page);
  }

  async getPreviousWorkday() {
    return await this.milesContractPage.getPreviousWorkday();
  }

  async goToBillingOverviewFromLTC() {
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.FINANCIAL);
    await this.milesContractPage.clickMenuItem(
      CONTRACT_LABELS.BILLING_OVERVIEW,
    );
  }

  // LTC > Financial > Billing Overview
  async selectServiceTypeAndSearch(serviceType: string) {
    await this.milesContractPage.dropdownServiceType.click();
    await this.milesContractPage.enterValueByLocator({
      locator: this.milesContractPage.dropdownServiceType,
      value: serviceType,
    });
    await this.milesContractPage.btnSearch.click();
    await this.milesContractPage.waitUntilLoadingFinishes();
  }

  // LTC > Financial > Billing Overview
  async verifyInvoiceNRIsPopulated() {
    const tableName = "Search Results";
    const tableIndex = -1;
    const invoiceNrColumn = 0;
    await this.milesContractPage.waitForTableDataToLoad(tableName);
    const rows = await this.milesContractPage.getNumberOfTableRows(tableName);
    let valueFound = false;
    for (let row = 0; row < rows && !valueFound; row++) {
      const value = await this.milesContractPage.getValueInTableCell(
        tableName,
        tableIndex,
        row,
        invoiceNrColumn,
      );
      if (value) {
        console.log("Invoice:" + value);
        valueFound = true;
      }
    }
    expect(valueFound, "No invoice found").toBe(true);
  }

  // Starts in LTC > Financial > Billing Overview
  // First use verifyInvoiceNRIsPopulated()
  async verifyCusInvoiceNumberIsPopulated(value: string) {
    const tableName = "Search Results";
    const tableIndex = -1;
    const rowIndex = 0;
    const invoiceNrColumn = 0;
    const salesInvoiceLink = await this.milesContractPage.getTableCellLocator(
      tableName,
      tableIndex,
      rowIndex,
      invoiceNrColumn,
    );
    await salesInvoiceLink.click();
    const cusInvoiceNumber = await this.milesSalesInvoice.retrieveValueByLabel(
      SALES_INVOICES.CUS_INVOICE_NUMBER,
    );
    expect(
      cusInvoiceNumber,
      "Cus Invoice Number has incorrect value",
    ).toContain(value);
  }
}
