import { Page, expect } from "@playwright/test";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { ModifyContract } from "../../steps/miles/ModifyContractSteps";
import { LEASE_SERVICE_LABELS, CONTRACT_LABELS } from "../../../enums/milesapp";

export class VerifyContractRunning {
  readonly page: Page;
  milesContractPage: MilesContractPage;
  modifyContract: ModifyContract;

  constructor(page: Page) {
    this.page = page;
    this.milesContractPage = new MilesContractPage(page);
    this.modifyContract = new ModifyContract(page);
  }

  /*
  Refreshes the Contract so that it goes into Running Status. 
  It does not check for Full Billing.
  It does not check if there are any open orders or pending quotes
  Those verifications can be done afterwards
  */
  async verifyContractRunningStatus({ ltc }: { ltc: string }) {
    await this.milesContractPage.enterAndSelectValueInQuickNavigation(ltc);
    const status = await this.milesContractPage.retrieveValueByLabel(
      CONTRACT_LABELS.STATUS,
    );
    if (status === "Initialized") {
      await this.milesContractPage.btnRefresh.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
      await this.milesContractPage.closeBtnMsgCollapser();
    }
    expect(
      await this.milesContractPage.retrieveValueByLabel(CONTRACT_LABELS.STATUS),
    ).toContain("Running");
  }

  /*
  Refreshes the contract if required. Then handles Pending Quotes in order to 
  get the contract in Full Billing status (in Billable field)
  */
  async verifyContractRunningAndFullBilling({ ltc }: { ltc: string }) {
    await this.verifyContractRunningStatus({ ltc });
    await this.handlePendingQuotesInContract();
    const status = await this.milesContractPage.retrieveValueByLabel(
      CONTRACT_LABELS.BILLABLE,
    );
    if (status != "Full Billing") {
      await this.milesContractPage.btnRefresh.click();
      await this.milesContractPage.waitUntilLoadingFinishes();
      await this.milesContractPage.closeBtnMsgCollapser();
    }
    expect(
      await this.milesContractPage.retrieveValueByLabel(
        CONTRACT_LABELS.BILLABLE,
      ),
    ).toEqual("Full Billing");
  }

  async verifyFreeform(type: string) {
    expect(
      await this.milesContractPage.vehicleOrderTypeFirstRowInVO.innerText(),
    ).toEqual(type);
  }

  async verifyManualOverride(rvOverrideStatus: string) {
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.LEASE_SERVICE);
    const rvOverrideStatusActual =
      await this.milesContractPage.retrieveValueByLabel(
        LEASE_SERVICE_LABELS.RV_OVERRIDE_STATUS,
      );
    const manualRVOverride = await this.milesContractPage.retrieveValueByLabel(
      LEASE_SERVICE_LABELS.MANUAL_RV_OVERRIDE,
    );
    expect(rvOverrideStatusActual).toEqual(rvOverrideStatus);
    expect(manualRVOverride).toBeTruthy();
  }

  async verifyManualInterestMargin(manualInterestStatus: string) {
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.LEASE_SERVICE);
    await this.milesContractPage.clickHorizontalTab(LEASE_SERVICE_LABELS.MORE);
    const manualInterestStatusActual =
      await this.milesContractPage.retrieveValueByLabel(
        LEASE_SERVICE_LABELS.MANUAL_INTEREST_STATUS,
      );
    const manualStandardInterestMargin =
      await this.milesContractPage.retrieveValueByLabel(
        LEASE_SERVICE_LABELS.MANUAL_STANDARD_INTEREST_MARGIN,
      );
    expect(manualInterestStatusActual).toEqual(manualInterestStatus);
    expect(manualStandardInterestMargin).toBeTruthy();
  }

  async verifyPendingQuotesIsEmpty() {
    await expect(this.milesContractPage.pendingQuotesEmptyMsg).toBeVisible();
  }

  async verifyPendingQuotesIsNotEmpty() {
    await expect(
      this.milesContractPage.pendingQuotesEmptyMsg,
    ).not.toBeVisible();
  }

  /* 
  On the Contract page check for any Pending Quotes
  Click on the first one and Validate, Approve, Create Contract
  Come back to the LTC and Refresh. It should not have that Pending Quote anymore
  Keep going until there are no Pending Quotes
  */
  async handlePendingQuotesInContract() {
    const tableName = CONTRACT_LABELS.PENDING_QUOTES;
    const tableIndex = 1;
    const firstRow = 0;
    const statusIndex = 2;
    const quoteReferenceIndex = 0;
    let hasExistingPendingQuotes = true;
    const rows = await this.milesContractPage.getNumberOfTableRows(
      tableName,
      tableIndex,
    );
    let status;
    for (let i = 0; i < rows && hasExistingPendingQuotes; i++) {
      status = await this.milesContractPage.getValueInTableCell(
        tableName,
        tableIndex,
        firstRow,
        statusIndex,
      );
      if (status === "Waiting") {
        await this.milesContractPage.clickLinkInTableCell(
          tableName,
          tableIndex,
          firstRow,
          quoteReferenceIndex,
        );
        await this.modifyContract.validateApproveContractFromQuoteOrAQ();
        await this.milesContractPage.clickBottomTab("LTC");
        await this.milesContractPage.btnRefresh.waitFor();
        await this.milesContractPage.btnRefresh.click();
        await this.milesContractPage.waitUntilLoadingFinishes();
        // Row that had the Waiting Quote will disappear from the table
        if (await this.milesContractPage.pendingQuotesEmptyMsg.isVisible()) {
          hasExistingPendingQuotes = false;
        }
      }
    }
  }
}
