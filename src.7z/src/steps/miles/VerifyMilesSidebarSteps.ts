import { Page, expect } from "@playwright/test";
import { MilesSideBarPage } from "../../pages/miles/MilesSideBarPage";

export class VerifyMilesSideBar {
  milesSideBarPage: MilesSideBarPage;
  page: Page;

  constructor(page: Page) {
    this.milesSideBarPage = new MilesSideBarPage(page);
    this.page = page;
  }

  async verifyUpdatePackageButtonInMilesSidebar() {
    await this.page.waitForTimeout(5000);
    const isavailable =
      await this.milesSideBarPage.btnUpdatePackage.isVisible();
    if (!isavailable) {
      console.log(
        "This contract doesn't have update package. Please retry with a new end date",
      );
    }
    await this.milesSideBarPage.btnUpdatePackage.click();
    await expect(this.milesSideBarPage.updatePackageDropdown).toBeVisible({
      timeout: 5000,
    });
  }

  async verifyCreatePackageButtonInMilesSidebar() {
    const isavailable =
      await this.milesSideBarPage.btncreatePackage.isVisible();
    if (!isavailable) {
      console.log(
        "This contract doesn't have create package. Please retry with a new end date",
      );
    }
    await expect(this.milesSideBarPage.btncreatePackage).toBeVisible();
  }

  async verifyPageTitles() {
    await expect(this.milesSideBarPage.accountInformation).toBeVisible();
    await expect(this.milesSideBarPage.packageInformation).toBeVisible();
  }

  async verifyAccountInformationInMilesSidebar(fieldName: string) {
    return await this.milesSideBarPage.retrieveContractInformation(fieldName);
  }

  async verifyPackageInformationInMilesSidebar(fieldName: string) {
    return await this.milesSideBarPage.retrieveContractInformation(fieldName);
  }

  async verifyPackageBalanceDetailsInMilesSidebar() {
    await expect(this.milesSideBarPage.packageBalance).toBeVisible();
    await expect(this.milesSideBarPage.packageService).toBeVisible();
    await this.milesSideBarPage.waitUntilPackageBalanceLoads();
  }

  async retrieveActualBalanceFromPackageInMilesSidebar() {
    return await this.milesSideBarPage.retrieveActualBalance();
  }

  async retrieveAvailableBalanceFromPackageInMilesSidebar() {
    return await this.milesSideBarPage.retrieveAvailableBalance();
  }

  async retrievePendingBalanceFromPackageInMilesSidebar() {
    return await this.milesSideBarPage.retrievePendingBalance();
  }

  async retrieveAvailableBalanceOfAllServices() {
    return await this.milesSideBarPage.retrieveAvailableBalanceByServiceNameFromPackageBalance();
  }

  async verifyBalances(
    balanceA: { servicename: string; availBal: string }[],
    balanceB: { servicename: string; availBal: string }[],
  ) {
    const balances: {
      [key: string]: { servicename: string; availBal: string }[];
    } = {};
    balances["balance0"] = balanceA;
    balances["balance1"] = balanceB;

    // Update data so it can be compared
    for (let i = 0; i < 2; i++) {
      for (let k = 0; k < balances["balance" + i].length; k++) {
        const name = balances["balance" + i][k].servicename.replace(":", "");
        balances["balance" + i][k].servicename = name;
        if (balances["balance" + i][k].servicename === "Registration & CTP") {
          balances["balance" + i][k].servicename = "Registration";
        }
        if (
          balances["balance" + i][k].servicename === "Comprehensive Insurance"
        ) {
          balances["balance" + i][k].servicename = "Insurance";
        }
        if (balances["balance" + i][k].servicename === "Carbon Offset") {
          balances["balance" + i][k].servicename = "Carbon Product";
        }
        if (balances["balance" + i][k].availBal === "$0.00") {
          balances["balance" + i].splice(k, 1);
          k--;
        }
      }
    }
    console.log("The updated balance in the first balance is", balanceA);
    console.log("The updated balance in the second balance is", balanceB);

    // below line of code doesn't work if the objects aren't in the same order
    //expect(_.isEqual(balances['balance0'], balances['balance1'])).toBe(true);

    let balanceVerified = true;
    for (let i = 0; i < balanceA.length && balanceVerified; i++) {
      let rowVerified = false;
      for (let k = 0; k < balanceB.length && !rowVerified; k++) {
        if (balanceA[i].servicename === balanceB[k].servicename) {
          if (balanceA[i].availBal === balanceB[k].availBal) {
            rowVerified = true; // exit inner loop as soon as the row passes
          }
        }
      } // finished checking all rows in balanceB
      if (!rowVerified) {
        balanceVerified = false; // exit outer loop as soon as it fails
      }
    }
    expect(balanceVerified).toBe(true);
  }
}
