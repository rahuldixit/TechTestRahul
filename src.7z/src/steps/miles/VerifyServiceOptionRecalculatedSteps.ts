import { Page, expect } from "@playwright/test";
import { MilesContractPage } from "../../pages/miles/MilesContractPage";
import { ModifyContract } from "./ModifyContractSteps";
import { MilesNewSalesRequestPage } from "pages/miles/MilesNewSalesRequestPage";
import { CONTRACT_LABELS } from "../../../enums/milesapp";

export class VerifyServiceOptionRecalculated {
  readonly page: Page;
  milesContractPage: MilesContractPage;
  modifyContract: ModifyContract;
  milesRequestPage: MilesNewSalesRequestPage;

  constructor(page: Page) {
    this.page = page;
    this.milesContractPage = new MilesContractPage(page);
    this.modifyContract = new ModifyContract(page);
    this.milesRequestPage = new MilesNewSalesRequestPage(page);
  }

  async verifyServiceOptionRecalculated({
    ltc,
    serviceOption,
  }: {
    ltc: string;
    serviceOption: string;
  }) {
    await this.milesContractPage.enterAndSelectValueInQuickNavigation(ltc);
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.VERSIONS);
    await this.milesRequestPage.bottomContractVersion.click();
    await this.milesContractPage.btnCompare.click({ force: true });
    await this.milesContractPage.waitUntilLoadingFinishes();
    const { leftValue, rightValue } =
      await this.milesContractPage.getLeftAndRightValuesInQuoteDetailsComparison(
        serviceOption,
        true,
      );
    if (leftValue === rightValue) {
      await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.LEASE_SERVICE);
      await this.milesContractPage.verifyRecalculateIsTickedInLeaseService(
        serviceOption,
      );
    } else {
      expect(leftValue).not.toEqual(rightValue);
    }
    await this.milesContractPage.clickMenuItem(CONTRACT_LABELS.GENERAL);
  }
}
