import { Page } from "@playwright/test";
import { MilesHomePage } from "pages/miles/MilesHomePage";

export class VerifyThirdPartyRenoSteps {
  readonly page: Page;
  readonly milesHomePage: MilesHomePage;

  constructor(page: Page) {
    this.page = page;
    this.milesHomePage = new MilesHomePage(page);
  }

  async goToBusinessPartner() {
    await this.milesHomePage.clickHorizontalPortalNav("Relation Management");
    await this.milesHomePage.clickHorizontalPortalNav("Business Partners");
    await this.milesHomePage.clickHorizontalPortalNav("Business Partner");
  }
}
