import { Page } from "@playwright/test";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";
import { NBAHomePage } from "../../pages/nba/NBAHomePage";

export class LoginNBA {
  msLogin: MsOnlineLoginPage;
  nbaHome: NBAHomePage;
  readonly page: Page;

  constructor(page: Page) {
    this.msLogin = new MsOnlineLoginPage(page);
    this.nbaHome = new NBAHomePage(page);
    this.page = page;
  }

  async loginIntoNBA(url: string, email: string, password: string) {
    await this.page.goto(url, { timeout: 30000 });
    await this.msLogin.doLogin(email, password);
    await this.nbaHome.loggedUser.isVisible();
  }
}
