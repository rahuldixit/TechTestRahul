import { Page, expect } from "@playwright/test";
import { NBAHomePage } from "../../pages/nba/NBAHomePage";
import { readDataFromExcel } from "../../../utils/excelReader";

export class RetrieveSpecificContract {
  page: Page;
  nbaHomePage: NBAHomePage;

  constructor(page: Page) {
    this.page = page;
    this.nbaHomePage = new NBAHomePage(page);
  }

  async selectContractToRetrieveType(contractID: string) {
    await this.page.waitForLoadState("domcontentloaded");
    await this.nbaHomePage.specifiedContractRadioBtn.click();
    await this.nbaHomePage.specifyContractID.fill(contractID);
    await this.nbaHomePage.btnRetrieve.click();
    await expect(this.nbaHomePage.contractCheckbox).toBeChecked({
      timeout: 30000,
    });
  }

  async downloadAndReadFile() {
    const filePath = await this.nbaHomePage.downloadContractDetailsToExcel();
    if (filePath && (await readDataFromExcel(filePath))) {
      console.log("File verification is in progress");
    } else {
      throw new Error("File download has failed.Please retry");
    }
  }
}
