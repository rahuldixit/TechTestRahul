import { Page, expect } from "@playwright/test";
import { IMSViewIssuePage } from "../../pages/ims/IMSViewIssuePage";
import { QuomoNovatedPage } from "../../pages/quomo/QuomoNovatedQuotingPage";
import { QuomoVehicleResultsPage } from "../../pages/quomo/QuomoVehicleResultsPage";
import { QuomoIndicativeQuotePage } from "../../pages/quomo/QuomoIndicativeQuotePage";
import { faker } from "@faker-js/faker";
import moment from "moment";

export class CreateQuote {
  page: Page;
  imsViewIssuePage: IMSViewIssuePage;
  quomoNovatedPage: QuomoNovatedPage;
  quomoVehicleResultsPage: QuomoVehicleResultsPage;
  quomoIndicativePage: QuomoIndicativeQuotePage;

  constructor(page: Page) {
    this.page = page;
    this.imsViewIssuePage = new IMSViewIssuePage(page);
    this.quomoNovatedPage = new QuomoNovatedPage(page);
    this.quomoVehicleResultsPage = new QuomoVehicleResultsPage(page);
    this.quomoIndicativePage = new QuomoIndicativeQuotePage(page);
  }

  async getReferenceNumber() {
    const referenceNumber = await this.imsViewIssuePage.issueLink.innerText();
    return referenceNumber;
  }

  async navigateToQuomo() {
    await this.imsViewIssuePage.clickOnQuoteLink();
    await this.quomoNovatedPage.waitFor();
  }

  async submitQuoteAttributes(
    employeeNum: string,
    annualSal: string,
    annualKM: string,
    postCode: string,
    procurementType: string,
    payCycle: string,
    term: string,
    purchaseType: string,
    vehicleSource?: string,
    zlev?: boolean,
  ) {
    await this.fillOutQuoteAttributes(
      employeeNum,
      annualSal,
      annualKM,
      postCode,
      procurementType,
      payCycle,
      term,
      purchaseType,
      vehicleSource,
      zlev,
    );
    /* 
    There are issues with the Continue button. It doesn't click sometimes.
    If it doesn't work the first time, it won't work even after multiple clicks
    This closes the dialog and tries again up to maxAttempts
    */
    const maxAttempts = 5;
    let salaryDialogIsVisible =
      await this.quomoVehicleResultsPage.verifySalaryInfoDialog.isVisible();
    for (
      let attempt = 2;
      attempt <= maxAttempts && !salaryDialogIsVisible;
      attempt++
    ) {
      await this.quomoVehicleResultsPage.btnCancel.click();
      await this.quomoVehicleResultsPage.selectVehicleToConfigure();
      await this.fillOutQuoteAttributes(
        employeeNum,
        annualSal,
        annualKM,
        postCode,
        procurementType,
        payCycle,
        term,
        purchaseType,
        vehicleSource,
        zlev,
      );
      salaryDialogIsVisible =
        await this.quomoVehicleResultsPage.verifySalaryInfoDialog.isVisible();
    }
    expect(
      this.quomoVehicleResultsPage.verifySalaryInfoDialog,
      "Continue button won't click in Quote Atrributes dialog",
      // Just start the test again at this point (or manually click the button by adding a pause before this statement)
    ).toBeVisible();
    await this.quomoVehicleResultsPage.btnConfirm.click();
  }

  async fillOutQuoteAttributes(
    employeeNum: string,
    annualSal: string,
    annualKM: string,
    postCode: string,
    procurementType: string,
    payCycle: string,
    term: string,
    purchaseType: string,
    vehicleSource?: string,
    zlev?: boolean,
  ) {
    await this.quomoVehicleResultsPage.quoteAttributeTitle.waitFor();
    const quoteEmployeeNumber =
      this.quomoVehicleResultsPage.quoteEmployeeNumber;
    const quoteAnnualKm = this.quomoVehicleResultsPage.quoteAnnualKm;
    const quoteAnnualSalary = this.quomoVehicleResultsPage.quoteAnnualSalary;
    await this.quomoVehicleResultsPage.purchaseTypeDropdown.click();
    await this.quomoVehicleResultsPage.selectPurchaseType
      .filter({ hasText: purchaseType })
      .click();
    switch (purchaseType) {
      case "Demo":
        await this.quomoVehicleResultsPage.inputBuildDate.type(
          moment().subtract(2, "years").format("DD/MM/YYYY"),
        );
        await this.quomoVehicleResultsPage.inputRegistrationExpiry.type(
          moment().add(6, "months").format("DD/MM/YYYY"),
        );
        await this.quomoVehicleResultsPage.inputCurrentOdometer.type(
          faker.number.int({ min: 10000, max: 100000 }).toString(),
        );
        break;
      case "Used":
        await this.quomoVehicleResultsPage.inputBuildDate.type(
          moment().subtract(2, "years").format("DD/MM/YYYY"),
        );
        await this.quomoVehicleResultsPage.inputRegistrationExpiry.type(
          moment().add(6, "months").format("DD/MM/YYYY"),
        );
        await this.quomoVehicleResultsPage.inputCurrentOdometer.type(
          faker.number.int({ min: 10000, max: 100000 }).toString(),
        );
        await this.selectVehicleSource(vehicleSource ? vehicleSource : "");
        break;
      default:
        break;
    }
    await this.quomoVehicleResultsPage.typeValueIntoLocator(
      quoteEmployeeNumber,
      employeeNum,
    );
    await this.quomoVehicleResultsPage.typeValueIntoLocator(
      quoteAnnualKm,
      annualKM,
    );
    await this.quomoVehicleResultsPage.selectPostcodeInAttributes(postCode);
    await this.quomoVehicleResultsPage.typeValueIntoLocator(
      quoteAnnualSalary,
      annualSal,
    );
    await this.quomoVehicleResultsPage.procurementTypeDropdown.click();
    await this.quomoVehicleResultsPage.selectProcurement
      .filter({ hasText: procurementType })
      .click();
    await this.quomoVehicleResultsPage.payCycleDropdown.click();
    await this.quomoVehicleResultsPage.selectPayCycle
      .filter({ hasText: payCycle })
      .click();
    const quoteTerm = this.quomoVehicleResultsPage.quoteTerm;
    await this.quomoVehicleResultsPage.typeValueIntoLocator(quoteTerm, term);
    await quoteAnnualSalary.click(); // click-out
    if (zlev) {
      await this.quomoVehicleResultsPage.inputZLEVFirstHeldDate.type(
        moment().subtract(3, "months").format("DD/MM/YYYY"),
      );
      await this.quomoVehicleResultsPage.inputZLEVFirstPurchasePrice.type(
        faker.number.int({ min: 1000, max: 10000 }).toString(),
      );
    }
    await this.quomoVehicleResultsPage.btnContinue.hover();
    await this.quomoVehicleResultsPage.btnContinue.click({ force: true });
  }

  async selectVehicleSource(vehicleSource: string) {
    await this.quomoVehicleResultsPage.dropdownVehicleSource.click();
    await this.quomoVehicleResultsPage.selectDropDownOption(
      vehicleSource,
      this.quomoVehicleResultsPage.selectVehicleSource,
    );
    if (vehicleSource != "Dealer") {
      await this.quomoVehicleResultsPage.inputFBTCostBase.type(
        faker.number.int({ min: 10000, max: 20000 }).toString(),
      );
    }
  }
  async verifyIndicativeQuoteHeader() {
    await this.quomoIndicativePage.quoteHeading.first().waitFor();
    await expect(this.quomoIndicativePage.quoteHeading.first()).toHaveText(
      "Indicative quote",
    );
  }

  async verifyFirmQuoteHeader() {
    await this.quomoIndicativePage.quoteHeading
      .first()
      .waitFor({ state: "visible" });
    await expect(this.quomoIndicativePage.quoteHeading.first()).toHaveText(
      /^Firm(?:\s+refinance)?\s+quote$/,
    );
  }

  async verifyFirmQuoteHeaderExtension() {
    await this.quomoIndicativePage.quoteHeading
      .first()
      .waitFor({ state: "visible" });
    await expect(this.quomoIndicativePage.quoteHeading.first()).toHaveText(
      /^Firm(?:\s+extension)?\s+quote$/,
    );
  }

  async searchVehicle(vehicleModel: string) {
    await this.quomoNovatedPage.selectVehicleMakeandModel(vehicleModel);
    await this.quomoNovatedPage.btnFindCars.click();
    await this.quomoVehicleResultsPage.waitFor();
    await expect(this.quomoVehicleResultsPage.checkPageHeader).toContainText(
      " Vehicle results ",
    );
  }

  async showOrHideSearchScreen() {
    const screenWithSearchHidden = this.page.locator(
      ".ng-star-inserted.twoPanesWithResults",
    );
    await expect(screenWithSearchHidden).toBeVisible();
    await this.quomoVehicleResultsPage.showorHideSearch.click();
    const screenWithSearchDisplayed = this.page.locator(
      ".ng-star-inserted.threePanes",
    );
    await expect(screenWithSearchDisplayed).toBeVisible();
  }

  async showOrHideQuotes() {
    const screenWithSearchDisplayed = this.page.locator(
      ".twoPanesWithSearch.ng-star-inserted",
    );
    await expect(screenWithSearchDisplayed).toBeVisible();
    await this.quomoNovatedPage.expandorCollapseQuotes.click();
    const screenWithSearchHidden = this.page.locator(
      ".ng-star-inserted.onePane",
    );
    await expect(screenWithSearchHidden).toBeVisible();
    await this.quomoNovatedPage.expandorCollapseQuotes.click();
  }

  async expandAndCollapseSearchedVehicles() {
    await this.quomoVehicleResultsPage.btnCollapseAll.click();
    await expect(this.quomoVehicleResultsPage.checkStatus).toBeHidden();
  }

  async verifyConfigureVehicle(vehicleName: string) {
    await this.quomoVehicleResultsPage.selectExpandByVehicleName(vehicleName);
    await this.quomoVehicleResultsPage.selectVehicleToConfigure();
    await expect(
      this.quomoVehicleResultsPage.quoteAttributeTitle,
    ).toBeVisible();
    await this.quomoVehicleResultsPage.btnCancel.click();
  }

  async resetVehicleSearch() {
    await this.quomoVehicleResultsPage.btnReset.click();
    const screenWithSearchDisplayed = this.page.locator(
      ".ng-star-inserted.twoPanesWithSearch",
    );
    await expect(screenWithSearchDisplayed).toBeVisible();
  }

  async createIndicativeQuote({
    vehicleModel,
    vehicleName,
    employeeNum = faker.number.int({ min: 1000, max: 5000 }) + "",
    annualSal = faker.number.int({ min: 100000, max: 250000 }) + "",
    annualKM = faker.number.int({ min: 10000, max: 50000 }) + "",
    postCode,
    procurementType,
    payCycle,
    term,
    purchaseType,
    colour,
    vehicleSource,
    zlev,
  }: {
    vehicleModel: string;
    vehicleName: string;
    employeeNum?: string;
    annualSal?: string;
    annualKM?: string;
    postCode: string;
    procurementType: string;
    payCycle: string;
    term: string;
    purchaseType: string;
    colour?: string;
    vehicleSource?: string;
    zlev?: boolean;
  }) {
    if (zlev) {
      await this.quomoNovatedPage.checkboxZlev.click();
    }
    await this.quomoNovatedPage.selectVehicleMakeandModel(vehicleModel);
    await this.quomoNovatedPage.btnFindCars.click();
    await this.quomoVehicleResultsPage.waitFor();
    await this.quomoVehicleResultsPage.selectExpandByVehicleName(vehicleName);
    await this.quomoVehicleResultsPage.selectVehicleToConfigure();
    await this.submitQuoteAttributes(
      employeeNum,
      annualSal,
      annualKM,
      postCode,
      procurementType,
      payCycle,
      term,
      purchaseType,
      vehicleSource,
      zlev,
    );
    await this.verifyIndicativeQuoteHeader();
    await expect(this.quomoIndicativePage.quoteStatus).toHaveText(
      "In progress",
    );
    await this.page.waitForLoadState("domcontentloaded");
    await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });
    if (purchaseType != "Used" && colour) {
      await this.configureVehicle(colour);
    }
    await this.configureContractComprehensiveInsurance();
  }

  async createCustomerRequestInFuelMaintenanceTyre(
    percentageValue: number,
    variationReason: string,
  ) {
    await this.configureContractFuelServices(percentageValue, variationReason);
    await this.configureContractMaintenanceServices(
      percentageValue,
      variationReason,
    );
    await this.configureContractTyresServices(percentageValue, variationReason);
  }

  async setContractDetails({
    insuranceType,
    insuranceAmount,
    funder,
    leaseGuard,
    zlev,
  }: {
    insuranceType: string;
    insuranceAmount?: string;
    funder: string;
    leaseGuard: string;
    zlev?: boolean;
  }) {
    await this.quomoIndicativePage.contractPane.click();
    await this.selectInsurance(
      insuranceType,
      insuranceAmount ? insuranceAmount : "",
    );
    await this.quomoIndicativePage.selectRadioButton(funder);
    await this.quomoIndicativePage.selectRadioButton(leaseGuard, "LeaseGuard");
    if (zlev) {
      await this.quomoIndicativePage.tabPackageDetails.click();
      await this.quomoIndicativePage.radioButtonZLEVExempt.click();
    }
    await this.quomoIndicativePage.btnSave.click();
  }

  async selectInsurance(insuranceType: string, insuranceAmount: string) {
    await this.quomoIndicativePage.selectRadioButton(
      insuranceType,
      "Comprehensive insurance",
    );
    switch (insuranceType) {
      case "Employee arranged":
        await this.quomoIndicativePage.inputEmployerArrangedInsuranceAmount.clear();
        await this.quomoIndicativePage.inputEmployerArrangedInsuranceAmount.type(
          insuranceAmount,
        );
        break;
      default:
        break;
    }
  }

  async verifyOppurtunityBar(
    employeeName: string,
    mobNum: string,
    payCycle: string,
    customerName: string,
    referenceNumber: string,
    emailAddr: string,
    annualSal: string,
    postCode: string,
    employeeNum: string,
  ) {
    await this.quomoIndicativePage.toggleOppurtunityBar.click();
    expect(this.quomoIndicativePage.employeeName.innerText()).toContain(
      employeeName,
    );
    expect(this.quomoIndicativePage.employeeMobNum.innerText()).toEqual(mobNum);
    expect(this.quomoIndicativePage.employeePayCycle.innerText()).toContain(
      payCycle,
    );
    expect(this.quomoIndicativePage.employer.innerText()).toEqual(customerName);
    expect(this.quomoIndicativePage.getOppurtunityID()).toEqual(
      referenceNumber,
    );
    expect(this.quomoIndicativePage.getEmailAddress()).toEqual(emailAddr);
    expect(this.quomoIndicativePage.getEmployeeAnnualSalary()).toEqual(
      annualSal,
    );
    expect(this.quomoIndicativePage.getEmployeePostcode()).toContain(postCode);
    expect(this.quomoIndicativePage.getEmployeeNumber()).toEqual(employeeNum);
    await this.quomoIndicativePage.toggleOppurtunityBar.click();
  }

  async configureVehicle(colour: string) {
    await this.quomoIndicativePage.carColourSelection(colour);
    await this.quomoIndicativePage.addPaintandTrim.first().click();
    await this.quomoIndicativePage.addPaintandTrim.last().click();
    await this.quomoIndicativePage.btnSave.click({ force: true });
    await this.quomoIndicativePage.indicativeQuoteCard.waitFor();
    await expect(this.quomoIndicativePage.indicativeQuoteStatus).toHaveText(
      "Saved",
    );
  }

  async configureContractComprehensiveInsurance() {
    await this.quomoIndicativePage.contractPane.click();
    await expect(this.quomoIndicativePage.contractDetails).toBeVisible();
    await this.quomoIndicativePage.selectNoInComprehensiveInsurance();
    await this.quomoIndicativePage.btnSave.click();
  }

  async configureContractFuelServices(
    percentageValue: number,
    variationReason: string,
  ) {
    await this.quomoIndicativePage.dropdownVariationReasonInFuel.click();
    await this.quomoIndicativePage.selectDropDownOption(variationReason);
    const fuelAmount: number =
      +(await this.quomoIndicativePage.inputFuelMonthly.inputValue());
    await this.quomoIndicativePage.inputValueInServiceType(
      this.quomoIndicativePage.inputFuelMonthly,
      percentageValue * fuelAmount,
    );
    await this.quomoIndicativePage.btnSave.click();
  }

  async configureContractMaintenanceServices(
    percentageValue: number,
    variationReason: string,
  ) {
    await this.quomoIndicativePage.dropdownVariationReasonInMaintenance.click();
    await this.quomoIndicativePage.selectDropDownOption(variationReason);
    const maintenanceAmount: number =
      +(await this.quomoIndicativePage.inputMaintenanceMonthly.inputValue());
    await this.quomoIndicativePage.inputValueInServiceType(
      this.quomoIndicativePage.inputMaintenanceMonthly,
      maintenanceAmount * percentageValue,
    );
    await this.quomoIndicativePage.btnSave.click();
  }

  async configureContractTyresServices(
    percentageValue: number,
    variationReason: string,
  ) {
    await this.quomoIndicativePage.dropdownVariationReasonInTyres.click();
    await this.quomoIndicativePage.selectDropDownOption(variationReason);
    const tyresAmount: number =
      +(await this.quomoIndicativePage.inputTyresMonthly.inputValue());
    await this.quomoIndicativePage.inputValueInServiceType(
      this.quomoIndicativePage.inputTyresMonthly,
      percentageValue * tyresAmount,
    );
    await this.quomoIndicativePage.btnSave.click();
  }

  async createFirmQuoteRefinance({
    deliveryDate,
    quoteNotes = faker.word.noun(),
  }: {
    deliveryDate?: string;
    quoteNotes?: string;
  } = {}) {
    if (await this.quomoIndicativePage.btnCreateFirm.isDisabled()) {
      await this.quomoIndicativePage.btnSave.click();
    }
    await this.quomoIndicativePage.btnCreateFirm.click();
    await this.quomoIndicativePage.verifyAttributesHeader.waitFor();
    !!deliveryDate &&
      (await this.quomoIndicativePage.preferredDeliveryDate.fill(deliveryDate));
    await this.quomoIndicativePage.notes.fill(quoteNotes);
    await this.quomoIndicativePage.btnContinue.click();
    await this.quomoIndicativePage.firmQuoteCard.waitFor();
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .waitFor({ timeout: 500000 });
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();
    if (await this.quomoIndicativePage.modalDialogTitle.isVisible()) {
      const modalTitle =
        await this.quomoIndicativePage.modalDialogTitle.innerText();
      if (modalTitle && modalTitle.includes("Quote not saved")) {
        await this.quomoIndicativePage.btnNo.click();
        await this.quomoIndicativePage.firmQuoteCard
          .locator(this.quomoIndicativePage.quoteLinkInCard)
          .click();
      }
    }
    await this.verifyFirmQuoteHeader();
    await expect(this.quomoIndicativePage.quoteStatus).toHaveText(
      "Ready to send",
    );
    await expect(this.quomoIndicativePage.btnSave).toBeDisabled();
  }

  async createFirmQuoteExtension({
    deliveryDate,
    quoteNotes = faker.word.noun(),
  }: {
    deliveryDate?: string;
    quoteNotes?: string;
  } = {}) {
    if (await this.quomoIndicativePage.btnCreateFirm.isDisabled()) {
      await this.quomoIndicativePage.btnSave.click();
    }
    await this.quomoIndicativePage.btnCreateFirm.click();
    await this.quomoIndicativePage.verifyAttributesHeader.waitFor();
    !!deliveryDate &&
      (await this.quomoIndicativePage.preferredDeliveryDate.fill(deliveryDate));
    await this.quomoIndicativePage.notes.fill(quoteNotes);
    await this.quomoIndicativePage.btnContinue.click();
    await this.quomoIndicativePage.firmQuoteCard.waitFor();
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .waitFor({ timeout: 500000 });
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();

    await this.verifyFirmQuoteHeaderExtension();
    await expect(this.quomoIndicativePage.quoteStatus).toHaveText(
      "Ready to send",
    );
    await expect(this.quomoIndicativePage.btnSave).toBeDisabled();
  }

  async createFirmQuote({
    deliveryDate,
    quoteNotes = faker.word.noun(),
  }: {
    deliveryDate?: string;
    quoteNotes?: string;
  } = {}) {
    if (await this.quomoIndicativePage.btnCreateFirm.isDisabled()) {
      await this.quomoIndicativePage.btnSave.click();
    }
    if (!(await this.quomoIndicativePage.btnSave.isDisabled())) {
      await this.quomoIndicativePage.btnSave.click();
    }
    await this.quomoIndicativePage.btnCreateFirm.click();
    await this.quomoIndicativePage.verifyAttributesHeader.waitFor();
    !!deliveryDate &&
      (await this.quomoIndicativePage.preferredDeliveryDate.fill(deliveryDate));
    await this.quomoIndicativePage.notes.fill(quoteNotes);
    await this.quomoIndicativePage.btnContinue.click();
    await this.quomoIndicativePage.firmQuoteCard.waitFor();
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .waitFor({ timeout: 500000 });
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();
    await this.page.waitForLoadState("networkidle");
    if (await this.quomoIndicativePage.modalDialogTitle.isVisible()) {
      const modalTitle =
        await this.quomoIndicativePage.modalDialogTitle.innerText();
      if (modalTitle && modalTitle.includes("Quote not saved")) {
        await this.quomoIndicativePage.btnNo.click();
        await this.quomoIndicativePage.firmQuoteCard
          .locator(this.quomoIndicativePage.quoteLinkInCard)
          .click();
      }
    }
    await this.verifyFirmQuoteHeader();
    await expect(this.quomoIndicativePage.quoteStatus).toHaveText(
      "Ready to send",
    );
    await expect(this.quomoIndicativePage.btnSave).toBeDisabled();
  }

  async compareQuoteValues() {
    await this.quomoIndicativePage.indicativeQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();
    await expect(this.quomoIndicativePage.btnSave).toBeDisabled();
    await expect(
      this.quomoIndicativePage.quoteCardCheckboxes.first(),
    ).toBeVisible();
    const quoteCheckboxes =
      await this.quomoIndicativePage.quoteCardCheckboxes.all();
    await Promise.all(
      quoteCheckboxes.map(async (b) => {
        await b.click();
        await this.page.waitForTimeout(200);
        while ((await b.getAttribute("aria-checked")) == "false") {
          await b.click();
        }
      }),
    );
    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.compare.click();
    await expect(this.quomoIndicativePage.compareQuoteDialog).toBeVisible();
    const pricevalues =
      await this.quomoIndicativePage.getPricingDifferenceByType();
    await this.quomoIndicativePage.btnClose.last().click();
    return pricevalues;
  }

  async sendVSSS(emailAddr: string, subject: string, message: string) {
    await expect(this.quomoIndicativePage.firmQuoteCard).toBeVisible();
    await this.quomoIndicativePage.firmQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();
    await this.verifyFirmQuoteHeader();
    await this.quomoIndicativePage.btnSendVSSS.click();
    await this.quomoIndicativePage.sendVSSSDialog.waitFor();
    await expect(this.quomoIndicativePage.emailTo).toHaveValue(emailAddr);
    await expect(this.quomoIndicativePage.subject).toHaveValue(subject);
    await this.quomoIndicativePage.personalisedMessage.fill(message);
    await expect(this.quomoIndicativePage.emailPreview).toBeVisible();
    await this.quomoIndicativePage.btnSend.click();
    await expect(this.quomoIndicativePage.sendingVSSSEmail).toBeVisible();
    await this.quomoIndicativePage.quoteStatus
      .filter({ hasText: "Sent" })
      .waitFor();
  }

  async viewAndCloseEmailHistory() {
    await this.quomoIndicativePage.tradeAdvantageDownArrowKey.click();
    await this.quomoIndicativePage.emailHistoryOption.click();
    await expect(this.quomoIndicativePage.emailHistoryDetails).toBeVisible();
    await this.quomoIndicativePage.pdfFsgAuditTab.click();
    await expect(this.quomoIndicativePage.pdfFsgAuditHistory).toBeVisible();
    await this.quomoIndicativePage.btnCloseHistory.click();
    await expect(this.quomoIndicativePage.emailHistoryDetails).toBeHidden();
  }

  async sendEmployerApprovalRequest(emailTo: string, employeeNum: string) {
    await this.quomoIndicativePage.tradeAdvantageDownArrowKey.click();
    await this.quomoIndicativePage.employerApprovalOption.click();
    await expect(this.quomoIndicativePage.checkWindowHeader).toHaveText(
      " Employer approval request ",
    );
    await this.quomoIndicativePage.employeeNumber.fill(employeeNum);
    await this.quomoIndicativePage.approverEmail.clear();
    await this.quomoIndicativePage.approverEmail.type(emailTo);
    await this.quomoIndicativePage.selectDocument.click();
    await this.quomoIndicativePage.confirmCheckbox.click();
    await this.quomoIndicativePage.btnSend.click();
  }

  async viewVSSS() {
    await this.quomoIndicativePage.toggleDropDown.click();
    await this.quomoIndicativePage.viewVSSS.click();
    await expect(this.quomoIndicativePage.vsssPDF).toBeVisible({
      timeout: 65000,
    });
    await this.quomoIndicativePage.btnClose.last().click();
  }

  async submitOrder({
    employeeName = faker.person.firstName(),
    emailAddr,
    mobNum,
    location,
    finApproverNum = faker.number.int({ min: 100000, max: 500000 }) + "",
  }: {
    employeeName?: string;
    emailAddr: string;
    mobNum: string;
    location: string;
    finApproverNum?: string;
  }) {
    await this.quomoIndicativePage.btnSubmitOrder.click();
    expect(this.quomoIndicativePage.submitOrderDialogHeader).toBeVisible();
    await this.quomoIndicativePage.deliveryContactName.fill(employeeName);
    await this.page.keyboard.press("Tab");
    await this.quomoIndicativePage.deliveryContactemail.fill(emailAddr);
    await this.quomoIndicativePage.deliveryContactPhone.fill(mobNum);
    await this.quomoIndicativePage.deliveryLocation.last().fill(location);
    await this.quomoIndicativePage.financeApproverRefNum.fill(finApproverNum);
    await this.quomoIndicativePage.btnSubmitOrder.last().click();
    await this.quomoIndicativePage.submitSuccessfulDialog.waitFor({
      state: "visible",
      timeout: 60000,
    });
    await expect(this.quomoIndicativePage.submitSuccessfulMessage).toHaveText(
      " Submit order successful ",
      { timeout: 120000 },
    );
    await this.quomoIndicativePage.btnClose.last().click();
    await expect(this.quomoIndicativePage.quoteStatus).toContainText("Ordered");
    const milesRefNum = await this.quomoIndicativePage.retrieveAttributeValues
      .nth(2)
      .innerText();
    const quoteNum = await this.quomoIndicativePage.retrieveAttributeValues
      .nth(3)
      .innerText();
    return {
      milesRefNum,
      quoteNum,
    };
  }

  async discardQuotes() {
    await this.quomoIndicativePage.indicativeQuoteCard
      .locator(this.quomoIndicativePage.quoteLinkInCard)
      .click();
    await this.page.waitForLoadState("networkidle");
    await this.page.waitForTimeout(5000); //Adding this timeout as the page relement refreshes and the checkbox that was selected becomes unselected and hence test fails.
    await this.quomoIndicativePage.quoteCardCheckboxes
      .first()
      .check({ force: true });

    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.discard.click();
    await this.quomoIndicativePage.indicativeQuoteCard.waitFor({
      state: "hidden",
    });
    await expect(this.quomoIndicativePage.indicativeQuoteCard).toBeHidden();
  }

  async showDiscardedQuotes() {
    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.showDiscarded.click();
    await this.quomoIndicativePage.indicativeQuoteCard.waitFor();
    await expect(this.quomoIndicativePage.discardStatus).toBeVisible();
    await expect(this.quomoIndicativePage.discardStatus).toContainText(
      "Discarded",
    );
    await expect(this.quomoIndicativePage.indicativeQuoteCard).toBeVisible();
  }

  async hideDiscardedQuotes() {
    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.hideDiscarded.click();
    await expect(this.quomoIndicativePage.indicativeQuoteCard).toBeHidden();
  }

  async restoreDiscardedQuotes() {
    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.showDiscarded.click();
    await this.quomoIndicativePage.quoteCardCheckboxes.first().click();
    await this.quomoIndicativePage.actionsDropdown.click();
    await this.quomoIndicativePage.restore.click();
    await expect(this.quomoIndicativePage.quoteStatus).toContainText("Saved");
    await expect(this.quomoIndicativePage.indicativeQuoteCard).toBeVisible();
  }
}
