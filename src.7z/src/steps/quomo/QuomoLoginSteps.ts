import { Page } from "@playwright/test";
import { QuomoLoginPage } from "../../pages/quomo/QuomoLoginPage";
import { QuomoNovatedPage } from "../../pages/quomo/QuomoNovatedQuotingPage";
import { MsOnlineLoginPage } from "../../pages/common/signOns/MSOnlineLoginPage";

export class LoginIntoQuomo {
  quomoLoginPage: QuomoLoginPage;
  quomoNovatedPage: QuomoNovatedPage;
  msOnlineLogin: MsOnlineLoginPage;
  readonly page: Page;

  constructor(page: Page) {
    this.quomoLoginPage = new QuomoLoginPage(page);
    this.quomoNovatedPage = new QuomoNovatedPage(page);
    this.msOnlineLogin = new MsOnlineLoginPage(page);
    this.page = page;
  }

  async searchIMSLeadInQuomo(
    url: string,
    email: string,
    password: string,
    imsLeadNum: string,
  ) {
    console.log("Username: " + email);
    console.log("URL: " + url);
    console.log("IMS LeadNum: " + imsLeadNum);
    await this.quomoLoginPage.openQuomo(url);
    await this.msOnlineLogin.doLogin(email, password);
    await this.quomoLoginPage.textboxTicketNum.fill(imsLeadNum);
    await this.quomoLoginPage.quomoSearchButton.click();
    await this.acknowledgeEmployerNotes(imsLeadNum);
    await this.page.setViewportSize({
      width: 1600,
      height: 1200,
    });
  }

  async acknowledgeEmployerNotes(imsLeadNum: string, trial = 3) {
    if (!trial) {
      throw "Acknowledgement pop up not appearing";
    }
    await this.page.reload({ waitUntil: "domcontentloaded" });
    console.log("----------------Trial remaining--------------", trial);
    const isModalVisible = await this.#isModalVisible(20);
    console.log(" Outside Modal visible:", isModalVisible);
    if (isModalVisible) {
      const modalTitle =
        await this.quomoNovatedPage.modalDialogTitle.innerText();
      switch (modalTitle) {
        case "Warning": // appears on top of Employer Notes
          console.log("Modal Error: " + modalTitle);
          await this.quomoNovatedPage.btnClose.click();
          await this.quomoNovatedPage.acknowledgeBtn.waitFor();
          await this.quomoNovatedPage.acknowledgeBtn.click();
          break;
        case "Employer notes":
          await this.quomoNovatedPage.acknowledgeBtn.waitFor();
          await this.quomoNovatedPage.acknowledgeBtn.click();
          break;
        case "An unknown error has occurred.":
          console.log("Modal Error: " + modalTitle);
          await this.page.waitForTimeout(5000);
          await this.quomoNovatedPage.btnClose.click();
          await this.quomoLoginPage.textboxTicketNum.fill(imsLeadNum);
          await this.quomoLoginPage.quomoSearchButton.click();
          await this.acknowledgeEmployerNotes(imsLeadNum, --trial);
          break;
        default:
          console.log("Modal Error: " + modalTitle);
          await this.page.waitForTimeout(5000);
          await this.quomoNovatedPage.btnClose.click();
      }
    } else {
      await this.acknowledgeEmployerNotes(imsLeadNum, --trial);
    }
  }

  async #isModalVisible(timeout = 10): Promise<boolean> {
    console.log("Inside:", timeout);
    if (timeout) {
      const isModalVisible =
        await this.quomoNovatedPage.modalDialogTitle.isVisible();
      console.log("Value inside:", isModalVisible);
      if (!isModalVisible) {
        console.log("oops not visible inside:", timeout);
        await this.page.waitForTimeout(1000);
        return await this.#isModalVisible(--timeout);
      } else {
        console.log("Yaay, its visible on timeout:", timeout);
        return true;
      }
    } else {
      return false;
    }
  }
}
