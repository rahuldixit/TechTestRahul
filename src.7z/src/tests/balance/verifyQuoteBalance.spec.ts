import { VerifyBalanceInQuote } from "../../steps/balance/VerifyAvailableBalanceInQuoteSteps";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { APPCONSTANTS } from "../../app.constants";
import moment from "moment";
import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { VerifyMilesSideBar } from "../../steps/miles/VerifyMilesSidebarSteps";
import * as data from "./testdata/balanceData.json";
import * as quomo from "../quomo/testdata/quomoData.json";

test.describe("Verify available balance in Quote, @smoke @balancesmoke", async () => {
  test.setTimeout(15 * 60 * 1000);
  let imslogin: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let quomoLogin: LoginIntoQuomo;
  let createQuote: CreateQuote;
  let verifyQuoteBalance: VerifyBalanceInQuote;
  let milesLogin: MilesLogin;
  let selectContract: SearchExistingObject;
  let milesSidebar: VerifyMilesSideBar;

  test("Verify if the Available Balance summary is displayed in the Refinance Quote @EM-111", async ({
    page,
  }) => {
    milesLogin = new MilesLogin(page);
    await milesLogin.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2, // Changed user, because sometimes it's faster
      APPCONSTANTS.PASSWORD_2,
    );
    selectContract = new SearchExistingObject(page);

    const { contractID, contractReference, customerName } =
      (await selectContract.retrieveExistingRefinanceOrFormalExtContractID({
        option: data.refinance.option,
        reference: data.refinance.reference,
        product: data.refinance.product,
        customer: data.refinance.customer,
        contractOperator: data.refinance.contractOperator,
        contractValue: data.refinance.contractValue,
        endDateOperator: data.refinance.endDateOperator,
        fromEndDateValue: moment().add(15, "d").format("DD/MM/YYYY 00:00"),
        toEndDateValue: moment().add(6, "months").format("DD/MM/YYYY 00:00"),
        billingOperator: data.refinance.billingOperator,
        billingValue: data.refinance.billingValue,
        netRentalDescription: data.refinance.fundingArrangement,
      })) as {
        contractID: string;
        contractReference: string;
        customerName: string;
      };

    imslogin = new LoginIntoIMS(page);
    await imslogin.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    createOpp = new CreateOppurtunity(page);
    const { issueNum } =
      await createOpp.createEndOfTermOppurtunityAndRetrieveQuoteDetails({
        customerName: customerName,
        emailAddr: APPCONSTANTS.USERNAME,
        conRef: contractReference,
      });

    const oppurtunityID = issueNum.split("-")[1];
    quomoLogin = new LoginIntoQuomo(page);
    await quomoLogin.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      oppurtunityID,
    );
    await page.waitForTimeout(7000);
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    await verifyQuoteBalance.submitRefinanceQuoteAttributes({
      postcode: quomo.quotedata.postCode,
      registrationExpDate: moment().add(2, "years").format("DD/MM/YYYY"),
      refTerm: quomo.quotedata.refTerm,
    });
    await verifyQuoteBalance.verifyIndicativeRefinanceQuoteHeader();
    createQuote = new CreateQuote(page);
    await createQuote.configureContractComprehensiveInsurance();
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    const indicativeAvailBal =
      await verifyQuoteBalance.retrieveAvailableBalanceByServiceName();
    console.log(
      "The available balance in indicative quote is",
      indicativeAvailBal,
    );
    createQuote = new CreateQuote(page);
    await createQuote.createFirmQuoteRefinance();
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    const firmAvailBal =
      await verifyQuoteBalance.retrieveAvailableBalanceByServiceName();
    console.log("The available balance in firm quote is", firmAvailBal);

    // Open miles sidebar
    milesLogin = new MilesLogin(page);
    await milesLogin.loginIntoMilesSidebar({
      url: APPCONSTANTS.MILES_SIDEBAR_URL,
      sroid: "86",
      contractID: contractID,
    });
    milesSidebar = new VerifyMilesSideBar(page);
    const milesSBAvailBal =
      await milesSidebar.retrieveAvailableBalanceOfAllServices();
    console.log("The available balance in miles sidebar is", milesSBAvailBal);
    await milesSidebar.verifyBalances(firmAvailBal, milesSBAvailBal);
  });

  test("Verify if the Available Balance summary is displayed in the Formal Extension Quote @EM-112", async ({
    page,
  }) => {
    milesLogin = new MilesLogin(page);
    selectContract = new SearchExistingObject(page);
    quomoLogin = new LoginIntoQuomo(page);

    await milesLogin.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2, // Changed user, because sometimes it's faster
      APPCONSTANTS.PASSWORD_2,
    );

    const { contractID, customerName } =
      (await selectContract.retrieveExistingRefinanceOrFormalExtContractID({
        option: data.formalextension.option,
        product: data.formalextension.product,
        customer: data.formalextension.customer,
        contractOperator: data.formalextension.contractOperator,
        contractValue: data.formalextension.contractValue,
        endDateOperator: data.formalextension.endDateOperator,
        fromEndDateValue: moment().add(1, "months").format("DD/MM/YYYY 00:00"),
        toEndDateValue: moment().add(2, "months").format("DD/MM/YYYY 00:00"),
        billingOperator: data.formalextension.billingOperator,
        billingValue: data.formalextension.billingValue,
        vehicleSourceOperator: data.formalextension.vehicleSourceOperator,
        vehicleSourceValue: data.formalextension.vehicleSourceValue,
        fundingArrangement: data.formalextension.fundingArrangement,
      })) as {
        contractID: string;
        customerName: string;
      };

    imslogin = new LoginIntoIMS(page);
    await imslogin.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    createOpp = new CreateOppurtunity(page);
    const { issueNum } =
      await createOpp.createEndOfTermOppurtunityAndRetrieveQuoteDetails({
        customerName: customerName,
        emailAddr: APPCONSTANTS.USERNAME,
        conRef: contractID,
      });

    const oppurtunityID = issueNum.split("-")[1];

    await quomoLogin.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      oppurtunityID,
    );
    await page.waitForTimeout(7000);
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    await verifyQuoteBalance.submitFormalExtensionQuoteAttributes({
      postcode: quomo.quotedata.postCode,
      registrationExpDate: moment().add(2, "years").format("DD/MM/YYYY"),
      refTerm: quomo.quotedata.refTerm,
    });
    await verifyQuoteBalance.verifyIndicativeExtensionQuoteHeader();
    createQuote = new CreateQuote(page);
    await createQuote.configureContractComprehensiveInsurance();
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    const indicativeAvailBal =
      await verifyQuoteBalance.retrieveAvailableBalanceByServiceName();
    console.log(
      "The available balance in indicative quote is",
      indicativeAvailBal,
    );
    createQuote = new CreateQuote(page);
    await createQuote.createFirmQuoteExtension();
    verifyQuoteBalance = new VerifyBalanceInQuote(page);
    const firmAvailBal =
      await verifyQuoteBalance.retrieveAvailableBalanceByServiceName();
    console.log("The available balance in firm quote is", firmAvailBal);

    // Open miles sidebar
    milesLogin = new MilesLogin(page);
    await milesLogin.loginIntoMilesSidebar({
      url: APPCONSTANTS.MILES_SIDEBAR_URL,
      sroid: "86",
      contractID: contractID,
    });
    milesSidebar = new VerifyMilesSideBar(page);
    const milesSBAvailBal =
      await milesSidebar.retrieveAvailableBalanceOfAllServices();

    console.log("The available balance in miles sidebar is", milesSBAvailBal);
    await milesSidebar.verifyBalances(firmAvailBal, milesSBAvailBal);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
