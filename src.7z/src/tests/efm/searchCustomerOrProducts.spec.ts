import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoEFM } from "../../steps/efm/EFMLoginSteps";
import { SearchProducts } from "../../steps/efm/SearchProductSteps";
import { ViewProductDetails } from "../../steps/efm/ViewProductDetailsSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/efmData.json";

test.describe("Search Customer/Products @smoke @efmsmoke", async () => {
  test.setTimeout(8 * 60 * 1000);
  let login: LoginIntoEFM;
  let search: SearchProducts;
  let productDetails: ViewProductDetails;

  test("Verify user is able to search for customer/products with Product ID in Customers/Products tab @EM-192", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );
    search = new SearchProducts(page);
    await search.searchProduct(data.efm1.productID);
  });

  test("Verify user is able to click on Product ID to view the product details @EM-193", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    search = new SearchProducts(page);
    productDetails = new ViewProductDetails(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );
    await search.searchProduct(data.efm1.productID);
    await search.efmHomePage.selectProductByID(data.efm1.productID);
    await productDetails.verifyProductInGeneralInfo(data.efm1.productID);
    const rego = await productDetails.getRegistrationInGeneralInfo();
    const desc = await productDetails.getDescriptionInGeneralInfo();
    await productDetails.goToFBTTracking();
    await productDetails.verifyFBTTracking(rego, desc);
  });

  test("Verify user is able to search for customer/products with client name in Customers/Products tab @EM-194", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );
    search = new SearchProducts(page);
    await search.searchCustomer(data.efm1.client);
  });

  test("Verify that search on the home page works and results match expected data @EM-198", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    search = new SearchProducts(page);
    productDetails = new ViewProductDetails(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    // Search with Product ID
    await search.searchProduct(data.efm1.productID);
    await search.verifySearchResults({
      expectedName: data.efm1.name,
      expectedProductID: data.efm1.productID,
      expectedMilesContractRef: data.efm1.milesContractRef,
      expectedFMP: data.efm1.fmp,
      expectedLeaseType: data.efm1.leaseType,
      expectedProductDescription: data.efm1.productDescription,
      expectedState: data.efm1.state,
      expectedClient: data.efm1.expClient,
    });

    // Search with Rego
    await search.searchProduct(data.efm1.rego);
    await search.verifySearchResults({
      expectedName: data.efm1.name,
      expectedProductID: data.efm1.productID,
      expectedMilesContractRef: data.efm1.milesContractRef,
      expectedFMP: data.efm1.fmp,
      expectedLeaseType: data.efm1.leaseType,
      expectedProductDescription: data.efm1.productDescription,
      expectedState: data.efm1.state,
      expectedClient: data.efm1.expClient,
    });
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
