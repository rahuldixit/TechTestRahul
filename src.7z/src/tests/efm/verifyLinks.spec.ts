import { SearchProducts } from "steps/efm/SearchProductSteps";
import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoEFM } from "../../steps/efm/EFMLoginSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/efmData.json";
import { VerifyLinkData } from "steps/efm/VerifyLinkDataSteps";
import { EFMClientPage } from "pages/efm/EFMClientPage";

test.describe("Verify Link Data @regression @efmregression", async () => {
  test.setTimeout(3 * 60 * 1000);
  let login: LoginIntoEFM;
  let search: SearchProducts;
  let clientPage: EFMClientPage;
  let verifyLinkDataSteps: VerifyLinkData;

  test("Verify that link under 'Name' link in the search result, @EM-200", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    search = new SearchProducts(page);
    verifyLinkDataSteps = new VerifyLinkData(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    //goto to customer
    await search.searchProduct(data.efm2.productID);
    await search.clickName();
    await verifyLinkDataSteps.verifyCustomerData(data.efm2);
  });

  test("Verify that Product ID link in the search result works., @EM-199", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    search = new SearchProducts(page);
    clientPage = new EFMClientPage(page);
    verifyLinkDataSteps = new VerifyLinkData(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await search.searchProduct(data.efm2.productID);
    await search.clickProductID();
    await clientPage.clickSideMenu("Contract Details ...");
    await clientPage.clickSideMenu("Provision Amounts");
    await verifyLinkDataSteps.verifyProvisionAmounts(data.efm2.productDetails);
    await clientPage.btnEditProduct.click();
    await clientPage.btnBackProductDetails.click();
    await verifyLinkDataSteps.verifyProductDetails(data.efm2);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
