import { SearchProducts } from "steps/efm/SearchProductSteps";
import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoEFM } from "../../steps/efm/EFMLoginSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/efmData.json";
import { RecostingSteps } from "steps/efm/RecostingSteps";

test.describe("Verify Recosting @regression @efmregression", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: LoginIntoEFM;
  let search: SearchProducts;
  let recostingsSteps: RecostingSteps;

  test("Verify user is able to generate and mail recosting quote to driver, @EM-201", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    search = new SearchProducts(page);
    recostingsSteps = new RecostingSteps(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await search.searchProduct(data.efm3.productID);
    await search.clickProductID();
    await recostingsSteps.completeRecostRequest(data.efm3);
    await recostingsSteps.verifyRecostEmailSubject(
      data.efm3.emailSubject,
      process.env.TEST_USERNAME_2,
      process.env.TEST_PASSWORD_2,
    );
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
