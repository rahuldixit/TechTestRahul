import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoEFM } from "../../steps/efm/EFMLoginSteps";
import { NavigateToPage } from "../../steps/efm/EFMNavigateToPagesSteps";
import { SearchClients } from "../../steps/efm/SearchClientsSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/efmData.json";

test.describe("Login into EFM and verify links @healthcheck @efmhealthcheck", async () => {
  test.setTimeout(3 * 60 * 1000);
  let login: LoginIntoEFM;
  let navPage: NavigateToPage;
  let searchClients: SearchClients;

  test("Verify user is able to search for clients in Clients tab @EM-195", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    navPage = new NavigateToPage(page);
    searchClients = new SearchClients(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await navPage.navigateToClients();
    await searchClients.searchClient(data.efm1.client);
    await searchClients.verifySearchResult();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
