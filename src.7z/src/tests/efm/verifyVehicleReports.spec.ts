import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoEFM } from "../../steps/efm/EFMLoginSteps";
import { expect, test } from "@playwright/test";
import * as data from "./testdata/efmData.json";
import { hasDuplicates, readCSV } from "utils/csvReader";
import { VerifyReport } from "steps/efm/ViewReportSteps";
import {
  downloadFile,
  verifyQuoteEmailAndDownloadPDF,
  waitForNewSubject,
} from "utils/emailReader";

test.describe("Verify Vehicle Reports @regression @efmregression", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: LoginIntoEFM;
  let reportSteps: VerifyReport;

  test("Verify that FBT Company Report for ZLEV contract, @EM-166, @EM-167, @EM-168", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    reportSteps = new VerifyReport(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await reportSteps.gotoCompanyReport();
    await reportSteps.runVehicleReport([data.efm4.company]);

    const subject =
      "[" +
      APPCONSTANTS.EFM_APP_URL.split("/")[2].split(".")[0] +
      "]" +
      " FBT Company Report";
    const downloadPath = await verifyQuoteEmailAndDownloadPDF(
      reportSteps.page,
      process.env.TEST_USERNAME_2,
      process.env.TEST_PASSWORD_2,
      subject,
    );
    expect(downloadPath).not.toBe(null);
    const csvData: any = await readCSV(downloadPath ? downloadPath : "");

    const zlevExemptCustomer: any = csvData.data.filter(function (el: any) {
      return !!~el.indexOf(data.efm4.registrationNumber);
    });

    const row = 0;

    const fbtMethodology = 10;
    const grossTaxableValue = 32;
    const bfEmployeeContributions = 33;
    const actualEmployeeContributions = 34;
    const bfEmployeeContributionsFromNextYear = 35;
    const totalEmployeeContributions = 36;
    const taxableValue = 37;
    const excessEmployeeContributions = 38;
    const grossUpTaxableValue = 40;
    const employerFBTPayable = 41;
    const fBTSubsidyPercentage = 42;
    const fBTSubsidyAmount = 43;
    const employeeFBTPayable = 44;
    const fBTAccrual = 45;
    const fBTHeldbyEmployer = 46;
    const zlevFirstHeldDate = 48;
    const zlevFirstPurchasePrice = 49;
    const powertrain = 50;

    expect(zlevExemptCustomer[row][fbtMethodology]).toBe("ZLEV Exempt");

    expect(Number(zlevExemptCustomer[row][grossTaxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][bfEmployeeContributions])).toBe(0);
    expect(Number(zlevExemptCustomer[row][actualEmployeeContributions])).toBe(
      0,
    );
    expect(
      Number(zlevExemptCustomer[row][bfEmployeeContributionsFromNextYear]),
    ).toBe(0);
    expect(Number(zlevExemptCustomer[row][totalEmployeeContributions])).toBe(0);
    expect(Number(zlevExemptCustomer[row][taxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][excessEmployeeContributions])).toBe(
      0,
    );
    expect(Number(zlevExemptCustomer[row][grossUpTaxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][employerFBTPayable])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTSubsidyPercentage])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTSubsidyAmount])).toBe(0);
    expect(Number(zlevExemptCustomer[row][employeeFBTPayable])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTAccrual])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTHeldbyEmployer])).toBe(0);

    expect(csvData.data[row][zlevFirstHeldDate]).toBe("ZLEV First Held Date");
    expect(csvData.data[row][zlevFirstPurchasePrice]).toBe(
      "ZLEV First Purchase Price",
    );
    expect(csvData.data[row][powertrain]).toBe("Powertrain");
  });

  test("Verify FBT Company Group Report, @EM-169, @EM-170, @EM-171", async ({
    page,
  }) => {
    login = new LoginIntoEFM(page);
    reportSteps = new VerifyReport(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await reportSteps.gotoCompanyGroupReport();
    await reportSteps.runVehicleReport([data.efm4.company]);

    const subject =
      "[" +
      APPCONSTANTS.EFM_APP_URL.split("/")[2].split(".")[0] +
      "]" +
      " FBT Company Group Report";

    const downloadPath = await verifyQuoteEmailAndDownloadPDF(
      reportSteps.page,
      process.env.TEST_USERNAME_2,
      process.env.TEST_PASSWORD_2,
      subject,
    );
    expect(downloadPath).not.toBe(null);
    const csvData: any = await readCSV(downloadPath ? downloadPath : "");

    const zlevExemptCustomer: any = csvData.data.filter(function (el: any) {
      return !!~el.indexOf(data.efm4.registrationNumber);
    });

    const row = 0;

    const fbtMethodology = 11;
    const grossTaxableValue = 32;
    const bfEmployeeContributions = 33;
    const actualEmployeeContributions = 34;
    const bfEmployeeContributionsFromNextYear = 35;
    const totalEmployeeContributions = 36;
    const taxableValue = 37;
    const excessEmployeeContributions = 38;
    const grossUpTaxableValue = 40;
    const employerFBTPayable = 41;
    const fBTSubsidyPercentage = 42;
    const fBTSubsidyAmount = 43;
    const employeeFBTPayable = 44;
    const fBTAccrual = 45;
    const fBTHeldbyEmployer = 46;
    const zlevFirstHeldDate = 48;
    const zlevFirstPurchasePrice = 49;
    const powertrain = 50;

    expect(zlevExemptCustomer[row][fbtMethodology]).toBe("ZLEV Exempt");

    expect(Number(zlevExemptCustomer[row][grossTaxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][bfEmployeeContributions])).toBe(0);
    expect(Number(zlevExemptCustomer[row][actualEmployeeContributions])).toBe(
      0,
    );
    expect(
      Number(zlevExemptCustomer[row][bfEmployeeContributionsFromNextYear]),
    ).toBe(0);
    expect(Number(zlevExemptCustomer[row][totalEmployeeContributions])).toBe(0);
    expect(Number(zlevExemptCustomer[row][taxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][excessEmployeeContributions])).toBe(
      0,
    );
    expect(Number(zlevExemptCustomer[row][grossUpTaxableValue])).toBe(0);
    expect(Number(zlevExemptCustomer[row][employerFBTPayable])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTSubsidyPercentage])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTSubsidyAmount])).toBe(0);
    expect(Number(zlevExemptCustomer[row][employeeFBTPayable])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTAccrual])).toBe(0);
    expect(Number(zlevExemptCustomer[row][fBTHeldbyEmployer])).toBe(0);

    expect(csvData.data[row][zlevFirstHeldDate]).toBe("ZLEV First Held Date");
    expect(csvData.data[row][zlevFirstPurchasePrice]).toBe(
      "ZLEV First Purchase Price",
    );
    expect(csvData.data[row][powertrain]).toBe("Powertrain");
  });

  test("Verify that FBT Company Report (Run Vehicles Report) for multiple clients generates without error and duplicate columns, @EM-165", async ({
    page,
    context,
  }) => {
    login = new LoginIntoEFM(page);
    reportSteps = new VerifyReport(page);

    await login.loginIntoEFM(
      APPCONSTANTS.EFM_APP_URL,
      APPCONSTANTS.EFM_USERNAME,
      APPCONSTANTS.EFM_PASSWORD,
    );

    await reportSteps.gotoCompanyReport();
    await reportSteps.runVehicleReport([data.efm4.company, data.efm4.company2]);

    let subject =
      "[" +
      APPCONSTANTS.EFM_APP_URL.split("/")[2].split(".")[0] +
      "]" +
      " FBT Company Report 2024 for " +
      data.efm4.company2;
    let downloadPath = await verifyQuoteEmailAndDownloadPDF(
      page,
      process.env.TEST_USERNAME_2,
      process.env.TEST_PASSWORD_2,
      subject,
    );
    let csvData: any = await readCSV(downloadPath ? downloadPath : "");

    expect(hasDuplicates(csvData.data[0])).toBe(false);
    const bfEmployeeContributions = 35;
    expect(csvData.data[0][bfEmployeeContributions]).toBe(
      "B/F Employee Contributions From Next Year",
    );

    subject =
      "[" +
      APPCONSTANTS.EFM_APP_URL.split("/")[2].split(".")[0] +
      "]" +
      " FBT Company Report 2024 for " +
      data.efm4.company;
    const actualSubject = await waitForNewSubject(
      180,
      context.pages()[1],
      subject,
    );
    expect(actualSubject).not.toBe(null);
    downloadPath = await downloadFile(context.pages()[1]);
    csvData = await readCSV(downloadPath ? downloadPath : "");
    expect(hasDuplicates(csvData.data[0])).toBe(false);
    expect(csvData.data[0][bfEmployeeContributions]).toBe(
      "B/F Employee Contributions From Next Year",
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
