import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { SubmitOdoReading } from "../../steps/fi/VerifySubmitOdoReadingDisplayedSteps";
import { test, expect } from "@playwright/test";

/* 
Tags REMOVED due to Test Case Failing. Issue will not be fixed for a while.
Once fixed the Test Case can be moved back to the correct spec.ts
*/

// Once fixed, this test to be placed in verifySumitOdoReadingDisplayed.spec.ts
test.describe("Verify Submit Odo Reading. regression FIregression", () => {
  test.setTimeout(3 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let submitOdoReading: SubmitOdoReading;

  /* 
    This test case will FAIL when it tries to submit the new Odo Reading. 
    The issue is intermittent (fails 99%), it seems to work once per day (not always first try), and then keeps failing
    */
  test("Verify a novated driver can login to FI and submit new odo reading. EM-141", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    submitOdoReading = new SubmitOdoReading(page);

    //Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_ND_USER,
      APPCONSTANTS.FI_ND_PASSWORD,
    );

    //Submit Odo Reading
    const rego = await home.fiHomePage.getRegoFromVehicle();
    await submitOdoReading.goToSubmitOdoReadingDialog();
    const actualRego = await submitOdoReading.getRegoFromSubmitOdoReading();
    expect(actualRego).toEqual(rego);
    await submitOdoReading.submitNewOdoReading(100);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
