import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/fiData.json";

test.describe("Verify FI user login @healthcheck @fihealthcheck", () => {
  test.setTimeout(2 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;

  test("Verify a Novated Driver can login to FI and view the widgets. @EM-118", async ({
    page,
  }) => {
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    login = new LoginIntoFI(page);
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_ND_USER,
      APPCONSTANTS.FI_ND_PASSWORD,
    );
    home = new FIHome(page);
    await home.verifyWidgetsForNovatedDriver();
  });

  test("Verify a Fleet Manager can login to FI and view the widgets. @EM-113", async ({
    page,
  }) => {
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    login = new LoginIntoFI(page);
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    home = new FIHome(page);
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);
    await home.verifyWidgetsForFleetManager();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
