import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { FleetDataManagement } from "../../steps/fi/VerifyFleetDataManagementSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/fiData.json";
import { SearchRego } from "steps/fi/VerifySearchFunctionalitySteps";

test.describe("Fleet data management, @regression @FIregression", () => {
  test.setTimeout(10 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let fleetDataManagement: FleetDataManagement;
  let searchRego: SearchRego;

  test("Fleet data management - 'Update Vehicle Location' action, @EM-131", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetDataManagement = new FleetDataManagement(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    const rego = await searchRego.getRandomRegoFromHomePage();
    await fleetDataManagement.goToFleetDataManagement();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    let location =
      await fleetDataManagement.updateVehicleLocationUsingNewAddressField(
        data.fiData.location1,
        data.fiData.location2,
      );
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyVehicleLocationUpdated(location);
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    location =
      await fleetDataManagement.updateVehicleLocationUsingNewLocationDropdown(
        data.fiData.location1,
        data.fiData.location2,
      );
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyVehicleLocationUpdated(location);
  });

  test("Fleet data management - 'Driver Details' action, @EM-129", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetDataManagement = new FleetDataManagement(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    const rego = await searchRego.getRandomRegoFromHomePage();
    await fleetDataManagement.goToFleetDataManagement();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    const driver = await fleetDataManagement.updateDriverDetails(
      data.fiData.driver1,
      data.fiData.driver2,
    );
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyDriverUpdated(driver);
  });

  test("Fleet data management - 'Perform Cost Centre Transfer' action, @EM-130", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetDataManagement = new FleetDataManagement(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    const rego = await searchRego.getRandomRegoFromHomePage();
    await fleetDataManagement.goToFleetDataManagement();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    const costCentre = await fleetDataManagement.performCostCentreTransfer();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyCostCentreUpdated(costCentre);
  });

  test("Fleet data management - 'Submit Odo Reading' action, @EM-132", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetDataManagement = new FleetDataManagement(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    const rego = await searchRego.getRandomRegoFromHomePage();
    await fleetDataManagement.goToFleetDataManagement();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    const newOdoReading = await fleetDataManagement.updateOdoReading();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyOdoReadingUpdated(newOdoReading);
  });

  test("Fleet data management - 'Update Vehicle Details' action, @EM-133", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetDataManagement = new FleetDataManagement(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    const rego = await searchRego.getRandomRegoFromHomePage();
    await fleetDataManagement.goToFleetDataManagement();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    const [vehicleCategory, vehiclePurpose, vehicleRole] =
      await fleetDataManagement.updateVehicleDetails();
    await fleetDataManagement.enterAndSearchVehicleInFleetDataManagement(rego);
    await fleetDataManagement.verifyVehicleDetails(
      vehicleCategory,
      vehiclePurpose,
      vehicleRole,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
