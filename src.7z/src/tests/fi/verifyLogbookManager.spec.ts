import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { LogbookManager } from "../../steps/fi/VerifyLogbookManagerSteps";
import { SearchRego } from "steps/fi/VerifySearchFunctionalitySteps";
import { test } from "@playwright/test";
import * as data from "./testdata/fiData.json";

test.describe("Logbook Manager - Verify user can access and edit trip summary for a vehicle. @regression @FIregression", () => {
  test.setTimeout(5 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let logbookManager: LogbookManager;
  let searchRego: SearchRego;

  test("Logbook Manager - Verify user can access and edit trip summary for a vehicle. @EM-128", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    logbookManager = new LogbookManager(page);
    searchRego = new SearchRego(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);
    const rego = await searchRego.getRandomRegoFromHomePage();
    await logbookManager.goToLogbookManager();
    await logbookManager.searchForRegoAndSetYear({ partialRego: rego });
    await logbookManager.clickEdit();
    const { start, end } = await logbookManager.enterStartAndEndOdo();
    await logbookManager.saveTripSummaryTable();
    await logbookManager.verifyTripSummaryTableUpdated(start, end);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
