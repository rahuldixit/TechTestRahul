import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { test } from "@playwright/test";
import { ManageProfile } from "steps/fi/VerifyManageProfileSteps";
import * as data from "./testdata/fiData.json";
import { faker } from "@faker-js/faker";

test.describe("Verify Manage Profile. @regression @FIregression", () => {
  test.setTimeout(6 * 60 * 1000);
  let login: LoginIntoFI;
  let manageProfile: ManageProfile;

  test("Verify novated driver can edit Bank Account Details and Residential Address sections. @EM-144", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    manageProfile = new ManageProfile(page);

    // Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_ND_USER,
      APPCONSTANTS.FI_ND_PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await manageProfile.gotoManageProfile();

    const bankAccountNo = faker.string.numeric(6);
    await manageProfile.editBankAccount(bankAccountNo, data.fiData.bsbNo);
    const street = faker.location.streetAddress();
    const suburb = faker.location.county();
    const mobileNumber =
      "04" +
      faker.string.numeric(2) +
      " " +
      faker.string.numeric(3) +
      " " +
      faker.string.numeric(3);
    await manageProfile.editAddress(
      street,
      suburb,
      data.fiData.state,
      data.fiData.postcode,
      mobileNumber,
    );
    await manageProfile.saveUpdates();
    await manageProfile.verifyBankAccountDetailsNovatedDriver(
      bankAccountNo,
      data.fiData.bsbNo,
    );
    await manageProfile.verifyAddressDetails(
      street,
      suburb,
      data.fiData.state,
      data.fiData.postcode,
      mobileNumber,
    );
  });

  test("Verify an Autopak driver can edit Bank Account Details, Residential Address and Mail Address sections. @EM-148", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    manageProfile = new ManageProfile(page);

    // Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_AUTOPAK_USER,
      APPCONSTANTS.FI_AUTOPAK_PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await manageProfile.gotoManageProfile();

    const bankAccountNo = faker.string.numeric(6);
    await manageProfile.editBankAccount(bankAccountNo, data.fiData.bsbNo);
    const street = faker.location.streetAddress();
    const suburb = faker.location.county();
    const mobileNumber =
      "04" +
      faker.string.numeric(2) +
      " " +
      faker.string.numeric(3) +
      " " +
      faker.string.numeric(3);
    await manageProfile.editAddress(
      street,
      suburb,
      data.fiData.state,
      data.fiData.postcode,
      mobileNumber,
    );
    await manageProfile.saveUpdates();
    await manageProfile.verifyBankAccountDetailsAutopakDriver(
      bankAccountNo,
      data.fiData.bsbNo,
    );
    await manageProfile.verifyAddressDetails(
      street,
      suburb,
      data.fiData.state,
      data.fiData.postcode,
      mobileNumber,
    );
  });
  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
