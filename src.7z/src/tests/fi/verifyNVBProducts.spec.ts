import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { expect, test } from "@playwright/test";
import { FIHomePage } from "pages/fi/FIHomePage";
import { FIHome } from "steps/fi/VerifyFIHomeSteps";

test.describe("Verify NVB Products. @regression @FIregression", () => {
  test.setTimeout(6 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHomePage;
  let fiHomeSteps: FIHome;

  test("Verify an employee with non vehicle benefits can choose between products to display. @EM-150", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHomePage(page);
    fiHomeSteps = new FIHome(page);

    // Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_NVB_USER,
      APPCONSTANTS.FI_NVB_PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    const residentialProductSummary =
      await fiHomeSteps.getNVBProductSummaryTexts();
    const residentialTransactionSummary =
      await fiHomeSteps.getNVBTransactionsTexts();
    await home.selectNVBProduct("Housing Loan Interest");
    await page.waitForLoadState("networkidle");
    const housingProductSummary = await fiHomeSteps.getNVBProductSummaryTexts();
    const housingTransactionSummary =
      await fiHomeSteps.getNVBTransactionsTexts();
    expect(residentialProductSummary).not.toBe(housingProductSummary);
    expect(residentialTransactionSummary).not.toBe(housingTransactionSummary);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
