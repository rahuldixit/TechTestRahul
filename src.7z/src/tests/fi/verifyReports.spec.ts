import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { FleetListing } from "../../steps/fi/VerifyFleetListingReportDisplayedSteps";
import { test, expect } from "@playwright/test";
import * as data from "./testdata/fiData.json";

test.describe("Verify Fleet Listing Report. @regression @FIregression", () => {
  test.setTimeout(6 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let fleetListing: FleetListing;

  test("Reports - Verify quick search in Fleet Listing Report is working as expected. @EM-137", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetListing = new FleetListing(page);

    // Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    await fleetListing.goToFleetListingPage();
    const rego = await fleetListing.getRandomRegoFromFleetListingPage();
    const actualRego = await fleetListing.searchRego(rego);
    expect(actualRego).toEqual(rego);
  });

  test("Verify Fleet Listing Report can be exported to different file formats. @EM-138", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetListing = new FleetListing(page);

    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    await fleetListing.goToFleetListingPage();
    const rego = await fleetListing.getRandomRegoFromFleetListingPage();
    const actualRego = await fleetListing.searchRego(rego);
    await fleetListing.exportAndVerifyExcel(actualRego);
    await fleetListing.exportAndVerifyPDF(actualRego);
    await fleetListing.exportAndVerifyCSV(actualRego);
  });

  test("Verify all tabs in Fleet Listing Report is displayed. @EM-139", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    fleetListing = new FleetListing(page);

    // Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    await fleetListing.goToFleetListingPage();
    const rego = await fleetListing.getRandomRegoFromFleetListingPage();
    const actualRego = await fleetListing.searchRego(rego);
    await fleetListing.verifyVehicleDetails(actualRego);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
