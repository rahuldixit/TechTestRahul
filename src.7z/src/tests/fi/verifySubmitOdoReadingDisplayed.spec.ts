import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { SubmitOdoReading } from "../../steps/fi/VerifySubmitOdoReadingDisplayedSteps";
import { test, expect } from "@playwright/test";

test.describe("Verify Submit Odo Reading screen is displayed. @smoke @FIsmoke", () => {
  test.setTimeout(3 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let submitOdoReading: SubmitOdoReading;

  test("Verify Submit Odo Reading screen is displayed. @EM-119", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    submitOdoReading = new SubmitOdoReading(page);

    //Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_ND_USER,
      APPCONSTANTS.FI_ND_PASSWORD,
    );

    //Submit Odo Reading displayed
    const rego = await home.fiHomePage.getRegoFromVehicle();
    await submitOdoReading.goToSubmitOdoReadingDialog();
    const actualRego = await submitOdoReading.getRegoFromSubmitOdoReading();
    expect(actualRego).toEqual(rego);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
