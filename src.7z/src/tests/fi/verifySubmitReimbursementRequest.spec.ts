import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { test } from "@playwright/test";
import { SubmitReimbursementSteps } from "steps/fi/VerifySubmitReimbursementRequestDisplayedSteps";

test.describe("Verify Submit Reimbursement Request. @regression @FIregression", () => {
  test.setTimeout(6 * 60 * 1000);
  let login: LoginIntoFI;
  let reimbursementSteps: SubmitReimbursementSteps;

  test("Verify an Autopak driver can login and submit reimbursement request. Verify autopak driver can access the Reimbursement Request History menu. @EM-146, EM-147", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    reimbursementSteps = new SubmitReimbursementSteps(page);

    // Login as Autopak Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_AUTOPAK_USER,
      APPCONSTANTS.FI_AUTOPAK_PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await reimbursementSteps.goToRequestReimbursementOrDirectPayment();
    const [
      total,
      registration,
      ctp,
      autoClubMembership,
      comprehensiveInsurance,
      fuelPurchase,
      maintenance,
      otherExpenses,
    ] = await reimbursementSteps.completeReimbursementForAutopakDriver(
      "./src/tests/fi/testdata/reimbursement.pdf",
    );
    await reimbursementSteps.verifyReimbursementComplete();
    await reimbursementSteps.verifyReimbursement(
      total,
      registration,
      ctp,
      autoClubMembership,
      comprehensiveInsurance,
      fuelPurchase,
      maintenance,
      otherExpenses,
    );
  });

  test("Verify a Novated driver can login and submit reimbursement request. @EM-142", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    reimbursementSteps = new SubmitReimbursementSteps(page);

    // Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_NOVATED_DRIVER_BALANCE_USERNAME,
      APPCONSTANTS.FI_NOVATED_DRIVER_BALANCE_PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await reimbursementSteps.goToSubmitReimbursementRequest();
    await reimbursementSteps.completeReimbursementForNovatedDriver(
      "./src/tests/fi/testdata/reimbursement.pdf",
    );
    await reimbursementSteps.verifyReimbursementCompleteNovated();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
