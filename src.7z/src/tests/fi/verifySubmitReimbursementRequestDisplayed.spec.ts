import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { SubmitReimbursementSteps } from "../../steps/fi/VerifySubmitReimbursementRequestDisplayedSteps";
import { test, expect } from "@playwright/test";

test.describe("Verify Submit Reimbursement Request screen is displayed. @smoke @FIsmoke", () => {
  test.setTimeout(8 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let submitReimbursement: SubmitReimbursementSteps;

  test("Novated Driver: Verify Submit Reimbursement Request screen is displayed. @EM-120", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    submitReimbursement = new SubmitReimbursementSteps(page);

    //Login as Novated Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.FI_ND_USER,
      APPCONSTANTS.FI_ND_PASSWORD,
    );

    //Submit Reimbursement Request Displayed
    const rego = await home.fiHomePage.getRegoFromVehicle();
    await submitReimbursement.goToSubmitReimbursement();
    const actualRego =
      await submitReimbursement.getRegoFromSubmitReimbursement();
    await submitReimbursement.verifyHeadingsForNovatedDriver();
    expect(actualRego).toEqual(rego);
  });

  test("NVB Employee: Verify Submit Reimbursement Request screen is displayed. @EM-122", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    submitReimbursement = new SubmitReimbursementSteps(page);

    //Login as NVB Employee
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP2_URL,
      APPCONSTANTS.FI_NVB_USER,
      APPCONSTANTS.FI_NVB_PASSWORD,
    );

    //Submit Reimbursement Request Displayed
    const requestType = await home.fiHomePage.getRequestFromShowingDataFor();
    await submitReimbursement.goToSubmitReimbursement();
    const actualRequestType =
      await submitReimbursement.getRequestFromSubmitReimbursement();
    await submitReimbursement.verifyHeadingsForNVBEmployee();
    expect(actualRequestType).toEqual(requestType);
  });
  /**This testcase will fail in UAT as it doesn't have Autopak login */
  test("Autopak Driver: Verify Submit Reimbursement Request screen is displayed. @EM-125", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    submitReimbursement = new SubmitReimbursementSteps(page);

    //Login as Autopak Driver
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });

    await login.loginAsDriverOrEmployee(
      APPCONSTANTS.FI_APP2_URL,
      APPCONSTANTS.FI_AUTOPAK_USER,
      APPCONSTANTS.FI_AUTOPAK_PASSWORD,
    );

    //Reimbursement Request Displayed
    const rego = await home.fiHomePage.getRegoFromVehicle();
    await submitReimbursement.goToRequestReimbursementOrDirectPayment();
    const actualRego =
      await submitReimbursement.getRegoFromSubmitReimbursement();
    await submitReimbursement.verifyHeadingsForAutopakDriver();
    expect(actualRego).toEqual(rego);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
