import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoFI } from "../../steps/fi/VerifyFILoginSteps";
import { FIHome } from "../../steps/fi/VerifyFIHomeSteps";
import { VehicleQuotations } from "../../steps/fi/VerifyVehicleQuotationsScreenDisplayedSteps";
import { test } from "@playwright/test";
import * as data from "./testdata/fiData.json";

test.describe("Verify the Vehicle Quotations screen is displayed. @smoke @FIsmoke", () => {
  test.setTimeout(10 * 60 * 1000);
  let login: LoginIntoFI;
  let home: FIHome;
  let vehicleQuotations: VehicleQuotations;

  test("Verify the Vehicle Quotations screen is displayed. @EM-116", async ({
    page,
  }) => {
    login = new LoginIntoFI(page);
    home = new FIHome(page);
    vehicleQuotations = new VehicleQuotations(page);

    //Login as Fleet Manager
    await page.route("**/ajax/jquery/jquery-2.2.0.min.js", (route, request) => {
      // Override headers
      const headers = {
        ...request.headers(),
      };
      delete headers["Authorization"];
      route.continue({ headers });
    });
    await login.loginAsFleetManager(
      APPCONSTANTS.FI_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    await page.waitForLoadState("networkidle");
    await home.selectCostCentre(data.fiData.costCentre);

    //Vehicle Quotation Screen Displayed
    await vehicleQuotations.goToVehicleQuotations();
    await vehicleQuotations.goToCreateNewQuotation();
    await vehicleQuotations.createNewQuotation({
      costCentreNumber: data.fiData.costCentreNumber,
    });
    await vehicleQuotations.verifyQuotationDataLoaded();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
