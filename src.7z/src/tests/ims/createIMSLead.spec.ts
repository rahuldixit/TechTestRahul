import { test } from "@playwright/test";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import * as data from "./testdata/imsData.json";

test.describe("Create IMS Lead @imssmoke @smoke", async () => {
  test.setTimeout(5 * 60 * 1000);
  let createOpp: CreateOppurtunity;
  let login: LoginIntoIMS;

  test("Create new oppurtunity - customername - AustraliaPost, @EM-268", async ({
    page,
  }) => {
    login = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    await login.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.imslead.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });
    console.log(issueNum);
  });

  test("Create end of term oppurtunity - customername - AustraliaPost, @EM-269", async ({
    page,
  }) => {
    login = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    await login.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const { issueNum } =
      await createOpp.createEndOfTermOppurtunityAndRetrieveQuoteDetails({
        customerName: data.imslead.customerName,
        emailAddr: APPCONSTANTS.USERNAME,
        conRef: data.imslead.conRef,
      });
    console.log(issueNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
