import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { test } from "@playwright/test";

test.describe("Verify IMS Login @healthcheck, @imshealthcheck", () => {
  test.setTimeout(5 * 60 * 1000);
  let login: LoginIntoIMS;

  test("Login into IMS using AzureAD @EM-370", async ({ page }) => {
    login = new LoginIntoIMS(page);

    await login.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
