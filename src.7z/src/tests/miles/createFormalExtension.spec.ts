import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateFormalExtension } from "../../steps/miles/CreateFormalExtensionSteps";
import { ModifyContract } from "../../steps/miles/ModifyContractSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";

/*
This test case requires MANUAL INPUT for the contract number
Otherwise it is expected to fail due to it using old data causing various errors
Some of the errors cannot be handled even by human testers
*/

test.describe("Verify user able to create Formal Extension for a contract", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: MilesLogin;
  let createFormalExtension: CreateFormalExtension;
  let modifyContract: ModifyContract;
  let existingContract: SearchExistingObject;

  test("Verify user able to create Formal Extension for a contract, @EM-58", async ({
    page,
  }) => {
    /* =================================================================================
    MANUALLY enter Contract Number here for contractNum.
    If left as an empty string, it will find a contract and attempt the Formal Extension
    WARNING: This will usually FAIL when trying to APPROVE the Amendment Quote
    Sample contract number: EFM239485 (Note: Existing contracts have a start and end date hence the sample 
    may not be valid)
    */
    const contractNum = ""; // eg: "1234567" OR ""
    //===================================================================================

    login = new MilesLogin(page);
    createFormalExtension = new CreateFormalExtension(page);
    modifyContract = new ModifyContract(page);
    existingContract = new SearchExistingObject(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );

    const changeReason = "Formal Extension";
    if (contractNum) {
      await createFormalExtension.searchValue(contractNum);
    } else {
      await existingContract.searchExistingContractForFormalExtension({});
      await existingContract.selectExistingContractFromList();
    }
    await createFormalExtension.addNewOdoReading();
    await createFormalExtension.goToLtcTab();
    await createFormalExtension.modifyContractForFormalExtension();
    await createFormalExtension.updateDurationAndDistance();
    // Test will usually FAIL here if random data used. It may not be able to Approve.
    await modifyContract.validateApproveContractFromQuoteOrAQ();
    await modifyContract.validateAndVerifyChangeReasonInNewVersion(
      changeReason,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
