import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";

test.describe("Verify user is able to create a Contract in Miles, @smoke , @milessmoke", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let createContract: CreateNewContract;

  test("Verify user is able to create a Contract in Miles,  @EM-51", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });
    console.log("contract number is: ", contractNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
