import { test } from "@playwright/test";

test.describe("Select existing contract to denovate it, @regression1, @milesST", async () => {
  test.setTimeout(10 * 60 * 1000);
});
