import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { VerifyMilesSideBar } from "../../steps/miles/VerifyMilesSidebarSteps";
import { MsOnlineLogin } from "../../steps/common/MSOnlineLoginSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import moment from "moment";

test.describe("Failing Test Cases, @failing", async () => {
  test.setTimeout(20 * 60 * 1000);
  let login: MilesLogin;
  let milesSidebar: VerifyMilesSideBar;
  let msLogin: MsOnlineLogin;
  let existingContract: SearchExistingObject;

  //was part of verifyMilesSideBarExistingContract.spec.ts
  //Test fails in UAT: not finding sidebar in 5s, SIT: cant find sidebar needs to try with new end date.
  test('Verify "Update Package" button is available on Miles sidebar for an existing active novated LTC, @EM-173', async ({
    page,
  }) => {
    login = new MilesLogin(page);
    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );

    existingContract = new SearchExistingObject(page);
    const contractRefNum = (await existingContract.openAnExistingContract({
      option: data.existingcontract.option,
      serviceName: data.existingcontract.serviceName,
      product: data.existingcontract.product,
      contractStatus: data.existingcontract.contractStatus,
      billingStatus: data.existingcontract.billingStatus,
      endDateValue: moment().add(3, "years").format("DD/MM/YYYY"),
    })) as string;

    login = new MilesLogin(page);
    await login.loginIntoMilesSidebar({
      url: APPCONSTANTS.MILES_SIDEBAR_URL,
      sroid: "86",
      contractID: contractRefNum,
    });

    msLogin = new MsOnlineLogin(page);
    await msLogin.loginIntoMicrosoftAccount(
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    milesSidebar = new VerifyMilesSideBar(page);
    await milesSidebar.verifyUpdatePackageButtonInMilesSidebar();
    await milesSidebar.verifyPageTitles();
    await milesSidebar.verifyPackageBalanceDetailsInMilesSidebar();
    const RM =
      await milesSidebar.verifyAccountInformationInMilesSidebar("RM: ");
    const legalEntity =
      await milesSidebar.verifyAccountInformationInMilesSidebar(
        "Legal entity: ",
      );
    const packageID =
      await milesSidebar.verifyPackageInformationInMilesSidebar("Package Id: ");
    const driverName =
      await milesSidebar.verifyPackageInformationInMilesSidebar(
        "Driver name: ",
      );
    const address =
      await milesSidebar.verifyPackageInformationInMilesSidebar("Address: ");
    const email =
      await milesSidebar.verifyPackageInformationInMilesSidebar("Email: ");
    const phone =
      await milesSidebar.verifyPackageInformationInMilesSidebar("Phone: ");
    const registration =
      await milesSidebar.verifyPackageInformationInMilesSidebar(
        "Registration: ",
      );
    const category =
      await milesSidebar.verifyPackageInformationInMilesSidebar("Category: ");
    console.log("RM is :", RM);
    console.log("Legal entity is :", legalEntity);
    console.log("Package ID is :", packageID);
    console.log("Driver name is :", driverName);
    console.log("Address is :", address);
    console.log("Email is :", email);
    console.log("Phone is :", phone);
    console.log("Registration is :", registration);
    console.log("Category is :", category);
    const actbal =
      await milesSidebar.retrieveActualBalanceFromPackageInMilesSidebar();
    const pendingBal =
      await milesSidebar.retrievePendingBalanceFromPackageInMilesSidebar();
    const availableBal =
      await milesSidebar.retrieveAvailableBalanceFromPackageInMilesSidebar();
    console.log("Actual balance is :", actbal);
    console.log("Pending balance is :", pendingBal);
    console.log("Available balance is :", availableBal);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
