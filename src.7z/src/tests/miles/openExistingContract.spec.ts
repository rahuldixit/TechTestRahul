import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import moment from "moment";

test.describe("Verify user is able choose existing selection to find contract and able to open the contract, @smoke, @milessmoke", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: MilesLogin;
  let existingContract: SearchExistingObject;

  test("Verify user is able choose existing selection to find contract and able to open the contract, @EM-49", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    existingContract = new SearchExistingObject(page);
    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const contractRefNum = await existingContract.openAnExistingContract({
      option: data.existingcontract.option,
      serviceName: data.existingcontract.serviceName,
      product: data.existingcontract.product,
      contractStatus: data.existingcontract.contractStatus,
      billingStatus: data.existingcontract.billingStatus,
      endDateValue: moment().add(1, "years").format("DD/MM/YYYY"),
    });
    console.log(contractRefNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
