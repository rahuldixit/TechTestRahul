import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { APPCONSTANTS } from "../../app.constants";
import { NEW_QUOTE_VEHICLE_LABELS } from "../../../enums/milesapp";
import { test, expect } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import moment from "moment";

test.describe("Verify that when vehicle meets ZLEV exempt eligibility, @regression1 , @milesregression", async () => {
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;

  test("Verify that when a new vehicle meets ZLEV exempt eligibility, then FBT method automatically populate as ZLEV Exempt, @EM-190", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles5.tradingname,
      template: data.miles5.template,
      vehicleDescp: data.miles5.vehicleDescp,
      model: data.miles5.model,
      duration: data.miles5.duration,
      postCode: data.miles5.postCode,
      state: data.miles5.state,
      leaseG: data.miles5.leaseG,
      faultClaims: data.miles5.faultClaims,
      convictedDUI: data.miles5.convictedDUI,
      negligentDriving: data.miles5.negligentDriving,
      location: data.miles5.location,
      emailAddr: data.miles5.emailAddr,
      contactNum: data.miles5.contactNum,
    });

    expect(
      await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.FBT_METHOD,
      ),
    ).toBe("ZLEV Exempt");
    console.log("quote num is :", quoteNum);
  });

  test("Verify that when a used vehicle meets ZLEV exempt eligibility, then FBT method automatically populate as ZLEV Exempt, @EM-191", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles6.tradingname,
      bpID: data.miles6.bpID,
      template: data.miles6.template,
      vehicleDescp: data.miles6.vehicleDescp,
      model: data.miles6.model,
      purchaseType: data.miles6.purchaseType,
      duration: data.miles6.duration,
      postCode: data.miles6.postCode,
      state: data.miles6.state,
      leaseG: data.miles6.leaseG,
      faultClaims: data.miles6.faultClaims,
      convictedDUI: data.miles6.convictedDUI,
      negligentDriving: data.miles6.negligentDriving,
    });

    await createQuote.enterZLEVDeliveryDetails(
      moment().subtract(1, "year").format("DD/MM/YYYY"),
      moment().add(5, "years").format("DD/MM/YYYY"),
      data.miles6.zlevFirstHeldDate,
      data.miles6.zlevFirstPurchasePrice,
    );
    await createQuote.enterDistanceOfDate();
    await createQuote.calculateQuote();

    expect(
      await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.FBT_METHOD,
      ),
    ).toBe("ZLEV Exempt");
    console.log("quote num is :", quoteNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
