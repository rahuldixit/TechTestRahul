import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { CreateNewPurchaseInvoice } from "../../steps/miles/CreateNewPurchaseInvoiceSteps";
import { CreateNewDirectCredit } from "../../steps/miles/CreateNewDirectCreditSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";

test.describe("Verify AP Invoices, @regression1, @milesregression", async () => {
  test.setTimeout(5 * 60 * 1000);
  let login: MilesLogin;
  let purchaseInvoiceSteps: CreateNewPurchaseInvoice;
  let directCreditSteps: CreateNewDirectCredit;
  let searchExistingObject: SearchExistingObject;

  test("Verify the successful creation of AP invoice - Misc. manually, @EM-300", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    purchaseInvoiceSteps = new CreateNewPurchaseInvoice(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    await purchaseInvoiceSteps.goToPurchaseInvoices();

    await purchaseInvoiceSteps.createNewPurchaseInvoiceFromSearch(
      data.purchaseInvoice1.option,
    );

    await purchaseInvoiceSteps.createPIForFuelRecharge({
      tradingName: data.purchaseInvoice1.tradingName,
      fuelType: data.purchaseInvoice1.fuelType,
      quantity: data.purchaseInvoice1.quantity,
      unitPrice: data.purchaseInvoice1.unitPrice,
      costPrice: data.purchaseInvoice1.costPrice,
      rechargeAmount: data.purchaseInvoice1.rechargeAmount,
    });

    await purchaseInvoiceSteps.enterVATAmounts({
      amountVATExcl: data.purchaseInvoice1.amountVATExcl,
      vatAmount: (Number(data.purchaseInvoice1.amountVATExcl) * 0.1)
        .toFixed(2)
        .toString(),
      amountVATIncl: (Number(data.purchaseInvoice1.amountVATExcl) * 1.1)
        .toFixed(2)
        .toString(),
    });

    await purchaseInvoiceSteps.postPurchaseInvoiceForFuelRecharge({
      fuelType: data.purchaseInvoice1.fuelType,
      quantity: data.purchaseInvoice1.quantity,
      unitPrice: data.purchaseInvoice1.unitPrice,
      costPrice: data.purchaseInvoice1.costPrice,
      rechargeAmount: data.purchaseInvoice1.rechargeAmount,
    });
  });

  test("Verify the successful allocation of funds to AP invoices manually - Pay by - Direct Credit, @EM-301", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    purchaseInvoiceSteps = new CreateNewPurchaseInvoice(page);
    directCreditSteps = new CreateNewDirectCredit(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    await purchaseInvoiceSteps.goToPurchaseInvoices();

    await purchaseInvoiceSteps.createNewPurchaseInvoiceFromSearch(
      data.purchaseInvoice1.option,
    );

    await purchaseInvoiceSteps.createPIForFuelRecharge({
      tradingName: data.purchaseInvoice1.tradingName,
      fuelType: data.purchaseInvoice1.fuelType,
      quantity: data.purchaseInvoice1.quantity,
      unitPrice: data.purchaseInvoice1.unitPrice,
      costPrice: data.purchaseInvoice1.costPrice,
      rechargeAmount: data.purchaseInvoice1.rechargeAmount,
    });

    await purchaseInvoiceSteps.enterVATAmounts({
      amountVATExcl: data.purchaseInvoice1.amountVATExcl,
      vatAmount: (Number(data.purchaseInvoice1.amountVATExcl) * 0.1)
        .toFixed(2)
        .toString(),
      amountVATIncl: (Number(data.purchaseInvoice1.amountVATExcl) * 1.1)
        .toFixed(2)
        .toString(),
    });

    const documentNumber = await purchaseInvoiceSteps.postPurchaseInvoice();

    await directCreditSteps.goToDirectCredit();

    await directCreditSteps.searchAndAssignOutstandingInvoice({
      purchaseInvoiceNumber: documentNumber,
      businessPartner: data.purchaseInvoice1.supplier,
      amount: (Number(data.purchaseInvoice1.amountVATExcl) * 1.1)
        .toFixed(0)
        .toString(),
    });
    await directCreditSteps.enterBankAccountDetails(
      data.purchaseInvoice1.businessPartnerAccount,
      data.purchaseInvoice1.SGFleetAccount,
    );
    await directCreditSteps.postDirectCredit();
  });

  test("Verify Label display in Allocation Details in Purchase Invoice, @EM-308", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    purchaseInvoiceSteps = new CreateNewPurchaseInvoice(page);
    searchExistingObject = new SearchExistingObject(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    await purchaseInvoiceSteps.goToPurchaseInvoices();
    await searchExistingObject.openFirstResultFromBlankSearch(
      data.purchaseInvoice2.option,
    );
    await purchaseInvoiceSteps.verifyLabelInAllocationDetails();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
