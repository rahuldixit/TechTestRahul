import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { AccountsPayable } from "../../steps/miles/VerifyAccountsPayableSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { CreateNewPurchaseInvoice } from "steps/miles/CreateNewPurchaseInvoiceSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";

test.describe("Verify Accounts Payable,  @regression , @milesregression", async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: MilesLogin;
  let accountsPayable: AccountsPayable;
  let search: SearchExistingObject;
  let purchaseInvoice: CreateNewPurchaseInvoice;

  test("Verify the successful creation of vendor credit notes, @EM-307", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    accountsPayable = new AccountsPayable(page);
    search = new SearchExistingObject(page);
    purchaseInvoice = new CreateNewPurchaseInvoice(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    await accountsPayable.goToAPPurchaseInvoices();
    await search.searchSupplierInvoices({
      option: "Find supplier invoices",
      invoiceStatuses: "Allocated, Approved, Posted",
    });
    await accountsPayable.clickCreditNoteInDesputeSection(
      "IN - Request Credit Note",
    );
    await purchaseInvoice.enterInvoiceNumber();
    await purchaseInvoice.postPurchaseInvoice();
    await purchaseInvoice.verifyInvoiceType("Credit Note");
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
