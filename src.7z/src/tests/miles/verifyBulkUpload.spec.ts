import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { MilesBulkOperationsSteps } from "../../steps/miles/MilesBulkOperationsSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import moment from "moment";

test.describe("Verify Bulk Upload tests, @regression4, @milesregression", async () => {
  let login: MilesLogin;
  test.setTimeout(5 * 60 * 1000);

  test(`Validate that Citylink connector (SGAU_CityLink_GLIDe_TollInvoice_Import) is uploading the toll invoice in Miles with exact transaction times from the loader file, 
  Validate that Citylink connector (SGAU_CityLink_GLIDe_TollInvoice_Import) is uploading the toll invoice in Miles with updated start time and end time in the loader file, @EM-203, @EM-205`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    const bulkOperationsSteps = new MilesBulkOperationsSteps(page);

    const [fileData, filename, startDate, endDate] =
      await bulkOperationsSteps.doctorCityLinkConnectorFile(
        data.bulkOperationsCityLinkConnector.data,
        data.bulkOperationsCityLinkConnector.cons,
      );

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await bulkOperationsSteps.searchBulkOperation(
      "SGAU_CityLink_GLIDe_TollInvoice_Import",
    );

    let targetServer = "";
    let targetShare = "";
    if (APPCONSTANTS.MILES_APP_URL.includes("sgeqdmiles01")) {
      targetServer = data.bulkOperationsCityLinkConnector.targetServerSIT;
      targetShare = data.bulkOperationsCityLinkConnector.targetShareSIT;
    } else {
      targetServer = data.bulkOperationsCityLinkConnector.targetServerUAT;
      targetShare = data.bulkOperationsCityLinkConnector.targetShareUAT;
    }
    await bulkOperationsSteps.processFile(
      fileData,
      filename,
      targetServer,
      targetShare,
    );

    await bulkOperationsSteps.verifySuccessfullyProcessedFileCityLink();
    await bulkOperationsSteps.verifyPIDates(startDate, endDate);
  });

  test(`Validate that Citylink connector is throwing error if duplicate loader file is uploaded, having same date and same transaction time, @EM-204`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    const bulkOperationsSteps = new MilesBulkOperationsSteps(page);

    const [fileData, filename] =
      await bulkOperationsSteps.doctorCityLinkConnectorFile(
        data.bulkOperationsCityLinkConnector.data,
        data.bulkOperationsCityLinkConnector.cons,
      );

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await bulkOperationsSteps.searchBulkOperation(
      "SGAU_CityLink_GLIDe_TollInvoice_Import",
    );

    let targetServer = "";
    let targetShare = "";
    if (APPCONSTANTS.MILES_APP_URL.includes("sgeqdmiles01")) {
      targetServer = data.bulkOperationsCityLinkConnector.targetServerSIT;
      targetShare = data.bulkOperationsCityLinkConnector.targetShareSIT;
    } else {
      targetServer = data.bulkOperationsCityLinkConnector.targetServerUAT;
      targetShare = data.bulkOperationsCityLinkConnector.targetShareUAT;
    }
    await bulkOperationsSteps.processFile(
      fileData,
      filename,
      targetServer,
      targetShare,
    );
    const filename2 = filename.split(".")[0] + "1" + ".txt";
    await bulkOperationsSteps.processFile(
      fileData,
      filename2,
      targetServer,
      targetShare,
    );
    await bulkOperationsSteps.verifyErrorProcessedFile(
      "Duplicate item detected in input-file (Toll Management)",
    );
  });

  test(`Verify the successful automatic upload of bulk AP, @EM-302`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    const bulkOperationsSteps = new MilesBulkOperationsSteps(page);
    const [amount, fieldData] =
      await bulkOperationsSteps.doctorSOFGenericCostImportFile(
        data.bulkOperationsAP.data,
      );

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await bulkOperationsSteps.searchBulkOperation("SOF_Generic_Cost_Import");

    let targetServer = "";
    let targetShare = "";
    if (APPCONSTANTS.MILES_APP_URL.includes("sgeqdmiles01")) {
      targetServer = data.bulkOperationsAP.targetServerSIT;
      targetShare = data.bulkOperationsAP.targetShareSIT;
    } else {
      targetServer = data.bulkOperationsAP.targetServerUAT;
      targetShare = data.bulkOperationsAP.targetShareUAT;
    }
    await bulkOperationsSteps.processFile(
      fieldData,
      data.bulkOperationsAP.cons + moment().format("DDMMYYYYhhmmss") + ".txt",
      targetServer,
      targetShare,
    );

    await bulkOperationsSteps.verifySuccessfullyProcessedFileGenericCostImport();
    await bulkOperationsSteps.verifyPIAmount(amount);
  });

  test(`Verify the successful automatic upload of bulk Billing Item (for Billing Items, that will become Customer Invoices), @EM-303`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    const bulkOperationsSteps = new MilesBulkOperationsSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await bulkOperationsSteps.searchBulkOperation("SOF_BillingItem_Import");

    let targetServer = "";
    let targetShare = "";
    if (APPCONSTANTS.MILES_APP_URL.includes("sgeqdmiles01")) {
      targetServer = data.bulkOperationsBillingItems.targetServerSIT;
      targetShare = data.bulkOperationsBillingItems.targetShareSIT;
    } else {
      targetServer = data.bulkOperationsBillingItems.targetServerUAT;
      targetShare = data.bulkOperationsBillingItems.targetShareUAT;
    }
    await bulkOperationsSteps.processFile(
      data.bulkOperationsBillingItems.data,
      data.bulkOperationsBillingItems.cons +
        moment().format("DDMMYYYYhhmmss") +
        ".txt",
      targetServer,
      targetShare,
    );

    await bulkOperationsSteps.verifySuccessfullyProcessedFileBillingItems();
    const dataFields = data.bulkOperationsBillingItems.data.split(",");
    await bulkOperationsSteps.verifyBillingItems(dataFields[2], dataFields[5]);
  });

  test(`Verify the successful automatic upload of bulk Sundry Payment Document (for general journal entries - create general ledger),
  Verify the successful creation of  general ledger, @EM-304, @EM-305`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    const bulkOperationsSteps = new MilesBulkOperationsSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await bulkOperationsSteps.searchBulkOperation(
      "SOF_SundryPaymentDocument_Import",
    );

    let targetServer = "";
    let targetShare = "";
    if (APPCONSTANTS.MILES_APP_URL.includes("sgeqdmiles01")) {
      targetServer = data.bulkOperationsSundryPayment.targetServerSIT;
      targetShare = data.bulkOperationsSundryPayment.targetShareSIT;
    } else {
      targetServer = data.bulkOperationsSundryPayment.targetServerUAT;
      targetShare = data.bulkOperationsSundryPayment.targetShareUAT;
    }
    await bulkOperationsSteps.processFile(
      data.bulkOperationsSundryPayment.data,
      data.bulkOperationsSundryPayment.cons +
        moment().format("DDMMYYYYhhmmss") +
        ".txt",
      targetServer,
      targetShare,
      true,
    );

    const paymentID =
      await bulkOperationsSteps.verifySuccessfullyProcessedFileSundryPayments();
    await bulkOperationsSteps.verifySundryPayment(paymentID);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
