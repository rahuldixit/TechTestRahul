import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { ModifyContract } from "../../steps/miles/ModifyContractSteps";
import { CreateNewPurchaseInvoice } from "../../steps/miles/CreateNewPurchaseInvoiceSteps";
import { PayAllInvoices } from "../../steps/miles/PayAllInvoiceSteps";
import { DeliverTheVehicle } from "../../steps/miles/DeliverVehicleSteps";
import { VerifyContractRunning } from "../../steps/miles/VerifyContractRunningSteps";
import { CreateNewVehicleOrder } from "../../steps/miles/CreateNewVehicleOrderSteps";
import { CreateNewContact } from "../../steps/miles/CreateNewContactSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { VerifyThirdPartyRenoSteps } from "../../steps/miles/VerifyThirdPartyRenovationQuotesSteps";
import { MilesSearchPage } from "../../pages/miles/MilesSearchPage";
import { faker } from "@faker-js/faker";

test.describe("Verify AP Invoices, @regression2, @milesregression", async () => {
  test.setTimeout(20 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let createContract: CreateNewContract;
  let modifyContract: ModifyContract;
  let createVehicleOrder: CreateNewVehicleOrder;
  let createPurchaseInvoice: CreateNewPurchaseInvoice;
  let payAllInvoices: PayAllInvoices;
  let deliverVehicle: DeliverTheVehicle;
  let verifyContractRunningStatus: VerifyContractRunning;
  let newContactSteps: CreateNewContact;
  let selectExistingContractSteps: SearchExistingObject;
  let searchCustomers: MilesSearchPage;
  let thirdPartyRenoSteps: VerifyThirdPartyRenoSteps;

  test("Verify that Cost Center Transfer can be done successfully for a novated LTC, @EM-346", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    modifyContract = new ModifyContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles8.tradingname,
      template: data.miles8.template,
      vehicleDescp: data.miles8.vehicleDescp,
      duration: data.miles8.duration,
      postCode: data.miles8.postCode,
      state: data.miles8.state,
      leaseG: data.miles8.leaseG,
      faultClaims: data.miles8.faultClaims,
      convictedDUI: data.miles8.convictedDUI,
      negligentDriving: data.miles8.negligentDriving,
      location: data.miles8.location,
      emailAddr: data.miles8.emailAddr,
      contactNum: data.miles8.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles8.fundOption,
      fcreditAuth: data.miles8.fcreditAuth,
    });
    console.log("contract number is: ", contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await modifyContract.modifyContractAndSelectChangeReason(
      "Cost Centre Transfer",
    );
    await modifyContract.costCentreTransfer(data.miles8.toCustomer);
  });

  test("Verify that Novated Asset Assignment can be done successfully for a novated LTC, @EM-347", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    modifyContract = new ModifyContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles8.tradingname,
      template: data.miles8.template,
      vehicleDescp: data.miles8.vehicleDescp,
      duration: data.miles8.duration,
      postCode: data.miles8.postCode,
      state: data.miles8.state,
      leaseG: data.miles8.leaseG,
      faultClaims: data.miles8.faultClaims,
      convictedDUI: data.miles8.convictedDUI,
      negligentDriving: data.miles8.negligentDriving,
      location: data.miles8.location,
      emailAddr: data.miles8.emailAddr,
      contactNum: data.miles8.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles8.fundOption,
      fcreditAuth: data.miles8.fcreditAuth,
    });
    console.log("contract number is: ", contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    const driverID = await modifyContract.reAssignDriver(
      data.miles8.newBusinessUnitID,
    );
    await createContract.milesContractPage.clickBottomTab("LTC");
    await modifyContract.modifyContractAndSelectChangeReason(
      "Novated Asset Assignment",
    );
    await modifyContract.novatedAssetAssignment(
      data.miles8.newBusinessUnitID,
      driverID,
    );
    await modifyContract.validateApproveContractFromQuoteOrAQ();
    await modifyContract.verifyChangeReasonForNewVersion(
      "Novated Asset Assignment",
    );
  });

  test("Verify that Re-novation can be done successfully for a novated LTC, @EM-348", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    modifyContract = new ModifyContract(page);
    payAllInvoices = new PayAllInvoices(page);
    newContactSteps = new CreateNewContact(page);
    selectExistingContractSteps = new SearchExistingObject(page);
    thirdPartyRenoSteps = new VerifyThirdPartyRenoSteps(page);
    searchCustomers = new MilesSearchPage(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await thirdPartyRenoSteps.goToBusinessPartner();

    await searchCustomers.waitUntilLoadingFinishes();
    await selectExistingContractSteps.searchCustomer(data.miles1.tradingname);

    await newContactSteps.createNewDriver();

    const driverFirstName = faker.person.firstName("male");
    const driverLastName = faker.person.lastName("male");

    await newContactSteps.addNewDriver({
      title: data.miles1.title,
      firstName: driverFirstName,
      lastName: driverLastName,
      gender: data.miles1.gender,
      addressType: data.miles1.addressType,
      address: data.miles1.address,
      postCode: data.miles1.postCode,
      suburb: data.miles1.suburb,
      state: data.miles1.state,
      phoneType: data.miles1.phoneType,
      phoneNumber: data.miles1.phoneNumber,
      emailType: data.miles1.emailType,
      mailCategory: data.miles1.mailCategory,
    });

    await createQuote.createQuoteFromContact();

    const quoteNum = await createQuote.createNewMilesQuoteFromContact({
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });
    console.log(quoteNum);
    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });
    console.log("contract number is: ", contractNum);
    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await modifyContract.modifyContract({
      ltc: contractNum,
      changeReason: "De-Novation",
    });

    await modifyContract.changeCustomerSalesRegion(
      data.miles1.salesRegion,
      driverLastName + ", " + driverFirstName,
    );
    await modifyContract.validateApproveContractFromQuoteOrAQ();
    await modifyContract.verifyChangeReasonForNewVersion("De-Novation");

    await modifyContract.modifyContractAndSelectChangeReason("Re-Novation");
    await modifyContract.reNovationAssignment(data.miles8.toCustomer);
    await modifyContract.validateApproveContractFromQuoteOrAQ();
    await modifyContract.verifyChangeReasonForNewVersion("Re-Novation");
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test("Verify that De-novation can be done successfully for a novated LTC, @EM-349", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    modifyContract = new ModifyContract(page);
    payAllInvoices = new PayAllInvoices(page);
    newContactSteps = new CreateNewContact(page);
    selectExistingContractSteps = new SearchExistingObject(page);
    thirdPartyRenoSteps = new VerifyThirdPartyRenoSteps(page);
    searchCustomers = new MilesSearchPage(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await thirdPartyRenoSteps.goToBusinessPartner();

    await searchCustomers.waitUntilLoadingFinishes();
    await selectExistingContractSteps.searchCustomer(data.miles1.tradingname);

    await newContactSteps.createNewDriver();

    const driverFirstName = faker.person.firstName("male");
    const driverLastName = faker.person.firstName("male");

    await newContactSteps.addNewDriver({
      title: data.miles1.title,
      firstName: driverFirstName,
      lastName: driverLastName,
      gender: data.miles1.gender,
      addressType: data.miles1.addressType,
      address: data.miles1.address,
      postCode: data.miles1.postCode,
      suburb: data.miles1.suburb,
      state: data.miles1.state,
      phoneType: data.miles1.phoneType,
      phoneNumber: data.miles1.phoneNumber,
      emailType: data.miles1.emailType,
      mailCategory: data.miles1.mailCategory,
    });

    await createQuote.createQuoteFromContact();

    const quoteNum = await createQuote.createNewMilesQuoteFromContact({
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });
    console.log(quoteNum);
    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });
    console.log("contract number is: ", contractNum);
    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await modifyContract.modifyContract({
      ltc: contractNum,
      changeReason: "De-Novation",
    });

    await modifyContract.changeCustomerSalesRegion(
      data.miles1.salesRegion,
      driverLastName + ", " + driverFirstName,
    );
    await modifyContract.validateApproveContractFromQuoteOrAQ();
    await modifyContract.verifyChangeReasonForNewVersion("De-Novation");
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
