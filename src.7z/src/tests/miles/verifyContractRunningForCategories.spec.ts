import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { CreateNewVehicleOrder } from "../../steps/miles/CreateNewVehicleOrderSteps";
import { PayAllInvoices } from "../../steps/miles/PayAllInvoiceSteps";
import { DeliverTheVehicle } from "../../steps/miles/DeliverVehicleSteps";
import { VerifyContractRunning } from "../../steps/miles/VerifyContractRunningSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";

test.describe(`Verify that the status of the contract should be changed to "Running" from "Initialized, @regression2, @milesRegression`, async () => {
  test.setTimeout(10 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let existingContract: SearchExistingObject;
  let createContract: CreateNewContract;
  let createVehicleOrder: CreateNewVehicleOrder;
  let payAllInvoices: PayAllInvoices;
  let deliverVehicle: DeliverTheVehicle;
  let verifyContractRunningStatus: VerifyContractRunning;

  test(`Verify that the status of the contract should be changed to "Running" from "Initialized for a Budgeted contract category, @EM-340`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    existingContract = new SearchExistingObject(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const contractRefNum = await existingContract.openAnExistingContract({
      option: data.existingcontract3.option,
      product: data.existingcontract3.product,
      contractStatus: data.existingcontract3.contractStatus,
      category: data.existingcontract3.category,
      tradingName: data.existingcontract3.tradingName,
    });

    const quoteNum = await createContract.copyContract();
    console.log("Quote Number is: " + quoteNum);
    await createContract.verifyContractCategory(
      data.existingcontract3.category,
      quoteNum,
    );

    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    console.log(contractRefNum);
  });

  test(`Verify that the status of the contract should be changed to "Running" from "Initialized for a Invoiced contract category, @EM-341`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    existingContract = new SearchExistingObject(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const contractRefNum = await existingContract.openAnExistingContract({
      option: data.existingcontract4.option,
      contractStatus: data.existingcontract4.contractStatus,
      category: data.existingcontract4.category,
      tradingName: data.existingcontract4.tradingName,
    });

    const quoteNum = await createContract.copyContract();
    console.log("Quote Number is: " + quoteNum);
    await createContract.verifyContractCategory(
      data.existingcontract4.category,
      quoteNum,
    );

    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    console.log(contractRefNum);
  });

  test(`Verify that the status of the contract should be changed to "Running" from "Initialized for a Do and Charge contract category, @EM-342`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    existingContract = new SearchExistingObject(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const contractRefNum = await existingContract.openAnExistingContract({
      option: data.existingcontract5.option,
      contractStatus: data.existingcontract5.contractStatus,
      category: data.existingcontract5.category,
      tradingName: data.existingcontract5.tradingName,
      vehicle: data.existingcontract5.vehicle,
    });

    const quoteNum = await createContract.copyContract();
    console.log("Quote Number is: " + quoteNum);
    await createContract.verifyContractCategory(
      data.existingcontract5.category,
      quoteNum,
    );

    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles1.fundOption,
      fcreditAuth: data.miles1.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles1.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    console.log(contractRefNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
