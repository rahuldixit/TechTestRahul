import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { APPCONSTANTS } from "../../app.constants";
import { NEW_QUOTE_VEHICLE_LABELS } from "../../../enums/milesapp";
import { test, expect } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { ModifyContract } from "../../steps/miles/ModifyContractSteps";

test.describe("Verify that when vehicle meets ZLEV exempt eligibility, @regression2 , @milesregression", async () => {
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let createContract: CreateNewContract;
  let modifyContract: ModifyContract;

  test("Verify in Request Quote that the given roles are able to edit the Manual FBT Value and Manual FBT Status fields, @EM-67", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
    });

    await createQuote.editManualFBTFields({
      manualFBTValue: data.miles1.manualFBTValue,
      manualFBTStatus: data.miles1.manualFBTStatus,
    });

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_VALUE,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ),
    ).toBe(Number(data.miles1.manualFBTValue));
    expect(
      await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_STATUS,
      ),
    ).toBe(data.miles1.manualFBTStatus);
    console.log("quote num is :", quoteNum);
  });

  test("Verify in Amendment Quote(PAR) that the given roles are able to edit the Manual FBT Value and Manual FBT Status, @EM-68", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    modifyContract = new ModifyContract(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });

    const fundOption = "CBA (P&A) - Disclosed";
    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: fundOption,
      fcreditAuth: fundOption + " - Test",
    });

    // Modify Contract - Initialized Status
    const changeReason = "Pre Activation Restructure";
    await modifyContract.modifyContract({
      ltc: contractNum,
      changeReason: changeReason,
    });

    await createQuote.editManualFBTFields({
      manualFBTValue: data.miles1.manualFBTValue,
      manualFBTStatus: data.miles1.manualFBTStatus,
    });

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_VALUE,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ),
    ).toBe(Number(data.miles1.manualFBTValue));
    expect(
      await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
        NEW_QUOTE_VEHICLE_LABELS.MANUAL_FBT_STATUS,
      ),
    ).toBe(data.miles1.manualFBTStatus);
    console.log("quote num is :", quoteNum);
  });

  test("Verify that on updating Manual FBT Value, the FBT Base Value is updated to the Manual FBT Value and the FBT after 4 Years is updated as 2/3rd of the FBT Base Value in Request Quote, @EM-69", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      hasGrossAnnualSalary: true,
    });

    await createQuote.editManualFBTFields({
      manualFBTValue: data.miles1.manualFBTValue,
      manualFBTStatus: data.miles1.manualFBTStatus,
    });

    await createQuote.calculateQuote();

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.FBT_BASE_VALUE,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ),
    ).toBe(Number(data.miles1.manualFBTValue));

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.FBT4YEARS,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ).toFixed(2),
    ).toBe(((Number(data.miles1.manualFBTValue) * 2) / 3).toFixed(2));
    console.log("quote num is :", quoteNum);
  });

  test("Verify that on updating Manual FBT Value, the FBT Base Value is updated to the Manual FBT Value and the FBT after 4 Years is updated as 2/3rd of the FBT Base Value in Amendment Quote, @EM-70", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    modifyContract = new ModifyContract(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });

    const fundOption = "CBA (P&A) - Disclosed";
    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: fundOption,
      fcreditAuth: fundOption + " - Test",
    });

    // Modify Contract - Initialized Status
    const changeReason = "Pre Activation Restructure";
    await modifyContract.modifyContract({
      ltc: contractNum,
      changeReason: changeReason,
    });

    await createQuote.editManualFBTFields({
      manualFBTValue: data.miles1.manualFBTValue,
      manualFBTStatus: data.miles1.manualFBTStatus,
    });

    await createQuote.calculateQuote();

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.FBT_BASE_VALUE,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ),
    ).toBe(Number(data.miles1.manualFBTValue));

    expect(
      Number(
        (
          await createQuote.milesNewSalesRequestPage.retrieveValueByLabel(
            NEW_QUOTE_VEHICLE_LABELS.FBT4YEARS,
          )
        )
          .replace("$", "")
          .replace(",", ""),
      ).toFixed(2),
    ).toBe(((Number(data.miles1.manualFBTValue) * 2) / 3).toFixed(2));

    console.log("quote num is :", quoteNum);
  });

  test("Verify that the Manual FBT Status field should be populated in order to save the Manual FBT Value in Amendment Quote, @EM-72", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    modifyContract = new ModifyContract(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createNewMilesQuote({
      tradingname: data.miles1.tradingname,
      template: data.miles1.template,
      vehicleDescp: data.miles1.vehicleDescp,
      duration: data.miles1.duration,
      postCode: data.miles1.postCode,
      state: data.miles1.state,
      leaseG: data.miles1.leaseG,
      faultClaims: data.miles1.faultClaims,
      convictedDUI: data.miles1.convictedDUI,
      negligentDriving: data.miles1.negligentDriving,
      location: data.miles1.location,
      emailAddr: data.miles1.emailAddr,
      contactNum: data.miles1.contactNum,
    });

    const fundOption = "CBA (P&A) - Disclosed";
    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: fundOption,
      fcreditAuth: fundOption + " - Test",
    });

    // Modify Contract - Initialized Status
    const changeReason = "Pre Activation Restructure";
    await modifyContract.modifyContract({
      ltc: contractNum,
      changeReason: changeReason,
    });

    await createQuote.editManualFBTFields({
      manualFBTValue: data.miles1.manualFBTValue,
      tab: "AQ",
    });

    await createQuote.calculateQuote();
    await createQuote.milesNewSalesRequestPage.btnValidate.click({
      timeout: 60000,
    });
    await createQuote.milesNewSalesRequestPage.waitUntilLoadingFinishes(30);

    const errormsg =
      await createQuote.milesNewSalesRequestPage.getSystemErrorMsg();
    expect(errormsg).toContain(
      "Quotation Template : Manual FBT approval is required as a value has been entered in Manual FBT Override - Template rule violation",
    );

    console.log("quote num is :", quoteNum);
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
