import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { CreateNewVehicleOrder } from "../../steps/miles/CreateNewVehicleOrderSteps";
import { CreateNewPurchaseInvoice } from "../../steps/miles/CreateNewPurchaseInvoiceSteps";
import { ExistingVehicleOrder } from "../../steps/miles/ExistingVehicleOrderSteps";
import { DeliverTheVehicle } from "../../steps/miles/DeliverVehicleSteps";
import { VerifyContractRunning } from "../../steps/miles/VerifyContractRunningSteps";
import { APPCONSTANTS } from "../../app.constants";
import { expect, test } from "@playwright/test";
import * as data from "./testdata/milesData.json";

test.describe("Verify that user is able to activate contract for Funder Autonomy,  @regression3 , @milesregression", async () => {
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let createContract: CreateNewContract;
  let createVehicleOrder: CreateNewVehicleOrder;
  let createPurchaseInvoice: CreateNewPurchaseInvoice;
  let existingVehicleOrder: ExistingVehicleOrder;
  let deliverVehicle: DeliverTheVehicle;
  let verifyContractRunningStatus: VerifyContractRunning;

  test("Verify that user is able to activate contract with freeform aftermarket, @EM-183", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    existingVehicleOrder = new ExistingVehicleOrder(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });
    const equipmentType = "Accessory";
    await createQuote.milesNewSalesRequestPage.clickEditEquipment();
    await createQuote.addFreeformEquipment(equipmentType);
    await createQuote.calculateValidateApproveQuote({
      location: data.miles2.location,
      emailAddr: data.miles2.emailAddr,
      contactNum: data.miles2.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles2.fundOption,
      fcreditAuth: data.miles2.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles2.supplier,
      insuranceType: data.miles2.insuranceType,
      tradingOrderStatus: data.miles2.tradingOrderStatus,
    });

    await createPurchaseInvoice.createNewPurchaseInvoiceAutonomy({
      ltc: contractNum,
    });

    await existingVehicleOrder.approveExistingVehicleOrder({
      ltc: contractNum,
    });
    await createPurchaseInvoice.createNewPurchaseInvoiceFromExistingVO();
    await createPurchaseInvoice.postPurchaseInvoiceForExistingVO();

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
    await verifyContractRunningStatus.verifyFreeform(equipmentType);
  });

  test("Verify user is able to activate contract with Manual RV Override, @EM-184", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    existingVehicleOrder = new ExistingVehicleOrder(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });
    const manualRVOverrideStatus = "Manual Override Allowed - Request Quote";
    await createQuote.addManualOverride(manualRVOverrideStatus);
    await createQuote.calculateValidateApproveQuote({
      location: data.miles2.location,
      emailAddr: data.miles2.emailAddr,
      contactNum: data.miles2.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles2.fundOption,
      fcreditAuth: data.miles2.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles2.supplier,
      insuranceType: data.miles2.insuranceType,
      tradingOrderStatus: data.miles2.tradingOrderStatus,
    });

    await createPurchaseInvoice.createNewPurchaseInvoiceAutonomy({
      ltc: contractNum,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
    await verifyContractRunningStatus.verifyManualOverride(
      manualRVOverrideStatus,
    );
  });

  test("Verify that user is able to activate contract with vehicle adjustment > 0 and <= lower threshold amount, @EM-185", async ({
    page,
  }) => {
    //SIT Threshold is around 300
    //UAT Threshold is 200
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    existingVehicleOrder = new ExistingVehicleOrder(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });
    await createQuote.calculateValidateApproveQuote({
      location: data.miles2.location,
      emailAddr: data.miles2.emailAddr,
      contactNum: data.miles2.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles2.fundOption,
      fcreditAuth: data.miles2.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles2.supplier,
      insuranceType: data.miles2.insuranceType,
      tradingOrderStatus: data.miles2.tradingOrderStatus,
    });

    await createPurchaseInvoice.createPIWithVehicleAdjustment({
      ltc: contractNum,
      priceAdjustment: 200,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningStatus({
      ltc: contractNum,
    });
    await verifyContractRunningStatus.verifyPendingQuotesIsEmpty();
    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
  });

  test("Verify that user is able to activate contract with vehicle adjustment > $299, @EM-186", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    existingVehicleOrder = new ExistingVehicleOrder(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });
    await createQuote.calculateValidateApproveQuote({
      location: data.miles2.location,
      emailAddr: data.miles2.emailAddr,
      contactNum: data.miles2.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles2.fundOption,
      fcreditAuth: data.miles2.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles2.supplier,
      insuranceType: data.miles2.insuranceType,
      tradingOrderStatus: data.miles2.tradingOrderStatus,
    });

    await createPurchaseInvoice.createPIWithVehicleAdjustment({
      ltc: contractNum,
      priceAdjustment: 300,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningStatus({
      ltc: contractNum,
    });
    await verifyContractRunningStatus.verifyPendingQuotesIsNotEmpty();
    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
  });

  test("Verify user is able to activate contract with Manual Standard Interest Margin, @EM-187", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    existingVehicleOrder = new ExistingVehicleOrder(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });

    const manualIntestStatus = "Manual Override Allowed - Request Quote";
    await createQuote.addManualStandardInterestMargin(manualIntestStatus);
    await createQuote.calculateValidateApproveQuote({
      location: data.miles2.location,
      emailAddr: data.miles2.emailAddr,
      contactNum: data.miles2.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles2.fundOption,
      fcreditAuth: data.miles2.fcreditAuth,
    });

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles2.supplier,
      insuranceType: data.miles2.insuranceType,
      tradingOrderStatus: data.miles2.tradingOrderStatus,
    });

    await createPurchaseInvoice.createNewPurchaseInvoiceAutonomy({
      ltc: contractNum,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
    await verifyContractRunningStatus.verifyManualInterestMargin(
      manualIntestStatus,
    );
  });

  test("Verify user is able to tick/untick Funder Pre-Approval Granted?, @EM-189", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await createQuote.createFirstPartOfQuote({
      tradingname: data.miles2.tradingname,
      bpID: data.miles2.bpID,
      template: data.miles2.template,
      vehicleDescp: data.miles2.vehicleDescp,
      duration: data.miles2.duration,
      postCode: data.miles2.postCode,
      state: data.miles2.state,
    });

    await createQuote.milesNewSalesRequestPage.toggleFunderPreApprovalGranted();
    expect(
      await createQuote.milesNewSalesRequestPage.checkBoxValueFunderPreApprovalGranted.getAttribute(
        "src",
      ),
    ).not.toContain("unchecked");
    await createQuote.milesNewSalesRequestPage.toggleFunderPreApprovalGranted();
    expect(
      await createQuote.milesNewSalesRequestPage.checkBoxValueFunderPreApprovalGranted.getAttribute(
        "src",
      ),
    ).toContain("unchecked");
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
