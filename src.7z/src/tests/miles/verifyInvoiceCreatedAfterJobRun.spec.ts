import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { ContractDataSteps } from "../../steps/miles/VerifyContractDataSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";

test.describe("Verify that invoice is created after job run,  @regression4 , @milesregression", async () => {
  // Long timout to help accomodate the search being extremely slow sometimes. Otherwise the test only takes 60 seconds.
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let existingContract: SearchExistingObject;
  let contractDataSteps: ContractDataSteps;

  test("Verify that daily invoice is created after job run, @EM-325", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    existingContract = new SearchExistingObject(page);
    contractDataSteps = new ContractDataSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const contractNum =
      await existingContract.getAndOpenExistingContractAfterJobRun({
        option: data.existingcontract6.option,
        customerName: data.existingcontract6.tradingName,
        contractStatus: data.existingcontract6.contractStatus,
        billableStatus: data.existingcontract6.billableStatus,
        startDate: (await contractDataSteps.getPreviousWorkday()).format(
          "DD/MM/YYYY 00:00",
        ),
      });
    console.log("EM-325 contractNum: " + contractNum);

    await contractDataSteps.goToBillingOverviewFromLTC();
    await contractDataSteps.selectServiceTypeAndSearch("Net Rental");
    await contractDataSteps.verifyInvoiceNRIsPopulated();
  });

  test("Verify that consolidated invoice is created after the job run, @EM-309", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    existingContract = new SearchExistingObject(page);
    contractDataSteps = new ContractDataSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const contractNum =
      await existingContract.getAndOpenExistingContractAfterJobRun({
        option: data.existingcontract6.option,
        customerName: data.existingcontract6.tradingName,
        contractStatus: data.existingcontract6.contractStatus,
        billableStatus: data.existingcontract6.billableStatus,
        startDate: (await contractDataSteps.getPreviousWorkday()).format(
          "DD/MM/YYYY 00:00",
        ),
      });
    console.log("EM-309 contractNum: " + contractNum);

    await contractDataSteps.goToBillingOverviewFromLTC();
    await contractDataSteps.selectServiceTypeAndSearch("Insurance");
    await contractDataSteps.verifyInvoiceNRIsPopulated();
    await contractDataSteps.verifyCusInvoiceNumberIsPopulated("AUS");
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
