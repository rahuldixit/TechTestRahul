import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { CreateNewVehicleOrder } from "../../steps/miles/CreateNewVehicleOrderSteps";
import { CreateNewPurchaseInvoice } from "../../steps/miles/CreateNewPurchaseInvoiceSteps";
import { PayAllInvoices } from "../../steps/miles/PayAllInvoiceSteps";
import { DeliverTheVehicle } from "../../steps/miles/DeliverVehicleSteps";
import { VerifyContractRunning } from "../../steps/miles/VerifyContractRunningSteps";
import { VerifyServiceOptionRecalculated } from "../../steps/miles/VerifyServiceOptionRecalculatedSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import moment from "moment";

test.describe("Verify service option is recalculated on activation stage,  @regression3 , @milesregression", async () => {
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let createContract: CreateNewContract;
  let createVehicleOrder: CreateNewVehicleOrder;
  let createPurchaseInvoice: CreateNewPurchaseInvoice;
  let payAllInvoices: PayAllInvoices;
  let deliverVehicle: DeliverTheVehicle;
  let verifyContractRunningStatus: VerifyContractRunning;
  let verifyServiceOption: VerifyServiceOptionRecalculated;

  test("Verify lease guard service option is recalculated on activation stage for current date contract, @EM-63", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    verifyServiceOption = new VerifyServiceOptionRecalculated(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles3.tradingname,
      template: data.miles3.template,
      vehicleDescp: data.miles3.vehicleDescp,
      duration: data.miles3.duration,
      postCode: data.miles3.postCode,
      state: data.miles3.state,
      hasGrossAnnualSalary: data.miles3.hasGrossAnnualSalary,
      hasDriver: data.miles3.hasDriver,
      leaseG: data.miles3.leaseG,
      faultClaims: data.miles3.faultClaims,
      convictedDUI: data.miles3.convictedDUI,
      negligentDriving: data.miles3.negligentDriving,
    });

    //Add service option
    const serviceOption = "- Included - LeaseGuard";
    await createQuote.editLeaseServiceOptions({
      expandService1: "Services (AU)",
      expandService2: "LeaseGuard (AU)",
      removeService: "- None - LeaseGuard",
      addService: serviceOption,
    });

    await createQuote.calculateValidateApproveQuote({
      location: data.miles3.location,
      emailAddr: data.miles3.emailAddr,
      contactNum: data.miles3.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles3.fundOption,
      fcreditAuth: data.miles3.fcreditAuth,
    });
    console.log("Contract Number: " + contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await verifyServiceOption.verifyServiceOptionRecalculated({
      ltc: contractNum,
      serviceOption: serviceOption,
    });
  });

  test("Verify lease guard service option is recalculated on activation stage for back date contract, @EM-64", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    verifyServiceOption = new VerifyServiceOptionRecalculated(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles3.tradingname,
      template: data.miles3.template,
      vehicleDescp: data.miles3.vehicleDescp,
      duration: data.miles3.duration,
      postCode: data.miles3.postCode,
      state: data.miles3.state,
      hasGrossAnnualSalary: data.miles3.hasGrossAnnualSalary,
      hasDriver: data.miles3.hasDriver,
      leaseG: data.miles3.leaseG,
      faultClaims: data.miles3.faultClaims,
      convictedDUI: data.miles3.convictedDUI,
      negligentDriving: data.miles3.negligentDriving,
    });

    //Add service option
    const serviceOption = "- Included - LeaseGuard";
    await createQuote.editLeaseServiceOptions({
      expandService1: "Services (AU)",
      expandService2: "LeaseGuard (AU)",
      removeService: "- None - LeaseGuard",
      addService: serviceOption,
    });

    await createQuote.calculateValidateApproveQuote({
      location: data.miles3.location,
      emailAddr: data.miles3.emailAddr,
      contactNum: data.miles3.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles3.fundOption,
      fcreditAuth: data.miles3.fcreditAuth,
    });
    console.log("Contract Number: " + contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    // Use back date for contract
    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
      registrationDate: moment().subtract(1, "year").format("DD/MM/YYYY"),
      deliveryDate: moment().subtract(3, "weeks").format("DD/MM/YYYY"),
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await verifyServiceOption.verifyServiceOptionRecalculated({
      ltc: contractNum,
      serviceOption: serviceOption,
    });
  });

  test("Verify Vero insurance service option is recalculated on activation stage for back date contract, @EM-65", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    verifyServiceOption = new VerifyServiceOptionRecalculated(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles3.tradingname,
      template: data.miles3.template,
      vehicleDescp: data.miles3.vehicleDescp,
      duration: data.miles3.duration,
      postCode: data.miles3.postCode,
      state: data.miles3.state,
      hasGrossAnnualSalary: data.miles3.hasGrossAnnualSalary,
      hasDriver: data.miles3.hasDriver,
      leaseG: data.miles3.leaseG,
      faultClaims: data.miles3.faultClaims,
      convictedDUI: data.miles3.convictedDUI,
      negligentDriving: data.miles3.negligentDriving,
    });

    //Add service option
    const serviceOption =
      "- Do And Charge with Provision - Annual Comprehensive Insurance (Vero-NLCi)";
    await createQuote.editLeaseServiceOptions({
      expandService1: "Services (AU)",
      expandService2: "Comprehensive Insurance",
      removeService: "- Budgeted - Annual Comprehensive Insurance (Vero-NLCi)",
      addService: serviceOption,
    });

    await createQuote.calculateValidateApproveQuote({
      location: data.miles3.location,
      emailAddr: data.miles3.emailAddr,
      contactNum: data.miles3.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles3.fundOption,
      fcreditAuth: data.miles3.fcreditAuth,
    });
    console.log("Contract Number: " + contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await verifyServiceOption.verifyServiceOptionRecalculated({
      ltc: contractNum,
      serviceOption: serviceOption,
    });
  });

  test("Verify Vero insurance service option is recalculated on activation stage for back date contract, @EM-66", async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    createContract = new CreateNewContract(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    createPurchaseInvoice = new CreateNewPurchaseInvoice(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);
    verifyServiceOption = new VerifyServiceOptionRecalculated(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    const quoteNum = await createQuote.createFirstPartOfQuote({
      tradingname: data.miles3.tradingname,
      template: data.miles3.template,
      vehicleDescp: data.miles3.vehicleDescp,
      duration: data.miles3.duration,
      postCode: data.miles3.postCode,
      state: data.miles3.state,
      hasGrossAnnualSalary: data.miles3.hasGrossAnnualSalary,
      hasDriver: data.miles3.hasDriver,
      leaseG: data.miles3.leaseG,
      faultClaims: data.miles3.faultClaims,
      convictedDUI: data.miles3.convictedDUI,
      negligentDriving: data.miles3.negligentDriving,
    });

    //Add service option
    const serviceOption =
      "- Do And Charge with Provision - Annual Comprehensive Insurance (Vero-NLCi)";
    await createQuote.editLeaseServiceOptions({
      expandService1: "Services (AU)",
      expandService2: "Comprehensive Insurance",
      removeService: "- Budgeted - Annual Comprehensive Insurance (Vero-NLCi)",
      addService: serviceOption,
    });

    await createQuote.calculateValidateApproveQuote({
      location: data.miles3.location,
      emailAddr: data.miles3.emailAddr,
      contactNum: data.miles3.contactNum,
    });

    const contractNum = await createContract.createNewMilesContract({
      quoteNum: quoteNum,
      fundOption: data.miles3.fundOption,
      fcreditAuth: data.miles3.fcreditAuth,
    });
    console.log("Contract Number: " + contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    await createPurchaseInvoice.createNewPurchaseInvoice({
      ltc: contractNum,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles3.supplier,
    });

    // Use back date for contract
    await deliverVehicle.deliverVehicle({
      ltc: contractNum,
      registrationDate: moment().subtract(1, "year").format("DD/MM/YYYY"),
      deliveryDate: moment().subtract(3, "weeks").format("DD/MM/YYYY"),
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });

    await verifyServiceOption.verifyServiceOptionRecalculated({
      ltc: contractNum,
      serviceOption: serviceOption,
    });
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
