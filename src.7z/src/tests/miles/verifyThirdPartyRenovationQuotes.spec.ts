import { MilesLogin } from "../../steps/miles/MilesLoginSteps";
import { APPCONSTANTS } from "../../app.constants";
import { test } from "@playwright/test";
import * as data from "./testdata/milesData.json";
import { CreateNewQuote } from "../../steps/miles/CreateNewQuoteSteps";
import { MilesSearchPage } from "../../pages/miles/MilesSearchPage";
import { faker } from "@faker-js/faker";
import moment from "moment";
import { CreateNewContract } from "../../steps/miles/CreateNewContractSteps";
import { CreateNewContact } from "../../steps/miles/CreateNewContactSteps";
import { SearchExistingObject } from "../../steps/miles/SearchExistingObjectSteps";
import { VerifyThirdPartyRenoSteps } from "../../steps/miles/VerifyThirdPartyRenovationQuotesSteps";
import { CreateNewVehicleOrder } from "../../steps/miles/CreateNewVehicleOrderSteps";
import { PayAllInvoices } from "../../steps/miles/PayAllInvoiceSteps";
import { DeliverTheVehicle } from "../../steps/miles/DeliverVehicleSteps";
import { VerifyContractRunning } from "../../steps/miles/VerifyContractRunningSteps";

test.describe(`Verify third party reno quotes, @regression3, @milesRegression`, async () => {
  test.setTimeout(15 * 60 * 1000);
  let login: MilesLogin;
  let createQuote: CreateNewQuote;
  let searchCustomers: MilesSearchPage;
  let createContract: CreateNewContract;
  let newContactSteps: CreateNewContact;
  let selectExistingContractSteps: SearchExistingObject;
  let thirdPartyRenoSteps: VerifyThirdPartyRenoSteps;
  let createVehicleOrder: CreateNewVehicleOrder;
  let payAllInvoices: PayAllInvoices;
  let deliverVehicle: DeliverTheVehicle;
  let verifyContractRunningStatus: VerifyContractRunning;

  test(`Verify that  new quote can be created for third party renovation with Quote Template: Novated Fleet Managed - T2P (Used for every Miles 3rd Party Reno), @EM-345`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    searchCustomers = new MilesSearchPage(page);
    newContactSteps = new CreateNewContact(page);
    selectExistingContractSteps = new SearchExistingObject(page);
    thirdPartyRenoSteps = new VerifyThirdPartyRenoSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await thirdPartyRenoSteps.goToBusinessPartner();

    await searchCustomers.waitUntilLoadingFinishes();
    await selectExistingContractSteps.searchCustomer(data.miles7.tradingname);
    await newContactSteps.createNewDriver();
    await newContactSteps.addNewDriver({
      title: data.miles7.title,
      firstName: faker.person.firstName("male"),
      lastName: faker.person.lastName("male"),
      gender: data.miles7.gender,
      addressType: data.miles7.addressType,
      address: data.miles7.address,
      state: data.miles7.state,
      postCode: data.miles7.postCode,
      suburb: data.miles7.suburb,
      phoneType: data.miles7.phoneType,
      phoneNumber: data.miles7.phoneNumber,
      emailType: data.miles7.emailType,
      mailCategory: data.miles7.mailCategory,
    });

    await newContactSteps.addPerson();
    await createQuote.createQuoteFromNewContact(
      data.miles7.template,
      data.miles7.vehicleDescp,
    );

    await createQuote.vehicleDelivery({
      location: data.miles7.location,
      emailAddr: data.miles7.emailAddr,
      contactNum: data.miles7.contactNum,
      registrationExpiry: moment().add(5, "years").format("DD/MM/YYYY"),
      registrationSuburb: data.miles7.suburb,
      firstRegistrationDate: moment().subtract(5, "years").format("DD/MM/YYYY"),
      currentODO: data.miles7.currentODO,
      licensePlate: data.miles7.licensePlate,
      buildDate: moment().subtract(10, "years").format("DD/MM/YYYY"),
      chasisNumber: faker.string.alpha({
        length: 17,
        casing: "upper",
        exclude: ["I", "O", "Q"],
      }),
    });

    await createQuote.enterAndSaveVehicleDetailsForThirdPartyReno({
      duration: data.miles7.duration,
      distance: data.miles7.distance,
      postCode: data.miles7.postCode,
      state: data.miles7.state,
      grossAnnualSalary: data.miles7.grossAnnualSalary,
      leaseG: data.miles7.leaseG,
      faultClaims: data.miles7.faultClaims,
      convictedDUI: data.miles7.convictedDUI,
      negligentDriving: data.miles7.negligentDriving,
      purchaseType: data.miles7.purchaseType,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: data.miles7.removeService,
      addService: data.miles7.addService,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: "- Budgeted - Annual Comprehensive Insurance (Vero-NLCi)",
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: "Registration (AU)",
      removeService: "- Budgeted - Registration",
      addService: "- None - Registration",
    });

    await createQuote.addThirdPartyLessor(data.miles7.thirdPartyLessor);
    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();
    await createQuote.verifyQuoteStatus();
    console.log("Quote number: " + (await createQuote.retrieveQuoteNumber()));
  });

  test(`Verify that  LTC can be created(Initialized) for third party renovation with Quote Template: Novated Fleet Managed - T2P (Used for every Miles 3rd Party Reno), @EM-344`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    searchCustomers = new MilesSearchPage(page);
    newContactSteps = new CreateNewContact(page);
    selectExistingContractSteps = new SearchExistingObject(page);
    createContract = new CreateNewContract(page);
    thirdPartyRenoSteps = new VerifyThirdPartyRenoSteps(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await thirdPartyRenoSteps.goToBusinessPartner();

    await searchCustomers.waitUntilLoadingFinishes();
    await selectExistingContractSteps.searchCustomer(data.miles7.tradingname);

    await newContactSteps.createNewDriver();
    await newContactSteps.addNewDriver({
      title: data.miles7.title,
      firstName: faker.person.firstName("male"),
      lastName: faker.person.lastName("male"),
      gender: data.miles7.gender,
      addressType: data.miles7.addressType,
      address: data.miles7.address,
      postCode: data.miles7.postCode,
      suburb: data.miles7.suburb,
      state: data.miles7.state,
      phoneType: data.miles7.phoneType,
      phoneNumber: data.miles7.phoneNumber,
      emailType: data.miles7.emailType,
      mailCategory: data.miles7.mailCategory,
    });

    await newContactSteps.addPerson();
    await createQuote.createQuoteFromNewContact(
      data.miles7.template,
      data.miles7.vehicleDescp,
    );

    await createQuote.vehicleDelivery({
      location: data.miles7.location,
      emailAddr: data.miles7.emailAddr,
      contactNum: data.miles7.contactNum,
      registrationExpiry: moment().add(5, "years").format("DD/MM/YYYY"),
      registrationSuburb: data.miles7.suburb,
      firstRegistrationDate: moment().subtract(5, "years").format("DD/MM/YYYY"),
      currentODO: data.miles7.currentODO,
      licensePlate: data.miles7.licensePlate,
      buildDate: moment().subtract(10, "years").format("DD/MM/YYYY"),
      chasisNumber: faker.string.alpha({
        length: 17,
        casing: "upper",
        exclude: ["I", "O", "Q"],
      }),
    });
    await createQuote.enterAndSaveVehicleDetailsForThirdPartyReno({
      duration: data.miles7.duration,
      distance: data.miles7.distance,
      postCode: data.miles7.postCode,
      state: data.miles7.state,
      grossAnnualSalary: data.miles7.grossAnnualSalary,
      leaseG: data.miles7.leaseG,
      faultClaims: data.miles7.faultClaims,
      convictedDUI: data.miles7.convictedDUI,
      negligentDriving: data.miles7.negligentDriving,
      purchaseType: data.miles7.purchaseType,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: data.miles7.removeService,
      addService: data.miles7.addService,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: "- Budgeted - Annual Comprehensive Insurance (Vero-NLCi)",
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: "Registration (AU)",
      removeService: "- Budgeted - Registration",
      addService: "- None - Registration",
    });

    await createQuote.addThirdPartyLessor(data.miles7.thirdPartyLessor);
    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();
    await createQuote.verifyQuoteStatus();
    console.log("Quote number: " + (await createQuote.retrieveQuoteNumber()));

    await createContract.createContract();
    console.log(
      "Contract Number: " +
        (await createContract.retrieveContractReferenceNumber()),
    );
  });

  test(`Verify that  LTC can be activated (Initialized->Running)for third party renovation with Quote Template: Novated Fleet Managed - T2P (Used for every Miles 3rd Party Reno), @EM-343`, async ({
    page,
  }) => {
    login = new MilesLogin(page);
    createQuote = new CreateNewQuote(page);
    searchCustomers = new MilesSearchPage(page);
    newContactSteps = new CreateNewContact(page);
    selectExistingContractSteps = new SearchExistingObject(page);
    createContract = new CreateNewContract(page);
    thirdPartyRenoSteps = new VerifyThirdPartyRenoSteps(page);
    createVehicleOrder = new CreateNewVehicleOrder(page);
    payAllInvoices = new PayAllInvoices(page);
    deliverVehicle = new DeliverTheVehicle(page);
    verifyContractRunningStatus = new VerifyContractRunning(page);

    await login.loginIntoMilesApplication(
      APPCONSTANTS.MILES_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );

    await thirdPartyRenoSteps.goToBusinessPartner();

    await searchCustomers.waitUntilLoadingFinishes();
    await selectExistingContractSteps.searchCustomer(data.miles7.tradingname);

    await newContactSteps.createNewDriver();
    await newContactSteps.addNewDriver({
      title: data.miles7.title,
      firstName: faker.person.firstName("male"),
      lastName: faker.person.lastName("male"),
      gender: data.miles7.gender,
      addressType: data.miles7.addressType,
      address: data.miles7.address,
      postCode: data.miles7.postCode,
      suburb: data.miles7.suburb,
      state: data.miles7.state,
      phoneType: data.miles7.phoneType,
      phoneNumber: data.miles7.phoneNumber,
      emailType: data.miles7.emailType,
      mailCategory: data.miles7.mailCategory,
    });

    await newContactSteps.addPerson();
    await createQuote.createQuoteFromNewContact(
      data.miles7.template,
      data.miles7.vehicleDescp,
    );

    await createQuote.vehicleDelivery({
      location: data.miles7.location,
      emailAddr: data.miles7.emailAddr,
      contactNum: data.miles7.contactNum,
      registrationExpiry: moment().add(5, "years").format("DD/MM/YYYY"),
      registrationSuburb: data.miles7.suburb,
      firstRegistrationDate: moment().subtract(5, "years").format("DD/MM/YYYY"),
      currentODO: data.miles7.currentODO,
      licensePlate: faker.string.alphanumeric({
        length: 6,
        casing: "upper",
      }),
      buildDate: moment().subtract(10, "years").format("DD/MM/YYYY"),
      chasisNumber: faker.string.alpha({
        length: 17,
        casing: "upper",
        exclude: ["I", "O", "Q"],
      }),
      region: data.miles7.region,
      state: data.miles7.state,
    });

    await createQuote.enterAndSaveVehicleDetailsForThirdPartyReno({
      duration: data.miles7.duration,
      distance: data.miles7.distance,
      postCode: data.miles7.postCode,
      state: data.miles7.state,
      grossAnnualSalary: data.miles7.grossAnnualSalary,
      leaseG: data.miles7.leaseG,
      faultClaims: data.miles7.faultClaims,
      convictedDUI: data.miles7.convictedDUI,
      negligentDriving: data.miles7.negligentDriving,
      purchaseType: data.miles7.purchaseType,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: data.miles7.removeService,
      addService: data.miles7.addService,
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: data.miles7.expandService2,
      removeService: "- Budgeted - Annual Comprehensive Insurance (Vero-NLCi)",
    });
    await createQuote.editLeaseServiceOptions({
      expandService1: data.miles7.expandService1,
      expandService2: "Registration (AU)",
      removeService: "- Budgeted - Registration",
      addService: "- None - Registration",
    });

    await createQuote.addThirdPartyLessor(data.miles7.thirdPartyLessor);
    await createQuote.calculateQuote();
    await createQuote.validateQuote();
    await createQuote.approveQuote();
    await createQuote.verifyQuoteStatus();
    console.log("Quote number: " + (await createQuote.retrieveQuoteNumber()));

    await createContract.createContract();
    const contractNum = await createContract.retrieveContractReferenceNumber();
    console.log("Contract Number: " + contractNum);

    await createVehicleOrder.createNewMilesVehicleOrder({
      ltc: contractNum,
      supplier: data.miles7.supplier,
      tradingOrderStatus: data.miles7.tradingOrderStatus,
    });

    await payAllInvoices.payAllInvoicesFromContract({
      ltc: contractNum,
      supplier: data.miles7.supplier,
    });

    await deliverVehicle.deliverNewOrExistingVehicle({
      ltc: contractNum,
      state: data.miles7.state,
    });

    await verifyContractRunningStatus.verifyContractRunningAndFullBilling({
      ltc: contractNum,
    });
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
