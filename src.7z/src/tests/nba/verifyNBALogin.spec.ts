import { APPCONSTANTS } from "../../app.constants";
import { LoginNBA } from "../../steps/nba/NBALoginSteps";
import { test } from "@playwright/test";

test.describe("NBA - Login @healthcheck, @nbahealthcheck", async () => {
  test.setTimeout(2 * 60 * 1000);
  let login: LoginNBA;

  test("Login into NBA application @EM-182 ", async ({ page }) => {
    login = new LoginNBA(page);
    await login.loginIntoNBA(
      APPCONSTANTS.NBA_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
