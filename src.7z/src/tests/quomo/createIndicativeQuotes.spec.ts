import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import moment from "moment";
import * as data from "./testdata/quomoData.json";

type QuoteValueType = {
  header: string;
  value: string;
};

test.describe("Create Indicative Quotes @regression @quomoRegression", async () => {
  test.setTimeout(10 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;

  test("Create an Indicative quote for New car_Invoiced_SGFleet sourced, @EM-75", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-75";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      colour: data[testData].colour,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for New car_Invoiced_Vehicle Special, @EM-76", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-76";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      colour: data[testData].colour,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Demo car_Invoiced_Customer Supplied, @EM-77", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-77";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      colour: data[testData].colour,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_Invoiced_Customer Supplied_Dealer, @EM-78", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-78";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_Invoiced_Customer Supplied_Private Sale, @EM-79", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-79";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_Invoiced_Customer Supplied_Private Sale-Company, @EM-80", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-80";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_Invoiced_Customer Supplied_Private Sale-Company, @EM-81", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-81";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });
  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test("Create an Indicative quote for Used car_Invoiced_Customer Supplied_Third party Funded, @EM-82", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-82";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,

      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for New car_T2P_Customer Supplied, @EM-83", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-83";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,

      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for New car_T2P_SGFleet sourced, @EM-84", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const testData = "EM-84";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for New car_T2P_Vehicle Special, @EM-85", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-85";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Demo car_T2P_Customer Supplied, @EM-86", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const testData = "EM-86";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Dealer, @EM-87", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-87";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Private Sale, @EM-88", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const testData = "EM-88";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Private Sale-Company, @EM-89", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-89";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Sale & Leaseback, @EM-90", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );

    const testData = "EM-90";

    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Third party Funded, @EM-91", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-91";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test("Create an Indicative quote for Used car_T2P_Customer Supplied_Third party Funded_ZLEV, @EM-92", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const testData = "EM-92";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
      zlev: data[testData].zlev,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
      zlev: data[testData].zlev,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});

//Uncomment the below line of code if you to execute Step 66
// const isValueMoreThanOne = (priceObject: QuoteValueType) =>
//   parseFloat(priceObject.value.trim().slice(1)) > 1;
