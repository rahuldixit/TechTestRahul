import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import moment from "moment";
import { verifyQuoteEmailAndDownloadPDF } from "../../../utils/emailReader";
import * as data from "./testdata/quomoData.json";

type QuoteValueType = {
  header: string;
  value: string;
};

test.describe("Scenario 1 - Creation of New Contract quote @smoke @quomosmoke", async () => {
  test.setTimeout(10 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;

  test("Invoiced - New Car - Customer Supplied @EM-74", async ({ page }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      opportunityID,
    );
    await page.waitForTimeout(7000);
    await createQuote.createIndicativeQuote({
      vehicleModel: data.quotedata.vehicleModel,
      vehicleName: data.quotedata.vehicleName,
      postCode: data.quotedata.postCode,
      procurementType: data.quotedata.procurementType,
      payCycle: data.quotedata.payCycle,
      term: data.quotedata.term,
      purchaseType: data.quotedata.purchaseType,
      colour: data.quotedata.colour,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
      //Uncomment the below line of code if you want the testcase to fail when quoteValue difference is >1
      //expect.soft(isValueMoreThanOne(quoteValue)).toBeFalsy();
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      data.vehicleQuoteEmail.subject,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});

//Uncomment the below line of code if you to execute Step 66
// const isValueMoreThanOne = (priceObject: QuoteValueType) =>
//   parseFloat(priceObject.value.trim().slice(1)) > 1;
