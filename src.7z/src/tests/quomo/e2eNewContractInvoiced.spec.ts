import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import { verifyQuoteEmailAndDownloadPDF } from "../../../utils/emailReader";
import moment from "moment";
import * as data from "./testdata/quomoData.json";

type QuoteValueType = {
  header: string;
  value: string;
};

test.describe("Create New Contract Invoiced @e2e @quomoe2e", async () => {
  test.setTimeout(10 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;

  test("Scenario 2 _ New Contract _ Invoiced _ New Car _ SG Fleet Sourced _ Disclaimer, @EM-619", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-75";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME_3,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      colour: data[testData].colour,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME_3,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME_3,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      data.vehicleQuoteEmail.subject,
    );
  });

  test("Scenario 3 _ New Contract _ Invoiced _ Used Car _ Third Party Funded, @EM-620", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-82";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME_2,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      insuranceAmount: data[testData].insuranceAmount,

      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME_2,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME_2,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      data.vehicleQuoteEmail.subject,
    );
  });

  test("Scenario 4 _ New Contract _ Invoiced _ Used Car _ Sale & Leaseback, @EM-621", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-81";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME_3,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME_3,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME_3,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      data.vehicleQuoteEmail.subject,
    );
  });

  test("Scenario 5 _ New Contract _ Invoiced _ Used Car _ Dealer, @EM-622", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const testData = "EM-78";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME_2,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME_2,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME_2,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      data.vehicleQuoteEmail.subject,
    );
  });

  test("Scenario 6 _ New Contract _ Invoiced _ Used Car _ Private Sale, @EM-623", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const testData = "EM-79";
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data[testData].customerName,
        emailaddr: APPCONSTANTS.USERNAME_3,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      opportunityID,
    );

    await page.waitForTimeout(7000);

    await createQuote.createIndicativeQuote({
      vehicleModel: data[testData].vehicleModel,
      vehicleName: data[testData].vehicleName,
      postCode: data[testData].postCode,
      procurementType: data[testData].procurementType,
      payCycle: data[testData].payCycle,
      term: data[testData].term,
      purchaseType: data[testData].purchaseType,
      vehicleSource: data[testData].vehicleSource,
    });
    await createQuote.setContractDetails({
      insuranceType: data[testData].insuranceType,
      funder: data[testData].funder,
      leaseGuard: data[testData].leaseGuard,
    });
    await createQuote.createFirmQuote({
      deliveryDate: moment().add(5, "days").format("DD/MM/YYYY"),
    });
    const quoteValues =
      (await createQuote.compareQuoteValues()) as QuoteValueType[];
    quoteValues.forEach((quoteValue) => {
      console.log(quoteValue);
    });
    await createQuote.sendVSSS(
      APPCONSTANTS.USERNAME_3,
      data.vehicleQuoteEmail.subject,
      data.vehicleQuoteEmail.message,
    );
    await createQuote.viewVSSS();
    await createQuote.submitOrder({
      emailAddr: APPCONSTANTS.USERNAME_3,
      mobNum: data.quotedata.mobNum,
      location: data.quotedata.location,
    });
    await verifyQuoteEmailAndDownloadPDF(
      page,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      data.vehicleQuoteEmail.subject,
    );
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
