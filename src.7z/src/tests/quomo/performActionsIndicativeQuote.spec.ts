import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import * as data from "./testdata/quomoData.json";

test.describe("Perform actions on indicative quote @regression @quomoregression", async () => {
  test.setTimeout(8 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;

  test("Discard, show, hide and restore an indicative quote @EM-106, @EM-107, @EM-108, @EM-109", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const oppurtunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
      oppurtunityID,
    );
    await page.waitForTimeout(7000);
    await createQuote.createIndicativeQuote({
      vehicleModel: data.quotedata.vehicleModel,
      vehicleName: data.quotedata.vehicleName,
      postCode: data.quotedata.postCode,
      procurementType: data.quotedata.procurementType,
      payCycle: data.quotedata.payCycle,
      term: data.quotedata.term,
      purchaseType: data.quotedata.purchaseType,
      colour: data.quotedata.colour,
    });

    await createQuote.discardQuotes();
    await createQuote.showDiscardedQuotes();
    await createQuote.hideDiscardedQuotes();
    await createQuote.restoreDiscardedQuotes();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
