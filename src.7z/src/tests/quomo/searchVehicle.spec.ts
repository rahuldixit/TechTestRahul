import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import * as data from "./testdata/quomoData.json";

test.describe("Vehicle search and validate vehicle search navigations @regression @quomoregression", async () => {
  test.setTimeout(4 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;

  test("Search vehicle and validate vehicle search navigations @EM-97  @EM-103", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const oppurtunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      oppurtunityID,
    );
    await page.waitForTimeout(7000);
    await createQuote.searchVehicle(data.quotedata.vehicleModel);
    await createQuote.showOrHideSearchScreen();
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
