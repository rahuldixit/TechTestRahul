import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { test } from "@playwright/test";
import { MsOnlineLogin } from "../../steps/common/MSOnlineLoginSteps";
import * as data from "./testdata/quomoData.json";

test.describe("Land on QuoMo Home screen @healthcheck @quomohealthcheck", async () => {
  test.setTimeout(5 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let msLogin: MsOnlineLogin;

  test("Land on QuoMo Home screen - using Quote URL @EM-73", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const oppurtunityID = issueNum.split("-")[1];

    await createOpp.openQuoteURLFromLead();
    await page.context().waitForEvent("page");
    await page.waitForTimeout(3000);
    console.log("pages:", page.context().pages().length);
    const newPage = page.context().pages()[1];
    msLogin = new MsOnlineLogin(newPage);
    await msLogin.loginIntoMicrosoftAccount(
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    login = new LoginIntoQuomo(newPage);
    console.log("Page url:", page.url());
    await newPage.reload();
    await login.acknowledgeEmployerNotes(oppurtunityID);
  });

  test("Land on QuoMo Home screen - using IMS Lead number @EM-73", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });
    console.log("Issue ID is:", issueNum);
    const ticketID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME,
      APPCONSTANTS.PASSWORD,
      ticketID,
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
