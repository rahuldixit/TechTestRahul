import { APPCONSTANTS } from "../../app.constants";
import { LoginIntoQuomo } from "../../steps/quomo/QuomoLoginSteps";
import { LoginIntoIMS } from "../../steps/ims/IMSLoginSteps";
import { CreateOppurtunity } from "../../steps/ims/CreateIMSLeadSteps";
import { expect, test } from "@playwright/test";
import { CreateQuote } from "../../steps/quomo/CreateIndicativeAndFirmQuotesSteps";
import * as data from "./testdata/quomoData.json";
import { QuomoIndicativeQuotePage } from "pages/quomo/QuomoIndicativeQuotePage";

test.describe("Variation reason - Perform Contract Configuration In Fuel, Maintenance and Tyres services @regression @quomoregression", async () => {
  test.setTimeout(10 * 60 * 1000);
  let loginIMS: LoginIntoIMS;
  let createOpp: CreateOppurtunity;
  let login: LoginIntoQuomo;
  let createQuote: CreateQuote;
  let quomoIndicativePage: QuomoIndicativeQuotePage;

  test("Verify Monthly price within plus or minus 20% @EM-93", async ({
    page,
  }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);
    quomoIndicativePage = new QuomoIndicativeQuotePage(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);
    await createQuote.createIndicativeQuote({
      vehicleModel: data.quotedata.vehicleModel,
      vehicleName: data.quotedata.vehicleName,
      postCode: data.quotedata.postCode,
      procurementType: data.quotedata.procurementType,
      payCycle: data.quotedata.payCycle,
      term: data.quotedata.term,
      purchaseType: data.quotedata.purchaseType,
      colour: data.quotedata.colour,
    });
    await createQuote.createCustomerRequestInFuelMaintenanceTyre(
      0.9,
      "Customer request",
    );
    expect(quomoIndicativePage.warningMessageFuel).not.toBeVisible();
    expect(quomoIndicativePage.warningMessageMaintenance).not.toBeVisible();
    expect(quomoIndicativePage.warningMessageTyres).not.toBeVisible();
  });

  test("Verify Monthly price more than 20% @EM-94", async ({ page }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);
    quomoIndicativePage = new QuomoIndicativeQuotePage(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_3,
      APPCONSTANTS.PASSWORD_3,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);
    await createQuote.createIndicativeQuote({
      vehicleModel: data.quotedata.vehicleModel,
      vehicleName: data.quotedata.vehicleName,
      postCode: data.quotedata.postCode,
      procurementType: data.quotedata.procurementType,
      payCycle: data.quotedata.payCycle,
      term: data.quotedata.term,
      purchaseType: data.quotedata.purchaseType,
      colour: data.quotedata.colour,
    });
    await createQuote.createCustomerRequestInFuelMaintenanceTyre(
      1.6,
      "Customer request",
    );
    expect(quomoIndicativePage.warningMessageFuel).toBeVisible;
    await expect(quomoIndicativePage.warningMessageFuel).toContainText(
      "Monthly fuel budget override cannot exceed 20% variation limit",
    );
    await expect(quomoIndicativePage.warningMessageMaintenance).toContainText(
      "Monthly maintenance budget override cannot exceed 20% variation limit",
    );
    await expect(quomoIndicativePage.warningMessageTyres).toContainText(
      "Tyre cost override cannot exceed 20% variation limit",
    );
  });

  test("Verify Monthly price less than 20% @EM-95", async ({ page }) => {
    loginIMS = new LoginIntoIMS(page);
    createOpp = new CreateOppurtunity(page);
    login = new LoginIntoQuomo(page);
    createQuote = new CreateQuote(page);
    quomoIndicativePage = new QuomoIndicativeQuotePage(page);

    await loginIMS.loginIntoIMSUsingUsernameAndPassword(
      APPCONSTANTS.IMS_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
    );
    const { issueNum } =
      await createOpp.createNewOppurtunityAndRetrieveQuoteDetails({
        customerName: data.quotedata.customerName,
        emailaddr: APPCONSTANTS.USERNAME,
      });

    const opportunityID = issueNum.split("-")[1];
    await login.searchIMSLeadInQuomo(
      APPCONSTANTS.QUOMO_APP_URL,
      APPCONSTANTS.USERNAME_2,
      APPCONSTANTS.PASSWORD_2,
      opportunityID,
    );

    await page.waitForTimeout(7000);
    await createQuote.createIndicativeQuote({
      vehicleModel: data.quotedata.vehicleModel,
      vehicleName: data.quotedata.vehicleName,
      postCode: data.quotedata.postCode,
      procurementType: data.quotedata.procurementType,
      payCycle: data.quotedata.payCycle,
      term: data.quotedata.term,
      purchaseType: data.quotedata.purchaseType,
      colour: data.quotedata.colour,
    });
    await createQuote.createCustomerRequestInFuelMaintenanceTyre(
      0.5,
      "Customer request",
    );
    await expect(quomoIndicativePage.warningMessageFuel).toContainText(
      "Monthly fuel budget override cannot be below 20% variation limit",
    );
    await expect(quomoIndicativePage.warningMessageMaintenance).toContainText(
      "Monthly maintenance budget override cannot be below 20% variation limit",
    );
    await expect(quomoIndicativePage.warningMessageTyres).toContainText(
      "Tyre cost override cannot be below 20 % variation limit",
    );
  });

  test.beforeEach(async ({}, testInfo) => {
    if (testInfo.retry > 0) {
      //await page.waitForTimeout(5 * 60 * 1000);
      //test.setTimeout(15 * 60 * 1000);
    }
  });

  test.afterEach(async ({}, testInfo) => {
    console.log(`\nRan Test: ${testInfo.title}`);
    console.log(`On Retry #${testInfo.retry}`);
    if (testInfo.status !== testInfo.expectedStatus) {
      console.log(`${testInfo.title} did not run as expected!`);
      console.log("Error Message: ", testInfo.error?.message);
      console.log("Error Value: ", testInfo.error?.value);
      console.log("Error Stack: ", testInfo.error?.stack);
    } else {
      console.log(`${testInfo.title} passed!`);
    }
  });
});
