import { Locator, Page } from "@playwright/test";

export class FileUpload {
  readonly page: Page;
  fileChooser: Locator;
  imsUploadProgressBar: Locator;

  constructor(page: Page) {
    this.page = page;
    this.fileChooser = page.locator("input[type='file']");
    this.imsUploadProgressBar = page.locator(".upload-progress-bar__bar");
  }

  async uploadFile(fileLoc: string, container?: string) {
    container
      ? await this.page
          .locator(container)
          .locator("input[type='file']")
          .setInputFiles(fileLoc)
      : await this.fileChooser.setInputFiles(fileLoc);
  }

  async waitForIMSFileUploadProgressBar(timeoutInSeconds = 60){
    await this.imsUploadProgressBar.waitFor();
    const percent = await this.imsUploadProgressBar.getAttribute("style");
    const percentNum = Number(percent?.replace("%;", "").replace("width: ", ""));
    if(percentNum < 100 && timeoutInSeconds){
      await this.page.waitForTimeout(1000);
      await this.waitForIMSFileUploadProgressBar(--timeoutInSeconds);
    }
  }
}
