import { request as playwrightrequest } from "@playwright/test";
export const getRequest = async ({
  URL,
  headers,
}: {
  URL: string;
  headers: Record<string, any>;
}) => {
  const request = await playwrightrequest.newContext();
  const response = await request.get(URL, {
    headers,
  });
  return await response.json();
};

export const postRequest = async ({
  URL,
  headers,
  payload,
}: {
  URL: string;
  headers?: Record<string, any>;
  payload: Record<string, any>;
}) => {
  const request = await playwrightrequest.newContext();
  const response = await request.post(URL, {
    headers,
    data: payload,
  });
  return await response.json();
};

export const putRequest = async ({
  URL,
  headers,
  payload,
}: {
  URL: string;
  headers?: Record<string, any>;
  payload: Record<string, any>;
}) => {
  const request = await playwrightrequest.newContext();
  const response = await request.put(URL, { headers, data: payload });
  return await response.json();
};


export const deleteRequest = async ({
  URL,
  headers,
  payload,
}: {
  URL: string;
  headers?: Record<string, any>;
  payload?: Record<string, any>;
}) => {
    const request = await playwrightrequest.newContext()
    const response = await request.delete(URL, {headers,data:payload})
    return await response.json();
};
