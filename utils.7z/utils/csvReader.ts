import Papa from 'papaparse';
const fs = require('fs');
// First I want to read the file
export const readCSV = async(fileName: any) => {
    let csvString = await fs.readFileSync(fileName,'utf8');
    let resultsData = Papa.parse(csvString);   
    console.log(resultsData);         
    return resultsData;
}

export function hasDuplicates(array: string[]) {
	let valuesSoFar = Object.create(null);
    for (var i = 0; i < array.length; ++i) {
        var value = array[i];
        if (value in valuesSoFar) {
            return true;
        }
        valuesSoFar[value] = true;
    }
    return false;
}