import { chromium, Browser, Page, expect } from "@playwright/test";
import { MsOnlineLogin } from "../src/steps/common/MSOnlineLoginSteps";

export const readOutlookEmails = async (
  page: Page,
  username: string,
  password: string,
  subject: string,
  timeOut = 180,
) => {
  const msLoginSteps = new MsOnlineLogin(page);
  const btnSubmit= page.locator('[type="submit"]'); // button name changes it could be "Next" "Sign In"

  // Navigate to outlook login page
  await page.goto("https://outlook.live.com/owa/");
  // Click 'Sign-in' button
  if (await page.locator('#mectrl_headerPicture').isVisible()) {
    await page.click('#mectrl_headerPicture');
  }
  else {
    await page.click('.msame_Header_name st_msame_placeholder');    
  }
  await page.waitForLoadState("domcontentloaded");
  await page.waitForTimeout(5000);
  if(await page.locator('#i0116').isVisible()) {
    await page.fill("#i0116",username); 
    await btnSubmit.click();
  }  
  await page.waitForTimeout(5000);
  if(await page.locator('#i0118').isVisible()) {
    await page.fill("#i0118",password); 
    await btnSubmit.click();
  }  
  await page.waitForTimeout(5000);
   if(await btnSubmit.isVisible()) {
    await btnSubmit.click();
  }
  // Wait for the inbox to load
  await page.waitForSelector('div[role="listbox"]');
  // Select the first email    
  return waitForNewSubject(timeOut, page, subject);
}

async function extractSubjectName(page: Page) {  
  await page.locator('div[role=option]').first().click();
  const emailHeader = page.locator("#ConversationReadingPaneContainer [class*=allowTextSelection][role=heading] span:nth-child(1)").nth(0);      
  return await emailHeader.innerText();    
}

export const waitForNewSubject = async (timeOut = 180, page: Page, subject: string) => {    
  console.log("Waiting for email");
  do {              
    await page.waitForTimeout(1000);          
    let actualSubject = await extractSubjectName(page);
    if(actualSubject.includes(subject)) {
      return actualSubject;        
    }                        
    timeOut--;
    if(timeOut == 0) {
      expect(timeOut, "Email not received within timeOut.").not.toEqual(0);
    }
  } while (timeOut>0);      
}

export const verifyQuoteEmailAndDownloadPDF = async (
  existingPage: Page,
  username: string,
  password: string,
  sub: string
) => {
  const page: Page = await existingPage.context().newPage();
  const subject = await readOutlookEmails(page, username, password, sub);
  expect(subject).toBeTruthy();
  const downloadPath = await downloadFile(page);
  return downloadPath;
};

export async function downloadFile (page: Page){
  const downloadPromise = page.waitForEvent('download');  
  await page.getByTitle("More actions").first().click();
  await page.getByRole("menuitem").filter({ hasText: "Download" }).click();
  const download = await downloadPromise;  
  console.log("File Saved at: ", await download.path());
  return await download.path();
}

export const verifyEmailAndLaunchOnlineFinanceApplication = async (
  username: string,
  password: string,
  quoteNo: string,
  subject?: string
) => {
  const browser: Browser = await chromium.launch();
  const context = await browser.newContext();
  const page: Page = await context.newPage();

  const emailSubject = await readOutlookEmails(page, username, password, subject? subject : "");
  if (emailSubject?.includes(quoteNo)) {
    await page.click(
      '[a:has-text("Click here to launch your finance application.")]'
    );
  } else {
    await page.reload();
    await page.waitForSelector('div[role="listbox"]');
    await page.locator('div[role="option"]').first().click();
    await page.click(
      '[a:has-text("Click here to launch your finance application.")]'
    );
  }
};
