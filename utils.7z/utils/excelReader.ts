import * as Excel from "exceljs";

export const readDataFromExcel = async(filePath: string): Promise<any[]> => {
  const workbook = new Excel.Workbook();
  await workbook.xlsx.readFile(filePath);
  const worksheetdata = workbook.getWorksheet(1);
  const data: any[] | PromiseLike<any[]> = [];

  //Get header row
  const headerRow = worksheetdata.getRow(1);

  //@ts-ignore
  const keys = headerRow.values.slice(1);

  worksheetdata.eachRow((row, rowNumber) => {
    //Data starts from second row
    if (rowNumber > 1) {
      const rowData: any = {};
      row.eachCell((cell, colNumber) => {
        const key = keys[colNumber - 1];
        rowData[key] = cell.value;
      });

      data.push(rowData);
    }
  });
  console.log(data);
  return data;
}

//Example:
//readDataFromExcel(process.cwd() + "/assets/BussApp_2023Jul25_0.xlsx");
