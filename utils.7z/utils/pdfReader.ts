import pdfParse from "pdf-parse";
import { Page } from "@playwright/test";
import fs from "fs";
import { error } from "console";

export const readDataFromPDF = async (pdfFile: string) => {
  console.log("file:", pdfFile);
  let file = fs.readFileSync(pdfFile);
  let pdfExtract = await pdfParse(file);
  console.log("extract:", pdfExtract)
  return pdfExtract.text;
};

export const openAndDownloadPDF = async (pdfPage: Page) => {
  await pdfPage.bringToFront();
  const isPDF = await pdfPage.evaluate(
    () => document.contentType === "application/pdf"
  );
  if (isPDF) {
    console.log("PDF opened successfully in new tab");
  } else {
    console.log("Failed to open PDF");
  }
  try {
    const download = await pdfPage.waitForEvent("download");
    await download.saveAs("./assets/");
    console.log("PDF downloaded successfully");
  } catch {
    console.error("Download Failed", error);
  }
};

//Example:
//readDataFromPDF("./assets/Novated lease quote 1017919-002.pdf");
